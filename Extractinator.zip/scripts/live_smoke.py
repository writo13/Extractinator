"""Read-only live smoke test against real websites. Needs internet access.

    python scripts/live_smoke.py

Exits non-zero when a check fails, so it can run on a schedule and catch
site layout changes early. It is deliberately not part of the pytest suite.
"""

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from extractinator.core.exceptions import ExtractinatorError  # noqa: E402
from extractinator.service import ExtractinatorService  # noqa: E402


def books_listing(result):
    books = result.data.get("books", [])
    if result.adapter != "books_to_scrape":
        return "the books_to_scrape adapter did not handle the page"
    if not books:
        return "no books found"
    if not all(b["title"] and b["price"] is not None for b in books):
        return "a book is missing its title or price"
    if not result.data["pagination"]["next_url"]:
        return "no next-page URL"
    return None


def books_detail(result):
    data = result.data
    if result.adapter != "books_to_scrape" or data.get("type") != "book":
        return "the adapter did not return a book"
    if data["title"] != "A Light in the Attic":
        return f"unexpected title: {data['title']!r}"
    if data["currency"] != "GBP" or data["price"] is None:
        return "price or currency missing"
    return None


def example_com(result):
    title = result.data.get("metadata", {}).get("title")
    return None if title == "Example Domain" else f"unexpected title: {title!r}"


CHECKS = [
    ("books listing", "https://books.toscrape.com/", books_listing),
    ("book detail", "https://books.toscrape.com/catalogue/a-light-in-the-attic_1000/index.html", books_detail),
    ("generic page", "https://example.com/", example_com),
]


def main() -> int:
    service = ExtractinatorService()
    failures = 0
    for name, url, verify in CHECKS:
        started = time.monotonic()
        try:
            problem = verify(service.extract(url))
        except ExtractinatorError as exc:
            problem = f"{type(exc).__name__}: {exc}"
        elapsed = time.monotonic() - started
        print(f"{'FAIL' if problem else 'PASS'}  {name:<14} {elapsed:4.1f}s  {problem or ''}")
        failures += bool(problem)
    print(f"\n{len(CHECKS) - failures}/{len(CHECKS)} checks passed")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
