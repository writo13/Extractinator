"""Stream sanitized mitmproxy HTTP flows into Extractinator.

Run:
    mitmdump -s scripts/mitmproxy_capture.py

Only traffic observed through the user's own proxy is captured. Sensitive headers
and credentials are redacted before the flow is queued for POST to the local dashboard.
"""
from __future__ import annotations

import os
import queue
import threading
import time
from urllib.parse import urlsplit

import requests
from mitmproxy import ctx, http

TARGET = os.getenv("EXTRACTINATOR_FLOW_TARGET", "http://127.0.0.1:8000/flows/ingest")
ADMIN_KEY = os.getenv("EXTRACTINATOR_ADMIN_KEY", "")
BLOCKED_HEADERS = {
    "authorization", "proxy-authorization", "cookie", "set-cookie", "x-api-key",
    "x-auth-token", "x-access-token", "x-csrf-token", "x-xsrf-token",
}
MAX_BODY = 500_000

_queue: queue.Queue[dict] = queue.Queue(maxsize=1000)
_stop = threading.Event()
_worker: threading.Thread | None = None


def _headers(headers):
    return {k: ("<redacted>" if k.lower() in BLOCKED_HEADERS else v) for k, v in headers.items()}


def _body(message) -> str | None:
    try:
        content = message.raw_content or b""
        if not content:
            return None
        return content[:MAX_BODY].decode(message.get_text(strict=False) and "utf-8" or "utf-8", errors="replace")
    except Exception:
        return None


def _worker_loop():
    while not _stop.is_set():
        try:
            payload = _queue.get(timeout=0.2)
        except queue.Empty:
            continue
        try:
            headers = {"Content-Type": "application/json"}
            if ADMIN_KEY:
                headers["X-Extractinator-Admin-Key"] = ADMIN_KEY
            requests.post(TARGET, json=payload, headers=headers, timeout=2)
        except requests.RequestException as exc:
            ctx.log.debug(f"Extractinator flow post failed: {exc}")
        finally:
            _queue.task_done()


def load(loader):
    global _worker
    _worker = threading.Thread(target=_worker_loop, daemon=True)
    _worker.start()


def done():
    _stop.set()


def response(flow: http.HTTPFlow):
    request = flow.request
    host = urlsplit(request.pretty_url).hostname
    if not host or host in {"localhost", "127.0.0.1", "::1"}:
        return
    started = getattr(flow.server_conn, "timestamp_start", None) or getattr(request, "timestamp_start", None)
    ended = getattr(flow.client_conn, "timestamp_end", None) or getattr(flow.response, "timestamp_start", None)
    total_ms = max(0.0, (ended - started) * 1000) if started and ended else None
    payload = {
        "source": "mitmproxy",
        "state": "completed" if flow.response else "error",
        "started_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(started or time.time())),
        "request": {
            "method": request.method,
            "url": request.pretty_url,
            "http_version": request.http_version or "HTTP/1.1",
            "headers": _headers(request.headers),
            "body": _body(request),
        },
        "response": {
            "status": flow.response.status_code if flow.response else None,
            "reason": flow.response.reason if flow.response else "",
            "http_version": flow.response.http_version if flow.response else "HTTP/1.1",
            "headers": _headers(flow.response.headers) if flow.response else {},
            "body": _body(flow.response) if flow.response else None,
        },
        "timing": {"total_ms": total_ms},
    }
    try:
        _queue.put_nowait(payload)
    except queue.Full:
        ctx.log.warn("Extractinator flow queue is full; dropping flow")
