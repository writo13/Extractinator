"""Extract one URL and print the result as JSON.

    python scripts/demo.py https://books.toscrape.com/
    python scripts/demo.py            (prompts for a URL)
"""

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from extractinator.core.exceptions import ExtractinatorError  # noqa: E402
from extractinator.service import ExtractinatorService  # noqa: E402


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    url = sys.argv[1] if len(sys.argv) > 1 else input("Public URL to extract: ").strip()
    try:
        result = ExtractinatorService().extract(url)
    except ExtractinatorError as exc:
        print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result.as_dict(), indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
