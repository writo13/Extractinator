from __future__ import annotations

import argparse
import json
import sys

import uvicorn

from extractinator.api import create_app
from extractinator.core.config import Settings
from extractinator.core.flows import FlowStore, compile_filter
from extractinator.service import ExtractinatorService


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="extractinator")
    sub = parser.add_subparsers(dest="command")

    serve = sub.add_parser("serve", help="Run the Extractinator API")
    serve.add_argument("--host")
    serve.add_argument("--port", type=int)

    dump = sub.add_parser("dump", help="List stored flows")
    dump.add_argument("--filter", default="")
    dump.add_argument("--limit", type=int, default=100)
    _add_filter_flags(dump)

    export = sub.add_parser("export-har", help="Export stored flows to HAR")
    export.add_argument("path")
    export.add_argument("--filter", default="")
    export.add_argument("--limit", type=int, default=5000)
    _add_filter_flags(export)

    import_cmd = sub.add_parser("import-har", help="Import HAR into the flow store")
    import_cmd.add_argument("path")

    extract = sub.add_parser("extract-flow", help="Extract a stored response body offline")
    extract.add_argument("flow_id")

    replay = sub.add_parser("replay", help="Replay a stored flow against its public URL")
    replay.add_argument("flow_id")

    return parser


def _add_filter_flags(parser):
    parser.add_argument("--method")
    parser.add_argument("--status")
    parser.add_argument("--header", action="append", default=[])
    parser.add_argument("--body")
    parser.add_argument("--url")
    parser.add_argument("--source")
    parser.add_argument("--error", action="store_true")
    parser.add_argument("--redirect", action="store_true")


def _predicate_from_args(args):
    return compile_filter(args.filter, method=args.method, status=args.status, header=args.header, body=args.body, url=args.url, source=args.source, error=args.error, redirect=args.redirect)


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    settings = Settings.from_env()

    if args.command in {None, "serve"}:
        host = getattr(args, "host", None) or settings.host
        port = getattr(args, "port", None) or settings.port
        uvicorn.run(create_app(), host=host, port=port, reload=False)
        return 0

    store = FlowStore(settings.db_path)

    if args.command == "dump":
        predicate = _predicate_from_args(args)
        for flow in store.list(predicate, args.limit):
            print(json.dumps({
                "sequence": flow.sequence,
                "id": flow.id,
                "method": flow.request.method,
                "status": flow.status,
                "url": flow.request.url,
                "duration_ms": flow.duration_ms,
                "state": flow.state,
                "error": flow.error,
            }, ensure_ascii=False))
        return 0

    if args.command == "export-har":
        document = store.export_har(_predicate_from_args(args), args.limit)
        with open(args.path, "w", encoding="utf-8") as fh:
            json.dump(document, fh, ensure_ascii=False, indent=2)
        print(f"wrote {args.path}")
        return 0

    if args.command == "import-har":
        from extractinator.core.flows import har_to_flows
        with open(args.path, "r", encoding="utf-8") as fh:
            document = json.load(fh)
        flows, warnings = har_to_flows(document)
        saved = store.import_flows(flows)
        print(json.dumps({"imported": len(saved), "warnings": warnings}, indent=2))
        return 0

    if args.command == "extract-flow":
        service = ExtractinatorService()
        result = service.extract_from_flow(args.flow_id)
        if result is None:
            print("flow not found", file=sys.stderr)
            return 1
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0

    if args.command == "replay":
        service = ExtractinatorService()
        result = service.replay_flow(args.flow_id)
        if result is None:
            print("flow not found", file=sys.stderr)
            return 1
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0

    return 2


if __name__ == "__main__":
    raise SystemExit(main())
