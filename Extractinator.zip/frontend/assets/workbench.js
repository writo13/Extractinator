'use strict';

const wb = (id) => document.getElementById(id);
const adminHeaders = () => {
  const value = wb('admin-key')?.value?.trim();
  return value ? {'X-Extractinator-Admin-Key': value} : {};
};

async function wbJson(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: {'Content-Type': 'application/json', ...adminHeaders(), ...(options.headers || {})},
    cache: 'no-store',
  });
  const text = await response.text();
  let body;
  try { body = text ? JSON.parse(text) : {}; } catch { body = {raw: text}; }
  if (!response.ok) throw new Error(body?.error || body?.detail || `HTTP ${response.status}`);
  return body;
}

function pretty(value) { return JSON.stringify(value, null, 2); }
function safeJson(text, fallback) {
  try { return text.trim() ? JSON.parse(text) : fallback; }
  catch { throw new Error('Invalid JSON in one of the JSON fields.'); }
}
function setOutput(value) { wb('lab-response').textContent = typeof value === 'string' ? value : pretty(value); }
function resourceEmpty(text) { return `<div class="recent-empty">${text}</div>`; }

async function discoverEndpoints() {
  try {
    const url = encodeURIComponent(wb('lab-url').value.trim());
    const result = await wbJson(`/discover?url=${url}`);
    setOutput(result);
    const first = result.candidates?.[0]?.url;
    if (first) wb('forge-url').value = first;
  } catch (error) { setOutput(`Discovery error: ${error.message}`); }
}

async function sendLabRequest() {
  try {
    const payload = {
      method: wb('lab-method').value,
      url: wb('lab-url').value.trim(),
      params: safeJson(wb('lab-params').value, {}),
      headers: safeJson(wb('lab-headers').value, {}),
      body: wb('lab-body').value || null,
    };
    setOutput('Sending…');
    const result = await wbJson('/lab/request', {method: 'POST', body: JSON.stringify(payload)});
    setOutput(result);
  } catch (error) { setOutput(`Error: ${error.message}`); }
}

async function loadCaptures() {
  const el = wb('captures-list');
  try {
    const data = await wbJson('/captures');
    const captures = data.captures || [];
    el.innerHTML = captures.length ? captures.map((c) => `
      <div class="resource-item">
        <div class="resource-title">${c.method} ${wbEscapeHtml(c.url)}</div>
        <div class="resource-sub">${wbEscapeHtml(c.created_at)}</div>
        <div class="resource-actions">
          <button class="tiny-btn" data-capture="${c.id}">Use in Lab</button>
          <button class="tiny-btn danger-capture" data-delete-capture="${c.id}">Delete</button>
        </div>
      </div>`).join('') : resourceEmpty('No captures yet.');
    el.querySelectorAll('[data-capture]').forEach((button) => button.addEventListener('click', async () => {
      const id = button.dataset.capture;
      const capture = (await wbJson('/captures')).captures.find((item) => String(item.id) === id);
      if (!capture) return;
      wb('lab-method').value = capture.method;
      wb('lab-url').value = capture.url;
      wb('lab-headers').value = pretty(capture.headers || {});
      wb('lab-body').value = capture.body || '';
      window.scrollTo({top: wb('lab-url').getBoundingClientRect().top + window.scrollY - 100, behavior: 'smooth'});
    }));
    el.querySelectorAll('[data-delete-capture]').forEach((button) => button.addEventListener('click', async () => {
      await wbJson(`/captures/${button.dataset.deleteCapture}`, {method: 'DELETE'});
      loadCaptures();
    }));
  } catch (error) { el.innerHTML = resourceEmpty(`Capture access: ${wbEscapeHtml(error.message)}`); }
}

async function loadApis() {
  const el = wb('generated-apis');
  try {
    const data = await wbJson('/forge/apis');
    const apis = data.apis || [];
    el.innerHTML = apis.length ? apis.map((api) => `
      <div class="resource-item">
        <div class="resource-title">${wbEscapeHtml(api.name)}</div>
        <div class="resource-sub">${api.method} /generated/${wbEscapeHtml(api.slug)} → ${wbEscapeHtml(api.upstream_url)}</div>
        <div class="resource-actions"><button class="tiny-btn" data-disable-api="${api.id}">Disable</button><button class="tiny-btn" data-copy-endpoint="http://127.0.0.1:8000/generated/${wbEscapeHtml(api.slug)}">Copy URL</button></div>
      </div>`).join('') : resourceEmpty('No generated APIs yet.');
    el.querySelectorAll('[data-disable-api]').forEach((button) => button.addEventListener('click', async () => {
      await wbJson(`/forge/apis/${button.dataset.disableApi}`, {method: 'DELETE'});
      loadApis();
    }));
    el.querySelectorAll('[data-copy-endpoint]').forEach((button) => button.addEventListener('click', async () => {
      await navigator.clipboard.writeText(button.dataset.copyEndpoint);
    }));
  } catch (error) { el.innerHTML = resourceEmpty(`API Forge: ${wbEscapeHtml(error.message)}`); }
}

async function createApi() {
  try {
    const body = {
      name: wb('forge-name').value.trim(),
      method: wb('forge-method').value,
      upstream_url: wb('forge-url').value.trim(),
      description: wb('forge-desc').value.trim(),
    };
    const result = await wbJson('/forge/apis', {method: 'POST', body: JSON.stringify(body)});
    setOutput(result);
    await loadApis();
  } catch (error) { setOutput(`API Forge error: ${error.message}`); }
}

async function loadTokens() {
  const el = wb('tokens-list');
  try {
    const data = await wbJson('/tokens');
    const tokens = data.tokens || [];
    el.innerHTML = tokens.length ? tokens.map((t) => `
      <div class="resource-item">
        <div class="resource-title">${wbEscapeHtml(t.name)} ${t.revoked ? '<span class="badge">REVOKED</span>' : ''}</div>
        <div class="resource-sub">${wbEscapeHtml(t.prefix)}… · scopes: ${wbEscapeHtml((t.scopes || []).join(', '))}${t.expires_at ? ` · expires: ${wbEscapeHtml(t.expires_at)}` : ''}</div>
        ${t.revoked ? '' : `<div class="resource-actions"><button class="tiny-btn" data-revoke-token="${t.id}">Revoke</button></div>`}
      </div>`).join('') : resourceEmpty('No tokens yet.');
    el.querySelectorAll('[data-revoke-token]').forEach((button) => button.addEventListener('click', async () => {
      await wbJson(`/tokens/${button.dataset.revokeToken}`, {method: 'DELETE'});
      loadTokens();
    }));
  } catch (error) { el.innerHTML = resourceEmpty(`Token access: ${wbEscapeHtml(error.message)}`); }
}

async function createToken() {
  try {
    const result = await wbJson('/tokens', {
      method: 'POST',
      body: JSON.stringify({
        name: wb('token-name').value.trim() || 'postman-client',
        expires_at: wb('token-expiry').value.trim() || null,
        scopes: ['invoke'],
      }),
    });
    const reveal = wb('new-token');
    reveal.classList.remove('hidden');
    reveal.innerHTML = `<div class="overview-label">Copy this token now</div><code>${wbEscapeHtml(result.token)}</code><button id="copy-new-token" class="tiny-btn" type="button">Copy token</button>`;
    wb('copy-new-token').addEventListener('click', async () => navigator.clipboard.writeText(result.token));
    loadTokens();
  } catch (error) { wb('new-token').textContent = error.message; wb('new-token').classList.remove('hidden'); }
}

function wbEscapeHtml(value) {
  return String(value).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;');
}

wb('lab-send')?.addEventListener('click', sendLabRequest);
wb('lab-discover')?.addEventListener('click', discoverEndpoints);
wb('captures-refresh')?.addEventListener('click', loadCaptures);
wb('apis-refresh')?.addEventListener('click', loadApis);
wb('tokens-refresh')?.addEventListener('click', loadTokens);
wb('forge-create')?.addEventListener('click', createApi);
wb('token-create')?.addEventListener('click', createToken);

loadCaptures();
loadApis();
loadTokens();
