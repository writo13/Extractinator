'use strict';

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const form = $('#extract-form');
const urlInput = $('#url-input');
const extractBtn = $('#extract-btn');
const clearBtn = $('#clear-btn');
const validationMsg = $('#validation-msg');
const capabilityBox = $('#capability-box');
const statusPill = $('#api-status');
const versionLabel = $('#app-version');
const errorBox = $('#error-box');
const emptyState = $('#empty-state');
const resultContent = $('#result-content');
const resultTitle = $('#result-title');
const resultMeta = $('#result-meta');
const overviewPanel = $('#tab-overview');
const dataPanel = $('#tab-data');
const jsonOutput = $('#json-output');
const copyBtn = $('#copy-btn');
const downloadBtn = $('#download-btn');
const recentList = $('#recent-list');

const STORAGE_KEY = 'extractinator_recent';
const MAX_RECENT = 6;
const MAX_ROWS = 200;
const CAPABILITY_PLACEHOLDER = 'Enter a URL to see how it will be extracted.';

let lastResult = null;
let lastHost = 'result';
let extractController = null;
let capabilityController = null;

/* ---------------------------------------------------------------- helpers */

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

// "books.toscrape.com" -> "https://books.toscrape.com"
function normalizeUrl(value) {
  const trimmed = value.trim();
  if (!trimmed) return '';
  return /^[a-z][a-z0-9+.-]*:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
}

function isValidUrl(value) {
  try {
    const url = new URL(value);
    return ['http:', 'https:'].includes(url.protocol) && Boolean(url.hostname);
  } catch {
    return false;
  }
}

function hostOf(value) {
  try {
    return new URL(value).hostname || 'result';
  } catch {
    return 'result';
  }
}

async function getJson(path, controller) {
  const response = await fetch(path, { signal: controller.signal, cache: 'no-store' });
  let payload = {};
  try {
    payload = await response.json();
  } catch {
    // Non-JSON body, e.g. an HTML error page from a proxy.
  }
  return { response, payload };
}

function errorMessage(payload, response) {
  if (payload && typeof payload.error === 'string') return payload.error;
  if (payload && typeof payload.detail === 'string') return payload.detail;
  return `Unexpected response from the server (HTTP ${response.status}).`;
}

function friendlyError(error) {
  if (error instanceof TypeError) return 'Could not reach the Extractinator API. Is the server still running?';
  return error.message;
}

function setValidation(message = '', invalid = false) {
  validationMsg.textContent = message;
  validationMsg.classList.toggle('invalid', invalid);
}

function setLoading(loading) {
  extractBtn.disabled = loading;
  extractBtn.classList.toggle('loading', loading);
}

function showError(message) {
  errorBox.textContent = message;
  errorBox.classList.remove('hidden');
  emptyState.classList.add('hidden');
  resultContent.classList.add('hidden');
}

function clearError() {
  errorBox.classList.add('hidden');
  errorBox.textContent = '';
}

/* ----------------------------------------------------------- data renderer */

const isPrimitive = (v) => v === null || v === undefined || ['string', 'number', 'boolean'].includes(typeof v);
const isPlainObject = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const isFlatObject = (v) => isPlainObject(v) && Object.values(v).every(isPrimitive);

function renderPrimitive(value) {
  if (value === null || value === undefined) return '<span class="v-null">null</span>';
  if (typeof value !== 'string') return `<span class="v-num">${escapeHtml(value)}</span>`;
  if (/^https?:\/\//i.test(value)) {
    const href = escapeHtml(value);
    return `<a class="v-link" href="${href}" target="_blank" rel="noopener noreferrer">${href}</a>`;
  }
  return `<span class="v-str">${escapeHtml(value)}</span>`;
}

function overflowNote(total) {
  return total > MAX_ROWS ? `<div class="v-note">Showing the first ${MAX_ROWS} of ${total}. Use Raw JSON for everything.</div>` : '';
}

function renderTable(rows) {
  const columns = [...new Set(rows.flatMap((row) => Object.keys(row)))];
  const head = columns.map((c) => `<th>${escapeHtml(c)}</th>`).join('');
  const body = rows.slice(0, MAX_ROWS)
    .map((row) => `<tr>${columns.map((c) => `<td>${renderPrimitive(row[c])}</td>`).join('')}</tr>`)
    .join('');
  return `<div class="v-table-wrap"><table class="v-table"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>${overflowNote(rows.length)}`;
}

function renderMatrix(rows) {
  const body = rows.slice(0, MAX_ROWS)
    .map((row) => `<tr>${row.map((cell) => `<td>${renderPrimitive(cell)}</td>`).join('')}</tr>`)
    .join('');
  return `<div class="v-table-wrap"><table class="v-table"><tbody>${body}</tbody></table></div>${overflowNote(rows.length)}`;
}

function describe(value) {
  if (Array.isArray(value)) return `${value.length} ${value.length === 1 ? 'item' : 'items'}`;
  return `${Object.keys(value).length} fields`;
}

function renderArray(items, depth) {
  if (!items.length) return '<span class="v-null">[ ]</span>';
  if (items.every(isPrimitive)) {
    const list = items.slice(0, MAX_ROWS).map((item) => `<li>${renderPrimitive(item)}</li>`).join('');
    return `<ul class="v-list">${list}</ul>${overflowNote(items.length)}`;
  }
  if (items.every(isFlatObject)) return renderTable(items);
  if (items.every((item) => Array.isArray(item) && item.every(isPrimitive))) return renderMatrix(items);
  const nodes = items.slice(0, MAX_ROWS)
    .map((item, i) => renderNode(`[${i}]`, item, depth + 1, false))
    .join('');
  return `<div class="v-stack">${nodes}</div>${overflowNote(items.length)}`;
}

function renderObject(obj, depth) {
  const entries = Object.entries(obj);
  if (!entries.length) return '<span class="v-null">{ }</span>';
  const rows = entries.map(([key, value]) => (
    isPrimitive(value)
      ? `<div class="v-row"><div class="v-key">${escapeHtml(key)}</div><div class="v-val">${renderPrimitive(value)}</div></div>`
      : renderNode(key, value, depth + 1, depth === 0 && describeSize(value) <= 30)
  ));
  return `<div class="v-obj">${rows.join('')}</div>`;
}

function describeSize(value) {
  return Array.isArray(value) ? value.length : Object.keys(value).length;
}

function renderNode(key, value, depth, open) {
  const inner = Array.isArray(value) ? renderArray(value, depth) : renderObject(value, depth);
  return `<details class="v-node"${open ? ' open' : ''}><summary><span class="v-key">${escapeHtml(key)}</span> <span class="v-meta">${describe(value)}</span></summary><div class="v-body">${inner}</div></details>`;
}

function renderData(data) {
  if (!data || !Object.keys(data).length) {
    dataPanel.innerHTML = '<div class="capability-placeholder">No structured data returned.</div>';
    return;
  }
  dataPanel.innerHTML = renderObject(data, 0);
}

/* ---------------------------------------------------------------- overview */

function overviewCard(label, value, wide = false) {
  return `<div class="overview-card${wide ? ' span-2' : ''}"><div class="overview-label">${escapeHtml(label)}</div><div class="overview-value">${value}</div></div>`;
}

function renderOverview(payload) {
  const source = payload.source || {};
  const data = payload.data || {};
  const warnings = payload.warnings || [];
  const cards = [
    overviewCard('Type', escapeHtml(data.type || 'webpage')),
    overviewCard('Method', escapeHtml(source.method || 'unknown')),
    overviewCard('Adapter', escapeHtml(source.adapter || 'generic')),
    overviewCard('Fields', Object.keys(data).length),
    overviewCard('Source URL', escapeHtml(source.url || ''), true),
  ];
  if (source.requested_url && source.requested_url !== source.url) {
    cards.push(overviewCard('Requested URL (redirected)', escapeHtml(source.requested_url), true));
  }
  cards.push(overviewCard('Retrieved', escapeHtml(source.retrieved_at || '') + (source.cached ? ' (from cache)' : ''), true));

  const warningBox = warnings.length
    ? `<div class="warn-box"><div class="overview-label">Warnings</div><ul>${warnings.map((w) => `<li>${escapeHtml(w)}</li>`).join('')}</ul></div>`
    : '';
  overviewPanel.innerHTML = `<div class="overview-grid">${cards.join('')}</div>${warningBox}`;
}

function renderResult(payload, elapsedMs) {
  lastResult = payload;
  clearError();
  emptyState.classList.add('hidden');
  resultContent.classList.remove('hidden');

  const source = payload.source || {};
  const warnings = payload.warnings || [];
  const type = payload.data?.type || 'webpage';
  lastHost = hostOf(source.url);
  resultTitle.textContent = type.replaceAll('_', ' ');

  const chips = [
    `<div class="meta-chip"><strong>Type</strong> ${escapeHtml(type)}</div>`,
    `<div class="meta-chip"><strong>Method</strong> ${escapeHtml(source.method || 'unknown')}</div>`,
    `<div class="meta-chip"><strong>Adapter</strong> ${escapeHtml(source.adapter || 'generic')}</div>`,
    `<div class="meta-chip"><strong>Time</strong> ${(elapsedMs / 1000).toFixed(1)} s${source.cached ? ' · cached' : ''}</div>`,
  ];
  if (warnings.length) {
    chips.push(`<div class="meta-chip warn"><strong>${warnings.length}</strong> ${warnings.length === 1 ? 'warning' : 'warnings'}</div>`);
  }
  resultMeta.innerHTML = chips.join('');

  renderOverview(payload);
  renderData(payload.data);
  jsonOutput.textContent = JSON.stringify(payload, null, 2);
  copyBtn.disabled = false;
  downloadBtn.disabled = false;
  selectTab('overview');
}

function renderCapability(payload) {
  const adapter = payload.adapter;
  const generic = (payload.generic_extractors || []).join(', ');
  const robots = payload.respects_robots ? 'robots.txt is respected.' : 'robots.txt is NOT being checked.';
  capabilityBox.innerHTML = `
    <div class="capability-row">
      <div class="capability-main">
        <div class="capability-title">${adapter ? `Adapter: ${escapeHtml(adapter)}` : 'Generic extraction'}</div>
        <div class="capability-sub">${escapeHtml(payload.url || '')}</div>
      </div>
      <div class="badge">${adapter ? 'ADAPTER READY' : 'GENERIC READY'}</div>
    </div>
    <div class="capability-sub mt-10">Fallback extractors: ${escapeHtml(generic)}. ${robots}</div>
  `;
}

/* --------------------------------------------------------------------- API */

async function checkApi() {
  const controller = new AbortController();
  try {
    const { response, payload } = await getJson('/health', controller);
    if (!response.ok) throw new Error('Health check failed');
    statusPill.classList.add('ok');
    statusPill.classList.remove('bad');
    statusPill.innerHTML = '<span class="status-dot"></span> API online';
    if (payload.version) versionLabel.textContent = `v${payload.version}`;
  } catch {
    statusPill.classList.add('bad');
    statusPill.classList.remove('ok');
    statusPill.innerHTML = '<span class="status-dot"></span> API offline';
  }
}

async function checkCapabilities(url) {
  capabilityController?.abort();
  if (!isValidUrl(url)) {
    capabilityBox.innerHTML = '<div class="capability-placeholder">Enter a valid http(s) URL to see how it will be extracted.</div>';
    return;
  }

  const controller = new AbortController();
  capabilityController = controller;
  capabilityBox.innerHTML = '<div class="capability-placeholder">Checking…</div>';

  try {
    const { response, payload } = await getJson(`/capabilities?url=${encodeURIComponent(url)}`, controller);
    if (!response.ok) throw new Error(errorMessage(payload, response));
    renderCapability(payload);
  } catch (error) {
    if (error.name === 'AbortError') return;
    capabilityBox.innerHTML = `<div class="capability-placeholder">${escapeHtml(friendlyError(error))}</div>`;
  }
}

async function extract() {
  const url = normalizeUrl(urlInput.value);

  if (!isValidUrl(url)) {
    setValidation('Please enter a valid public http(s) URL.', true);
    urlInput.focus();
    return;
  }

  urlInput.value = url;
  setValidation('');
  clearError();

  extractController?.abort();
  const controller = new AbortController();
  extractController = controller;
  setLoading(true);
  resultTitle.textContent = 'Extracting…';
  const started = performance.now();

  try {
    const { response, payload } = await getJson(`/extract?url=${encodeURIComponent(url)}`, controller);
    if (!response.ok) throw new Error(errorMessage(payload, response));
    renderResult(payload, performance.now() - started);
    addRecent(url);
    renderRecent();
  } catch (error) {
    if (error.name === 'AbortError') return;
    resultTitle.textContent = 'Extraction failed';
    showError(friendlyError(error));
  } finally {
    if (extractController === controller) setLoading(false);
  }
}

/* ----------------------------------------------------------- recent URLs */

function loadRecent() {
  try {
    const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    return Array.isArray(parsed) ? parsed.filter((item) => typeof item === 'string') : [];
  } catch {
    return [];
  }
}

function addRecent(url) {
  try {
    const next = [url, ...loadRecent().filter((item) => item !== url)].slice(0, MAX_RECENT);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  } catch {
    // Storage can be unavailable (private mode, quota); history is a convenience only.
  }
}

function useUrl(url) {
  urlInput.value = url;
  setValidation('');
  checkCapabilities(url);
}

function renderRecent() {
  const urls = loadRecent();
  if (!urls.length) {
    recentList.innerHTML = '<div class="recent-empty">No extractions yet.</div>';
    return;
  }
  recentList.innerHTML = urls
    .map((url) => `<button type="button" class="recent-item" data-url="${escapeHtml(url)}">${escapeHtml(url)}</button>`)
    .join('');
  $$('.recent-item').forEach((button) => button.addEventListener('click', () => useUrl(button.dataset.url)));
}

/* ------------------------------------------------------------------- tabs */

function selectTab(name) {
  $$('.tab').forEach((tab) => {
    const active = tab.dataset.tab === name;
    tab.classList.toggle('active', active);
    tab.setAttribute('aria-selected', String(active));
    tab.tabIndex = active ? 0 : -1;
  });
  $$('.tab-panel').forEach((panel) => panel.classList.toggle('active', panel.id === `tab-${name}`));
}

function clearAll() {
  extractController?.abort();
  capabilityController?.abort();
  setLoading(false);
  urlInput.value = '';
  setValidation('');
  clearError();
  capabilityBox.innerHTML = `<div class="capability-placeholder">${CAPABILITY_PLACEHOLDER}</div>`;
  emptyState.classList.remove('hidden');
  resultContent.classList.add('hidden');
  resultTitle.textContent = 'Waiting for extraction';
  copyBtn.disabled = true;
  downloadBtn.disabled = true;
  lastResult = null;
  urlInput.focus();
}

/* ----------------------------------------------------------------- events */

form.addEventListener('submit', (event) => {
  event.preventDefault();
  extract();
});

urlInput.addEventListener('input', () => {
  const value = normalizeUrl(urlInput.value);
  if (!value) {
    setValidation('');
    return;
  }
  if (!isValidUrl(value)) {
    setValidation('Waiting for a valid http(s) URL.', true);
    return;
  }
  setValidation('Looks good. Press Enter to extract.');
});

urlInput.addEventListener('blur', () => {
  const value = normalizeUrl(urlInput.value);
  if (isValidUrl(value)) checkCapabilities(value);
});

clearBtn.addEventListener('click', clearAll);

$$('.example-btn').forEach((button) => {
  button.addEventListener('click', () => {
    useUrl(button.dataset.url);
    setValidation('Looks good. Press Enter to extract.');
  });
});

$$('.tab').forEach((tab) => {
  tab.addEventListener('click', () => selectTab(tab.dataset.tab));
  tab.addEventListener('keydown', (event) => {
    if (event.key !== 'ArrowRight' && event.key !== 'ArrowLeft') return;
    const tabs = $$('.tab');
    const step = event.key === 'ArrowRight' ? 1 : -1;
    const next = tabs[(tabs.indexOf(tab) + step + tabs.length) % tabs.length];
    selectTab(next.dataset.tab);
    next.focus();
  });
});

copyBtn.addEventListener('click', async () => {
  if (!lastResult) return;
  try {
    await navigator.clipboard.writeText(JSON.stringify(lastResult, null, 2));
    copyBtn.textContent = 'Copied';
  } catch {
    copyBtn.textContent = 'Copy failed';
  }
  setTimeout(() => { copyBtn.textContent = 'Copy JSON'; }, 1200);
});

downloadBtn.addEventListener('click', () => {
  if (!lastResult) return;
  const blob = new Blob([JSON.stringify(lastResult, null, 2)], { type: 'application/json' });
  const href = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = href;
  link.download = `extractinator-${lastHost}-${new Date().toISOString().slice(0, 19).replaceAll(':', '-')}.json`;
  link.click();
  URL.revokeObjectURL(href);
});

checkApi();
setInterval(checkApi, 30000);
renderRecent();
