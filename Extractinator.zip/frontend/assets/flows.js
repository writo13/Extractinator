'use strict';

const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const filterInput = $('#filter');
const adminInput = $('#admin-key');
const flowList = $('#flow-list');
const flowCount = $('#flow-count');
const notice = $('#notice');
const emptyDetail = $('#empty-detail');
const detail = $('#detail');
let flows = [];
let selected = null;

adminInput.value = localStorage.getItem('extractinator_admin_key') || '';

function adminHeaders(extra = {}) {
  const key = adminInput.value.trim();
  return key ? {'X-Extractinator-Admin-Key': key, ...extra} : extra;
}
function showNotice(message) { notice.textContent = message; notice.classList.remove('hidden'); }
function clearNotice() { notice.textContent = ''; notice.classList.add('hidden'); }
async function api(path, options={}) {
  const response = await fetch(path, {cache:'no-store', ...options, headers: adminHeaders(options.headers || {})});
  let data = null;
  try { data = await response.json(); } catch {}
  if (!response.ok) throw new Error(data?.error || `HTTP ${response.status}`);
  return data;
}
function statusClass(status, error=false) { if(error)return 'err'; return status ? `s${Math.floor(status/100)}` : ''; }
function fmtMs(v) { return v == null ? '—' : `${Number(v).toFixed(1)} ms`; }
function escapeHtml(v) { return String(v ?? '').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;'); }
function card(k,v){return `<div class="card"><div class="k">${escapeHtml(k)}</div><div class="v">${escapeHtml(v)}</div></div>`}
function kv(obj){return `<div class="kv">${Object.entries(obj).map(([k,v])=>`<div class="key">${escapeHtml(k)}</div><div>${escapeHtml(v)}</div>`).join('')}</div>`}

function renderList() {
  flowCount.textContent = `${flows.length} flow${flows.length===1?'':'s'}`;
  flowList.innerHTML = flows.map(f => `
    <div class="flow-item ${selected?.id===f.id?'active':''}" data-id="${escapeHtml(f.id)}">
      <div class="flow-line"><span class="method">${escapeHtml(f.request?.method||'—')}</span><span class="status ${statusClass(f.status,!!f.error)}">${escapeHtml(f.status || 'ERR')}</span><span class="seq">#${escapeHtml(f.sequence)}</span></div>
      <div class="flow-url">${escapeHtml(f.request?.url||'')}</div>
      <div class="flow-meta">${escapeHtml(f.source||'')} · ${fmtMs(f.duration_ms)}${f.from_cache?' · cache':''}${f.redirects?.length?` · ${f.redirects.length} redirect`:''}</div>
    </div>`).join('') || `<div class="empty" style="min-height:240px">No flows match.</div>`;
  $$('.flow-item').forEach(el => el.addEventListener('click', () => selectFlow(el.dataset.id)));
}

function renderTabs() {
  $$('.tab').forEach(btn => btn.addEventListener('click', () => {
    $$('.tab').forEach(b=>b.classList.remove('active'));
    $$('.tab-body').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    $(`#tab-${btn.dataset.tab}`).classList.add('active');
  }));
}

function renderDetail(f) {
  emptyDetail.classList.add('hidden'); detail.classList.remove('hidden');
  $('#detail-seq').textContent = `FLOW #${f.sequence} · ${f.source}`;
  $('#detail-title').textContent = `${f.request?.method || '—'} ${f.status || 'ERR'}`;
  $('#detail-url').textContent = f.request?.url || '';
  const status = $('#detail-status'); status.textContent = f.status || 'ERR'; status.className = `status-pill ${statusClass(f.status,!!f.error)}`;
  $('#flow-actions').innerHTML = `
    <button id="replay-flow">Replay</button>
    <button id="offline-extract">Offline extract</button>
    <button id="delete-flow">Delete</button>`;
  $('#replay-flow').onclick = () => act(`/flows/${encodeURIComponent(f.id)}/replay`, 'POST', 'Replay complete');
  $('#offline-extract').onclick = async () => {
    try { const data = await api(`/flows/${encodeURIComponent(f.id)}/extract`, {method:'POST'}); renderOffline(data); } catch(e){ showNotice(e.message); }
  };
  $('#delete-flow').onclick = async () => {
    try { await api(`/flows/${encodeURIComponent(f.id)}`, {method:'DELETE'}); selected=null; await load(); } catch(e){ showNotice(e.message); }
  };
  $('#tab-summary').innerHTML = `<div class="grid">
    ${card('State', f.state)}${card('Status', f.status || '—')}${card('Duration', fmtMs(f.duration_ms))}
    ${card('Started', f.started_at)}${card('Cached', f.from_cache?'yes':'no')}${card('Redirects', f.redirects?.length || 0)}
  </div>
  ${f.error ? `<div class="section error"><strong>${escapeHtml(f.error_type||'Error')}</strong><br>${escapeHtml(f.error)}</div>`:''}
  ${f.redirects?.length ? `<div class="section"><div class="section-title">Redirect chain</div>${f.redirects.map(x=>`<div class="card" style="margin-bottom:6px">${escapeHtml(x)}</div>`).join('')}</div>`:''}`;
  $('#tab-request').innerHTML = `<div class="section"><div class="section-title">Request metadata</div>${kv({method:f.request?.method,url:f.request?.url,http_version:f.request?.http_version,body_size:f.request?.body_size||0})}</div><div class="section"><div class="section-title">Headers</div><pre class="mono">${escapeHtml(JSON.stringify(f.request?.headers||{},null,2))}</pre></div><div class="section"><div class="section-title">Body</div><pre class="mono">${escapeHtml(f.request?.body||'(none)')}</pre></div>`;
  $('#tab-response').innerHTML = `<div class="section"><div class="section-title">Response metadata</div>${kv({status:f.response?.status,reason:f.response?.reason,content_type:f.response?.headers?.['Content-Type']||'',body_size:f.response?.body_size||0})}</div><div class="section"><div class="section-title">Headers</div><pre class="mono">${escapeHtml(JSON.stringify(f.response?.headers||{},null,2))}</pre></div><div class="section"><div class="section-title">Body</div><pre class="mono">${escapeHtml(f.response?.body||'(none)')}</pre></div>`;
  const t = f.timing || {};
  $('#tab-timeline').innerHTML = `<div class="grid">${card('Total',fmtMs(t.total_ms))}${card('Send',fmtMs(t.send_ms))}${card('Wait',fmtMs(t.wait_ms))}${card('Receive',fmtMs(t.receive_ms))}${card('DNS',fmtMs(t.dns_ms))}${card('Connect',fmtMs(t.connect_ms))}${card('TLS',fmtMs(t.tls_ms))}</div><div class="section timeline">${(f.events||[]).map(e=>`<div class="event"><div><div class="event-name">${escapeHtml(e.name)}</div><div class="event-time">${escapeHtml(e.at)}</div></div><div>${escapeHtml(e.detail||'')}</div></div>`).join('')}</div>`;
  $('#tab-extraction').innerHTML = f.extraction ? `<pre class="mono">${escapeHtml(JSON.stringify(f.extraction,null,2))}</pre>` : `<div class="empty" style="min-height:180px">No offline extraction stored for this flow.</div>`;
}
function renderOffline(data) { $('#tab-extraction').innerHTML = `<pre class="mono">${escapeHtml(JSON.stringify(data,null,2))}</pre>`; $$('.tab').forEach(b=>b.classList.remove('active')); $$('.tab-body').forEach(b=>b.classList.remove('active')); $('[data-tab="extraction"]').classList.add('active'); $('#tab-extraction').classList.add('active'); }
async function act(path, method, message){ try { const data=await api(path,{method}); showNotice(message); if(data?.status) console.log(data); } catch(e){ showNotice(e.message); } }
function selectFlow(id){ selected=flows.find(f=>f.id===id)||null; renderList(); if(selected) renderDetail(selected); }
async function load(){ clearNotice(); try { const data=await api(`/flows?q=${encodeURIComponent(filterInput.value.trim())}&limit=500`); flows=data.flows||[]; if(selected) selected=flows.find(f=>f.id===selected.id)||null; renderList(); if(selected) renderDetail(selected); } catch(e){ showNotice(e.message); } }

$('#save-key').onclick = () => { localStorage.setItem('extractinator_admin_key', adminInput.value.trim()); showNotice('Admin key saved locally in this browser.'); };
$('#refresh').onclick = load;
$('#select-all').onclick = load;
filterInput.addEventListener('keydown', e => { if(e.key==='Enter') load(); });
$('#clear-flows').onclick = async () => { if(!confirm('Delete all stored flows?')) return; try{await api('/flows',{method:'DELETE'});selected=null;await load();}catch(e){showNotice(e.message)}};
$('#export-har').onclick = async () => { try { const r=await fetch(`/flows/export/har?q=${encodeURIComponent(filterInput.value.trim())}`,{headers:adminHeaders(),cache:'no-store'}); if(!r.ok){const d=await r.json();throw new Error(d.error||`HTTP ${r.status}`)} const blob=await r.blob(); const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='extractinator.har.json';a.click();URL.revokeObjectURL(a.href);}catch(e){showNotice(e.message)} };
$('#import-har').addEventListener('change', async e => { const file=e.target.files[0]; if(!file)return; const fd=new FormData();fd.append('file',file);try{const data=await api('/flows/import/har',{method:'POST',body:fd,headers:{}});showNotice(`Imported ${data.imported} flow(s).`);await load();}catch(err){showNotice(err.message)}e.target.value=''; });
renderTabs();
load();
