(() => {
  const root = document.documentElement;
  const stored = localStorage.getItem('extractinator-theme');
  const prefersDark = window.matchMedia?.('(prefers-color-scheme: dark)').matches;
  const initial = stored || (prefersDark ? 'dark' : 'light');

  function applyTheme(theme) {
    root.dataset.theme = theme;
    const dark = theme === 'dark';
    document.querySelectorAll('[data-theme-label]').forEach((el) => {
      el.textContent = dark ? 'Light' : 'Dark';
    });
    document.querySelectorAll('#theme-toggle').forEach((button) => {
      button.setAttribute('aria-pressed', dark ? 'true' : 'false');
      button.setAttribute('aria-label', dark ? 'Switch to light mode' : 'Switch to dark mode');
      const icon = button.querySelector('.theme-icon');
      const label = button.querySelector('.theme-label');
      if (icon) icon.textContent = dark ? '☀' : '☾';
      if (label) label.textContent = dark ? 'Light' : 'Dark';
    });
  }

  applyTheme(initial);

  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('#theme-toggle').forEach((button) => {
      button.addEventListener('click', () => {
        const next = root.dataset.theme === 'dark' ? 'light' : 'dark';
        localStorage.setItem('extractinator-theme', next);
        applyTheme(next);
      });
    });
  });
})();
