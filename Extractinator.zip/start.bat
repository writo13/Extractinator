@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo Creating virtual environment...
    python -m venv .venv
    if errorlevel 1 goto :fail
)

call ".venv\Scripts\activate.bat"
python -m pip install -q -r requirements.txt
if errorlevel 1 goto :fail

echo.
echo Starting Extractinator...
echo Default address: http://127.0.0.1:8000/   (API docs: /docs)
echo Settings can be changed with EXTRACTINATOR_* environment variables, see README.md.
echo.
python run.py
if errorlevel 1 goto :fail
exit /b 0

:fail
echo.
echo Something went wrong. See the messages above.
pause
exit /b 1
