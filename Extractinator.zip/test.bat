@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo Creating virtual environment...
    python -m venv .venv
    if errorlevel 1 goto :fail
)

call ".venv\Scripts\activate.bat"
python -m pip install -q -r requirements-dev.txt
if errorlevel 1 goto :fail

python -m pytest -q
set RESULT=%errorlevel%
if not "%~1"=="--no-pause" pause
exit /b %RESULT%

:fail
echo.
echo Setup failed. See the messages above.
if not "%~1"=="--no-pause" pause
exit /b 1
