import pytest

from extractinator.core.exceptions import RobotsDisallowed

from conftest import Resp


def robots(site, text, **kwargs):
    site.add("/robots.txt", Resp(body=text, content_type="text/plain", **kwargs))


def test_disallowed_path_is_never_requested(site, make_fetcher):
    robots(site, "User-agent: *\nDisallow: /private\n")
    site.add("/private/x", "<p>secret</p>")
    site.add("/public", "<p>ok</p>")
    fetcher = make_fetcher(respect_robots=True)
    with pytest.raises(RobotsDisallowed):
        fetcher.fetch(site.url("/private/x"))
    assert "ok" in fetcher.fetch(site.url("/public")).text
    assert site.count("/private/x") == 0


def test_wildcard_and_end_anchor_rules_are_honoured(site, make_fetcher):
    # Python's urllib.robotparser ignores `*` and `$`, so it would allow all of these.
    robots(site, "User-agent: *\nDisallow: /*?action=\nDisallow: /*.pdf$\n")
    for path in ("/page?action=edit", "/doc.pdf", "/page", "/doc.pdf.html"):
        site.add(path, "<p>x</p>")
    fetcher = make_fetcher(respect_robots=True)
    for blocked in ("/page?action=edit", "/doc.pdf"):
        with pytest.raises(RobotsDisallowed):
            fetcher.fetch(site.url(blocked))
    fetcher.fetch(site.url("/page"))
    fetcher.fetch(site.url("/doc.pdf.html"))


def test_group_for_our_own_user_agent_wins(site, make_fetcher):
    robots(site, "User-agent: *\nDisallow:\n\nUser-agent: Extractinator\nDisallow: /\n")
    site.add("/p", "<p>x</p>")
    with pytest.raises(RobotsDisallowed):
        make_fetcher(respect_robots=True).fetch(site.url("/p"))


def test_missing_robots_txt_allows_everything(site, make_fetcher):
    site.add("/p", "<p>x</p>")  # /robots.txt -> 404
    assert make_fetcher(respect_robots=True).fetch(site.url("/p")).status_code == 200


def test_unreachable_robots_txt_means_disallow_all(site, make_fetcher):
    # Regression: a 5xx robots.txt used to be treated as "no rules".
    site.add("/robots.txt", Resp(status=503))
    site.add("/p", "<p>x</p>")
    with pytest.raises(RobotsDisallowed, match="could not be retrieved"):
        make_fetcher(respect_robots=True).fetch(site.url("/p"))
    assert site.count("/p") == 0


def test_robots_txt_redirect_is_followed(site, make_fetcher):
    # Regression: redirects were not followed, so the rules were silently ignored.
    site.redirect("/robots.txt", "/real-robots.txt")
    site.add("/real-robots.txt", Resp(body="User-agent: *\nDisallow: /p\n", content_type="text/plain"))
    site.add("/p", "<p>x</p>")
    with pytest.raises(RobotsDisallowed):
        make_fetcher(respect_robots=True).fetch(site.url("/p"))


def test_robots_txt_is_cached(site, make_fetcher):
    robots(site, "User-agent: *\nDisallow:\n")
    site.add("/a", "<p>a</p>")
    site.add("/b", "<p>b</p>")
    fetcher = make_fetcher(respect_robots=True)
    fetcher.fetch(site.url("/a"))
    fetcher.fetch(site.url("/b"))
    assert site.count("/robots.txt") == 1


def test_robots_failure_is_retried_after_a_few_minutes(site, make_fetcher, clock):
    site.add("/robots.txt", Resp(status=503))
    site.add("/p", "<p>x</p>")
    fetcher = make_fetcher(respect_robots=True, retries=0, clock=clock, sleep=clock.sleep)
    with pytest.raises(RobotsDisallowed):
        fetcher.fetch(site.url("/p"))
    robots(site, "User-agent: *\nDisallow:\n")  # the site recovers
    clock.now += 301
    assert fetcher.fetch(site.url("/p")).status_code == 200


def test_robots_rules_expire(site, make_fetcher, clock):
    robots(site, "User-agent: *\nDisallow:\n")
    site.add("/p", "<p>x</p>")
    fetcher = make_fetcher(respect_robots=True, cache_ttl=0, clock=clock, sleep=clock.sleep)
    fetcher.fetch(site.url("/p"))
    robots(site, "User-agent: *\nDisallow: /\n")
    clock.now += 24 * 3600 + 1
    with pytest.raises(RobotsDisallowed):
        fetcher.fetch(site.url("/p"))


def test_crawl_delay_is_honoured(site, make_fetcher, clock):
    robots(site, "User-agent: *\nCrawl-delay: 3\n")
    site.add("/a", "<p>a</p>")
    site.add("/b", "<p>b</p>")
    fetcher = make_fetcher(respect_robots=True, delay=0.5, clock=clock, sleep=clock.sleep)
    fetcher.fetch(site.url("/a"))
    fetcher.fetch(site.url("/b"))
    assert max(clock.sleeps) == pytest.approx(3.0)


def test_crawl_delay_is_capped(site, make_fetcher, clock):
    robots(site, "User-agent: *\nCrawl-delay: 600\n")
    site.add("/a", "<p>a</p>")
    site.add("/b", "<p>b</p>")
    fetcher = make_fetcher(respect_robots=True, clock=clock, sleep=clock.sleep)
    fetcher.fetch(site.url("/a"))
    fetcher.fetch(site.url("/b"))
    assert max(clock.sleeps) == pytest.approx(10.0)


def test_robots_can_be_switched_off_in_code(site, make_fetcher):
    robots(site, "User-agent: *\nDisallow: /\n")
    site.add("/p", "<p>x</p>")
    make_fetcher(respect_robots=False).fetch(site.url("/p"))
    assert site.count("/robots.txt") == 0
