import pytest
from fastapi.testclient import TestClient

from extractinator import __version__
from extractinator.api import create_app
from extractinator.core import exceptions as exc
from extractinator.core.config import Settings
from extractinator.core.fetcher import Fetcher
from extractinator.core.models import ExtractionResult
from extractinator.service import ExtractinatorService


class FakeService:
    class Registry:
        def names(self):
            return ["books_to_scrape"]

        def find(self, url):
            return None

    registry = Registry()

    def capabilities(self, url):
        return {
            "url": url,
            "adapter": None,
            "generic_extractors": ["jsonld", "metadata", "generic_html"],
        }

    def extract(self, url):
        return ExtractionResult(
            url=url,
            type="webpage",
            data={"hello": "world"},
            method="generic_html",
        )


def test_dashboard():
    client = TestClient(create_app(FakeService()))
    response = client.get("/")
    assert response.status_code == 200
    assert "Extractinator" in response.text


def test_frontend_assets():
    client = TestClient(create_app(FakeService()))
    css = client.get("/assets/styles.css")
    js = client.get("/assets/app.js")
    assert css.status_code == 200
    assert ":root" in css.text
    assert js.status_code == 200
    assert "checkApi" in js.text


def test_health():
    client = TestClient(create_app(FakeService()))
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_adapters():
    client = TestClient(create_app(FakeService()))
    response = client.get("/adapters")
    assert response.status_code == 200
    assert response.json()["adapters"] == ["books_to_scrape"]


def test_capabilities():
    client = TestClient(create_app(FakeService()))
    response = client.get("/capabilities", params={"url": "https://example.com"})
    assert response.status_code == 200
    assert response.json()["generic_extractors"] == ["jsonld", "metadata", "generic_html"]


def test_extract():
    client = TestClient(create_app(FakeService()))
    response = client.get("/extract", params={"url": "https://example.com"})
    assert response.status_code == 200
    body = response.json()
    assert body["data"]["hello"] == "world"


def test_extract_post():
    client = TestClient(create_app(FakeService()))
    response = client.post("/extract", json={"url": "https://example.com"})
    assert response.status_code == 200
    assert response.json()["data"]["hello"] == "world"


# ------------------------------------------------------------ error handling
class FailingService(FakeService):
    def __init__(self, error):
        self.error = error

    def extract(self, url):
        raise self.error


ERRORS = [
    (exc.URLNotAllowed("bad url"), 400),
    (exc.RobotsDisallowed("blocked"), 403),
    (exc.UpstreamError("HTTP 404", 404), 404),
    (exc.UpstreamError("HTTP 410", 410), 404),
    (exc.UpstreamError("HTTP 403", 403), 502),
    (exc.ResponseTooLarge("big"), 413),
    (exc.UnsupportedContentType("image/png"), 415),
    (exc.ExtractionError("cannot parse"), 422),
    (exc.NetworkError("down"), 502),
    (exc.FetchTimeout("slow"), 504),
]


@pytest.mark.parametrize("error,status", ERRORS, ids=lambda v: getattr(v, "__class__", v).__name__ if not isinstance(v, int) else str(v))
@pytest.mark.parametrize("method", ["get", "post"])
def test_errors_map_to_http_statuses_with_one_consistent_body(error, status, method):
    client = TestClient(create_app(FailingService(error)))
    url = "https://example.com"
    response = client.get("/extract", params={"url": url}) if method == "get" else client.post("/extract", json={"url": url})
    assert response.status_code == status
    assert response.json() == {"error": str(error), "type": type(error).__name__}


def test_unexpected_errors_return_a_generic_500():
    client = TestClient(create_app(FailingService(RuntimeError("secret internals"))), raise_server_exceptions=False)
    response = client.get("/extract", params={"url": "https://example.com"})
    assert response.status_code == 500
    assert response.json() == {"error": "unexpected internal error", "type": "InternalServerError"}
    assert "secret" not in response.text


def test_request_validation_errors_use_the_same_body_shape():
    client = TestClient(create_app(FakeService()))
    short = client.get("/extract", params={"url": "x"})
    missing = client.post("/extract", json={})
    for response in (short, missing):
        assert response.status_code == 422
        assert response.json()["type"] == "ValidationError"
        assert "url" in response.json()["error"]


def test_capabilities_rejects_private_urls_with_the_standard_error_body():
    service = ExtractinatorService(fetcher=Fetcher(), settings=Settings())
    client = TestClient(create_app(service))
    response = client.get("/capabilities", params={"url": "http://127.0.0.1:8000/"})
    assert response.status_code == 400
    assert response.json()["type"] == "URLNotAllowed"
    ok = client.get("/capabilities", params={"url": "https://books.toscrape.com/"})
    assert ok.status_code == 200 and ok.json()["adapter"] == "books_to_scrape"


def test_version_is_single_sourced():
    client = TestClient(create_app(FakeService()))
    assert client.get("/health").json()["version"] == __version__
    assert client.get("/openapi.json").json()["info"]["version"] == __version__


def test_extract_response_includes_provenance_fields():
    client = TestClient(create_app(FakeService()))
    source = client.get("/extract", params={"url": "https://example.com"}).json()["source"]
    assert source["requested_url"] == "https://example.com"
    assert source["cached"] is False


def test_dashboard_gets_security_headers_but_swagger_does_not():
    client = TestClient(create_app(FakeService()))
    for path in ("/", "/assets/app.js"):
        headers = client.get(path).headers
        assert "default-src 'self'" in headers["content-security-policy"]
        assert headers["x-content-type-options"] == "nosniff"
    assert "content-security-policy" not in client.get("/docs").headers


def test_head_requests_work_for_uptime_monitors():
    client = TestClient(create_app(FakeService()))
    assert client.head("/health").status_code == 200
    assert client.head("/").status_code == 200
