import pytest

from extractinator import __version__
from extractinator.core.config import Settings


def test_defaults():
    s = Settings.from_env({})
    assert s.delay == 0.5 and s.port == 8000 and s.host == "127.0.0.1"
    assert s.user_agent == f"Extractinator/{__version__}"


def test_environment_overrides_with_type_conversion():
    s = Settings.from_env(
        {
            "EXTRACTINATOR_DELAY": "2.5",
            "EXTRACTINATOR_RETRIES": "5",
            "EXTRACTINATOR_PORT": "9001",
            "EXTRACTINATOR_USER_AGENT": "  MyBot/1.0 (+mailto:me@example.com) ",
        }
    )
    assert (s.delay, s.retries, s.port) == (2.5, 5, 9001)
    assert s.user_agent == "MyBot/1.0 (+mailto:me@example.com)"


def test_blank_values_are_ignored():
    assert Settings.from_env({"EXTRACTINATOR_DELAY": "  "}).delay == 0.5


def test_invalid_values_fail_loudly():
    with pytest.raises(ValueError, match="EXTRACTINATOR_PORT"):
        Settings.from_env({"EXTRACTINATOR_PORT": "eighty"})


def test_robots_handling_cannot_be_disabled_from_the_environment():
    assert "respect_robots" not in Settings.__dataclass_fields__
