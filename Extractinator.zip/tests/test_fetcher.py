import pytest

from extractinator.core.exceptions import (
    FetchError,
    FetchTimeout,
    NetworkError,
    ResponseTooLarge,
    UnsupportedContentType,
    UpstreamError,
    URLNotAllowed,
)
from extractinator.core.fetcher import Fetcher
from extractinator.core.policy import URLPolicy

from conftest import Resp


def test_policy_rejects_localhost():
    with pytest.raises(URLNotAllowed):
        URLPolicy().validate("http://127.0.0.1:8000/")


def test_policy_rejects_non_http():
    with pytest.raises(URLNotAllowed):
        URLPolicy().validate("ftp://example.com/file")


def test_fetcher_can_construct():
    fetcher = Fetcher(respect_robots=False, delay=0)
    assert fetcher.user_agent.startswith("Extractinator/")


def test_basic_fetch(site, make_fetcher):
    site.add("/p", "<html><body><p>hi</p></body></html>")
    result = make_fetcher().fetch(site.url("/p"))
    assert result.status_code == 200
    assert result.content_type == "text/html"
    assert "<p>hi</p>" in result.text
    assert result.redirected_from is None and result.from_cache is False


def test_utf8_page_without_charset_is_not_mojibake(site, make_fetcher):
    # Regression: `requests` assumes ISO-8859-1 for text/* without a charset ("Â£").
    site.add("/p", Resp(body="<p>Café £51.77</p>".encode("utf-8"), content_type="text/html"))
    assert "Café £51.77" in make_fetcher().fetch(site.url("/p")).text


def test_declared_charset_is_used(site, make_fetcher):
    site.add("/p", Resp(body=b"<p>caf\xe9</p>", content_type="text/html; charset=iso-8859-1"))
    assert "café" in make_fetcher().fetch(site.url("/p")).text


def test_gzip_is_decoded(site, make_fetcher):
    site.add("/p", Resp(body="<p>zipped</p>", gzip=True))
    assert "zipped" in make_fetcher().fetch(site.url("/p")).text


# ------------------------------------------------------------------ redirects
def test_redirect_chain_longer_than_retry_budget(site, make_fetcher):
    # Regression: every redirect hop used to consume one retry attempt.
    for i in range(4):
        site.redirect(f"/r{i}", f"/r{i + 1}")
    site.add("/r4", "<p>arrived</p>")
    result = make_fetcher(retries=1).fetch(site.url("/r0"))
    assert result.url == site.url("/r4")
    assert result.redirected_from == site.url("/r0")
    assert result.requested_url == site.url("/r0")


def test_too_many_redirects(site, make_fetcher):
    for i in range(10):
        site.redirect(f"/r{i}", f"/r{i + 1}")
    with pytest.raises(FetchError, match="Maximum redirect"):
        make_fetcher().fetch(site.url("/r0"))


def test_redirect_loop(site, make_fetcher):
    site.redirect("/loop", "/loop")
    with pytest.raises(FetchError, match="loop"):
        make_fetcher().fetch(site.url("/loop"))


def test_redirect_to_private_address_is_blocked(site, make_fetcher):
    site.redirect("/evil", "http://169.254.169.254/latest/meta-data/")
    with pytest.raises(URLNotAllowed):
        make_fetcher().fetch(site.url("/evil"))


def test_redirect_to_non_http_scheme_is_blocked(site, make_fetcher):
    site.redirect("/evil", "file:///etc/passwd")
    with pytest.raises(URLNotAllowed):
        make_fetcher().fetch(site.url("/evil"))


def test_redirect_without_location(site, make_fetcher):
    site.add("/r", Resp(status=302, content_type=None))
    with pytest.raises(FetchError, match="Location"):
        make_fetcher().fetch(site.url("/r"))


# -------------------------------------------------------------- errors, retries
def test_retries_temporary_errors_with_exponential_backoff(site, make_fetcher, clock):
    site.add("/flaky", Resp(status=503), Resp(status=503), Resp(body="<p>ok</p>"))
    fetcher = make_fetcher(retries=2, backoff=1.0, clock=clock, sleep=clock.sleep)
    assert "ok" in fetcher.fetch(site.url("/flaky")).text
    assert clock.sleeps == [1.0, 2.0]
    assert site.count("/flaky") == 3


def test_gives_up_after_retries(site, make_fetcher):
    site.add("/down", Resp(status=503))
    with pytest.raises(UpstreamError) as info:
        make_fetcher(retries=2).fetch(site.url("/down"))
    assert site.count("/down") == 3
    assert info.value.upstream_status == 503 and info.value.status_code == 502


def test_retry_after_header_is_respected(site, make_fetcher, clock):
    site.add("/slow", Resp(status=429, headers={"Retry-After": "2"}), Resp(body="<p>ok</p>"))
    make_fetcher(clock=clock, sleep=clock.sleep).fetch(site.url("/slow"))
    assert clock.sleeps == [2]


def test_404_is_not_retried_and_maps_to_404(site, make_fetcher):
    with pytest.raises(UpstreamError) as info:
        make_fetcher().fetch(site.url("/missing"))
    assert site.count("/missing") == 1
    assert info.value.upstream_status == 404 and info.value.status_code == 404


def test_other_client_errors_are_not_retried(site, make_fetcher):
    site.add("/nope", Resp(status=403))
    with pytest.raises(UpstreamError) as info:
        make_fetcher().fetch(site.url("/nope"))
    assert site.count("/nope") == 1 and info.value.status_code == 502


def test_unsupported_content_type(site, make_fetcher):
    site.add("/img", Resp(body=b"\x89PNG", content_type="image/png"))
    with pytest.raises(UnsupportedContentType):
        make_fetcher().fetch(site.url("/img"))


def test_response_too_large_by_content_length(site, make_fetcher):
    site.add("/big", "x" * 5000)
    with pytest.raises(ResponseTooLarge):
        make_fetcher(max_bytes=1000).fetch(site.url("/big"))


def test_response_too_large_while_streaming(site, make_fetcher):
    site.add("/big", Resp(body="x" * 5000, content_length=False))
    with pytest.raises(ResponseTooLarge):
        make_fetcher(max_bytes=1000).fetch(site.url("/big"))


def test_gzip_bomb_is_limited_by_decompressed_size(site, make_fetcher):
    site.add("/bomb", Resp(body="a" * 500_000, gzip=True))
    with pytest.raises(ResponseTooLarge):
        make_fetcher(max_bytes=10_000).fetch(site.url("/bomb"))


def test_timeout(site, make_fetcher):
    site.add("/slow", Resp(body="<p>late</p>", delay=1.0))
    with pytest.raises(FetchTimeout):
        make_fetcher(timeout=0.2, retries=0).fetch(site.url("/slow"))


def test_connection_refused(site, make_fetcher):
    url = site.url("/p")
    site.close()
    with pytest.raises(NetworkError):
        make_fetcher(retries=0).fetch(url)


def test_policy_runs_before_any_network_access(make_fetcher):
    with pytest.raises(URLNotAllowed):
        make_fetcher().fetch("http://10.0.0.1/")


# ---------------------------------------------------------------------- cache
def test_cache_hit_skips_the_network(site, make_fetcher):
    site.add("/p", "<p>x</p>")
    fetcher = make_fetcher()
    first = fetcher.fetch(site.url("/p"))
    second = fetcher.fetch(site.url("/p"))
    assert site.count("/p") == 1
    assert first.from_cache is False and second.from_cache is True


def test_cache_expires(site, make_fetcher, clock):
    site.add("/p", "<p>x</p>")
    fetcher = make_fetcher(cache_ttl=60, clock=clock, sleep=clock.sleep)
    fetcher.fetch(site.url("/p"))
    clock.now += 61
    assert fetcher.fetch(site.url("/p")).from_cache is False
    assert site.count("/p") == 2


def test_cache_is_bounded_and_least_recently_used(site, make_fetcher):
    for name in "abc":
        site.add(f"/{name}", f"<p>{name}</p>")
    fetcher = make_fetcher(cache_max_entries=2)
    fetcher.fetch(site.url("/a"))
    fetcher.fetch(site.url("/b"))
    fetcher.fetch(site.url("/a"))  # refreshes /a, so /b is now the oldest
    fetcher.fetch(site.url("/c"))  # evicts /b
    fetcher.fetch(site.url("/a"))
    fetcher.fetch(site.url("/b"))
    assert (site.count("/a"), site.count("/b"), site.count("/c")) == (1, 2, 1)


# ------------------------------------------------------------------- throttle
def test_requests_to_one_host_are_spaced_by_the_delay(site, make_fetcher, clock):
    site.add("/a", "<p>a</p>")
    site.add("/b", "<p>b</p>")
    fetcher = make_fetcher(delay=1.0, clock=clock, sleep=clock.sleep)
    fetcher.fetch(site.url("/a"))
    fetcher.fetch(site.url("/b"))
    assert clock.sleeps == [1.0]


def test_throttle_never_sleeps_while_holding_the_lock(site, make_fetcher, clock):
    # Regression: sleeping under the lock stalled requests to every other host.
    site.add("/a", "<p>a</p>")
    site.add("/b", "<p>b</p>")
    fetcher = make_fetcher(delay=1.0, clock=clock, sleep=clock.sleep)

    def checked_sleep(seconds):
        assert fetcher._lock.acquire(blocking=False), "slept while holding the lock"
        fetcher._lock.release()
        clock.sleep(seconds)

    fetcher._sleep = checked_sleep
    fetcher.fetch(site.url("/a"))
    fetcher.fetch(site.url("/b"))
    assert clock.sleeps == [1.0]


# -------------------------------------------------------------------- cookies
def test_cookies_are_never_stored_or_replayed(site, make_fetcher):
    # A shared Session would replay one caller's cookies to the next caller.
    site.add("/a", Resp(body="<p>a</p>", headers={"Set-Cookie": "sid=abc; Path=/"}))
    site.add("/b", "<p>b</p>")
    fetcher = make_fetcher()
    fetcher.fetch(site.url("/a"))
    fetcher.fetch(site.url("/b"))
    assert all("cookie" not in headers for headers in site.request_headers)
    assert len(fetcher.session.cookies) == 0
