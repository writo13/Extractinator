import socket

import pytest

from extractinator.core.exceptions import URLNotAllowed
from extractinator.core.policy import URLPolicy

BLOCKED = [
    "http://127.0.0.1:8000/",
    "http://127.0.0.1/",
    "http://[::1]/",
    "http://10.0.0.5/",
    "http://192.168.1.1/",
    "http://169.254.169.254/latest/meta-data/",
    "http://100.64.0.1/",          # carrier-grade NAT, also Tailscale
    "http://198.18.0.1/",
    "http://0.0.0.0/",
    "http://224.0.0.1/",
    "http://[::ffff:127.0.0.1]/",  # IPv4 smuggled inside IPv6
    "http://[::ffff:7f00:1]/",
    "http://[::ffff:10.0.0.1]/",
    "http://[64:ff9b::a00:1]/",    # NAT64 wrapping 10.0.0.1
    "http://[2002:7f00:1::]/",     # 6to4 wrapping 127.0.0.1
    "http://localhost/",
    "http://localhost./",
    "http://app.localhost/",
    "http://printer.local/",
    "http://db.internal/",
    "ftp://example.com/file",
    "file:///etc/passwd",
    "http://user:pw@8.8.8.8/",
    "http://8.8.8.8:8080/",
    "http://8.8.8.8:0/",
    "http://example.com:abc/",     # used to crash with ValueError
    "http://example.com:99999/",
    "http:///path",
    "http://[::1/",
]

ALLOWED = [
    "http://8.8.8.8/",
    "https://8.8.8.8:443/",
    "https://[2606:4700:4700::1111]/",
]


@pytest.mark.parametrize("url", BLOCKED)
def test_blocked(url):
    with pytest.raises(URLNotAllowed):
        URLPolicy().validate(url)


@pytest.mark.parametrize("url", ALLOWED)
def test_allowed(url):
    URLPolicy().validate(url)


def test_resolve_false_skips_dns(monkeypatch):
    def boom(*args, **kwargs):
        raise AssertionError("DNS must not be used")

    monkeypatch.setattr(socket, "getaddrinfo", boom)
    URLPolicy().validate("https://example.com/", resolve=False)


def _fake_dns(monkeypatch, *addresses):
    infos = [(socket.AF_INET, socket.SOCK_STREAM, 6, "", (a, 0)) for a in addresses]
    monkeypatch.setattr(socket, "getaddrinfo", lambda *a, **k: infos)


def test_hostname_resolving_to_private_address_is_blocked(monkeypatch):
    _fake_dns(monkeypatch, "10.1.2.3")
    with pytest.raises(URLNotAllowed):
        URLPolicy().validate("https://innocent.test/")


def test_any_private_answer_blocks_the_host(monkeypatch):
    _fake_dns(monkeypatch, "8.8.8.8", "127.0.0.1")
    with pytest.raises(URLNotAllowed):
        URLPolicy().validate("https://mixed.test/")


def test_hostname_resolving_to_public_address_is_allowed(monkeypatch):
    _fake_dns(monkeypatch, "8.8.8.8")
    URLPolicy().validate("https://public.test/")


def test_unresolvable_host_is_rejected(monkeypatch):
    def fail(*args, **kwargs):
        raise socket.gaierror("nope")

    monkeypatch.setattr(socket, "getaddrinfo", fail)
    with pytest.raises(URLNotAllowed):
        URLPolicy().validate("https://nope.test/")
