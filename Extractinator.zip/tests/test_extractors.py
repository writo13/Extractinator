from pathlib import Path

import pytest
from bs4 import BeautifulSoup

from extractinator.core.exceptions import ExtractionError
from extractinator.extractors.json_data import extract_json, extract_plain_text

from extractinator.extractors.generic import extract_generic
from extractinator.extractors.jsonld import extract_jsonld
from extractinator.extractors.metadata import extract_metadata

FIXTURES = Path(__file__).parent / "fixtures"


def test_jsonld_article_is_extracted():
    html = (FIXTURES / "generic_article.html").read_text(encoding="utf-8")
    soup = BeautifulSoup(html, "html.parser")
    records = extract_jsonld(soup)
    assert records
    assert records[0]["_normalized_type"] == "article"


def test_metadata():
    html = (FIXTURES / "generic_article.html").read_text(encoding="utf-8")
    soup = BeautifulSoup(html, "html.parser")
    metadata = extract_metadata(soup)
    assert metadata["title"] == "Example Article"
    assert metadata["author"] == "Jane Doe"


def test_generic_prefers_jsonld():
    html = (FIXTURES / "generic_article.html").read_text(encoding="utf-8")
    record_type, data, method = extract_generic(
        html,
        "https://example.com/article",
    )
    assert record_type == "article"
    assert method == "jsonld"
    assert data["structured_data"]["headline"] == "Example Article"


# ------------------------------------------------------------------- json-ld
def _jsonld(payload):
    return f'<html><head><script type="application/ld+json">{payload}</script></head><body></body></html>'


def test_jsonld_prefers_the_specific_entity_over_organization():
    # Regression: the first "known" record won, so Organization beat Product.
    html = _jsonld('[{"@type":"Organization","name":"Shop Inc"},{"@type":"Product","name":"Widget"}]')
    record_type, data, method = extract_generic(html, "https://shop.test/p")
    assert record_type == "product" and method == "jsonld"
    assert data["structured_data"]["name"] == "Widget"


def test_jsonld_full_schema_org_urls_are_normalised():
    record_type, _, _ = extract_generic(_jsonld('{"@type":"https://schema.org/Article","headline":"H"}'), "https://x.test/")
    assert record_type == "article"


def test_jsonld_graph_inside_a_list():
    html = _jsonld('[{"@graph":[{"@type":"WebPage","name":"w"},{"@type":"Recipe","name":"Soup"}]}]')
    assert extract_generic(html, "https://x.test/")[0] == "recipe"


def test_jsonld_ties_prefer_the_richer_record():
    html = _jsonld('[{"@type":"Article","headline":"a"},{"@type":"Article","headline":"b","author":"x","datePublished":"d"}]')
    assert extract_generic(html, "https://x.test/")[1]["structured_data"]["headline"] == "b"


def test_broken_jsonld_is_ignored():
    html = _jsonld("{not json")
    assert extract_generic(html, "https://x.test/")[2] == "generic_html"


# ------------------------------------------------------------------ metadata
def test_metadata_is_case_insensitive_with_twitter_fallbacks():
    soup = BeautifulSoup(
        '<html lang="en-GB"><head><meta name="Description" content="d">'
        '<meta name="twitter:title" content="T"><meta name="twitter:image" content="/i.png">'
        '<link rel="canonical" href="/canon"></head></html>',
        "html.parser",
    )
    meta = extract_metadata(soup, "https://example.com/a/b")
    assert meta["description"] == "d"
    assert meta["title"] == "T"
    assert meta["canonical"] == "https://example.com/canon"
    assert meta["images"] == ["/i.png"]
    assert meta["language"] == "en-GB"


# ---------------------------------------------------------------------- html
def _html(body):
    return extract_generic(f"<html><body>{body}</body></html>", "https://x.test/dir/")[1]["content"]


def test_a_lone_article_is_the_content_root():
    content = _html("<p>nav</p><article><h1>T</h1><p>body</p></article><p>footer</p>")
    assert content["paragraphs"] == ["body"]


def test_many_articles_do_not_hide_the_rest_of_the_page():
    content = _html("<article><p>one</p></article><article><p>two</p></article>")
    assert content["paragraphs"] == ["one", "two"]


def test_main_is_preferred_over_the_whole_document():
    content = _html("<p>nav</p><main><p>core</p></main><p>footer</p>")
    assert content["paragraphs"] == ["core"]


def test_links_are_cleaned_and_deduplicated():
    content = _html(
        '<a href="/a">A</a><a href="/a">A</a><a href="#top">top</a>'
        '<a href="javascript:void(0)">js</a><a href="mailto:me@x.test">mail</a><a href="rel">R</a>'
    )
    assert [l["url"] for l in content["links"]] == ["https://x.test/a", "mailto:me@x.test", "https://x.test/dir/rel"]


def test_images_skip_inline_data_and_use_lazy_sources():
    content = _html('<img src="data:image/gif;base64,AAAA"><img data-src="/lazy.png" alt="L"><img src="/n.png">')
    assert [i["url"] for i in content["images"]] == ["https://x.test/lazy.png", "https://x.test/n.png"]


def test_counts_report_totals_even_when_lists_are_truncated():
    content = _html("".join(f'<a href="/p{i}">p{i}</a>' for i in range(150)))
    assert len(content["links"]) == 100
    assert content["counts"]["links"] == 150


# ---------------------------------------------------------------- json / text
def test_json_documents_are_returned_as_is():
    record_type, data, method = extract_json('{"a": [1, 2]}')
    assert (record_type, method) == ("json", "json")
    assert data["content"] == {"a": [1, 2]}


def test_invalid_json_is_an_extraction_error():
    with pytest.raises(ExtractionError, match="not valid JSON"):
        extract_json("{oops")


def test_plain_text():
    record_type, data, method = extract_plain_text("a\nb")
    assert (record_type, method) == ("text", "plain_text")
    assert data["content"] == {"text": "a\nb", "lines": 2}
