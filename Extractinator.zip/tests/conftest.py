from __future__ import annotations

import gzip as gzip_module
import threading
import time
from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

import pytest

from extractinator.core.fetcher import Fetcher
from extractinator.core.policy import URLPolicy


@dataclass
class Resp:
    """One canned HTTP response."""

    body: bytes | str = b""
    status: int = 200
    content_type: str | None = "text/html"
    headers: dict = field(default_factory=dict)
    gzip: bool = False
    content_length: bool = True
    delay: float = 0.0

    def payload(self) -> bytes:
        data = self.body.encode("utf-8") if isinstance(self.body, str) else self.body
        return gzip_module.compress(data) if self.gzip else data


class Site:
    """A real HTTP server on 127.0.0.1 so the fetcher is tested with the real `requests` stack."""

    def __init__(self):
        self.routes: dict[str, list[Resp]] = {}
        self.hits: list[str] = []
        self.request_headers: list[dict[str, str]] = []
        self._lock = threading.Lock()
        self._closed = False
        site = self

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):  # noqa: N802
                site._serve(self)

            def log_message(self, *args):
                pass

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.server.daemon_threads = True
        threading.Thread(
            target=self.server.serve_forever, kwargs={"poll_interval": 0.01}, daemon=True
        ).start()
        self.port = self.server.server_address[1]
        self.base = f"http://127.0.0.1:{self.port}"

    def url(self, path: str = "/") -> str:
        return self.base + path

    def add(self, path: str, *responses: Resp | str | bytes) -> None:
        """Responses are served in order; the last one repeats forever."""
        queue = responses or (Resp(),)
        self.routes[path] = [r if isinstance(r, Resp) else Resp(body=r) for r in queue]

    def redirect(self, path: str, to: str, status: int = 301) -> None:
        self.add(path, Resp(status=status, content_type=None, headers={"Location": to}))

    def count(self, path: str) -> int:
        return self.hits.count(path)

    def _serve(self, handler: BaseHTTPRequestHandler) -> None:
        with self._lock:
            self.hits.append(handler.path)
            self.request_headers.append({k.lower(): v for k, v in handler.headers.items()})
            queue = self.routes.get(handler.path)
            if queue is None:
                resp = Resp(body=b"not found", status=404, content_type="text/plain")
            else:
                resp = queue.pop(0) if len(queue) > 1 else queue[0]

        if resp.delay:
            time.sleep(resp.delay)
        body = resp.payload()
        try:
            handler.send_response(resp.status)
            if resp.content_type:
                handler.send_header("Content-Type", resp.content_type)
            if resp.gzip:
                handler.send_header("Content-Encoding", "gzip")
            for name, value in resp.headers.items():
                handler.send_header(name, value)
            if resp.content_length:
                handler.send_header("Content-Length", str(len(body)))
            handler.end_headers()
            handler.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def close(self) -> None:
        if not self._closed:
            self._closed = True
            self.server.shutdown()
            self.server.server_close()


class SitePolicy(URLPolicy):
    """The real URL policy, except the test server's own origin is allowed."""

    def __init__(self, site: Site):
        super().__init__()
        self.site = site

    def validate(self, url: str, *, resolve: bool = True) -> None:
        parsed = urlparse(url)
        if parsed.hostname == "127.0.0.1" and parsed.port == self.site.port:
            return
        super().validate(url, resolve=resolve)


class FakeClock:
    """Deterministic clock whose sleep() just advances time."""

    def __init__(self):
        self.now = 1000.0
        self.sleeps: list[float] = []

    def __call__(self) -> float:
        return self.now

    def sleep(self, seconds: float) -> None:
        self.sleeps.append(seconds)
        self.now += seconds


@pytest.fixture
def site():
    server = Site()
    yield server
    server.close()


@pytest.fixture
def clock():
    return FakeClock()


@pytest.fixture
def make_fetcher(site):
    def factory(**overrides) -> Fetcher:
        options = dict(
            delay=0, backoff=0, retries=2, timeout=5, respect_robots=False, policy=SitePolicy(site)
        )
        options.update(overrides)
        return Fetcher(**options)

    return factory
