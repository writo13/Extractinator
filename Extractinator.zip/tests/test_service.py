from pathlib import Path

import pytest

from extractinator.core.config import Settings
from extractinator.core.exceptions import ExtractionError, URLNotAllowed
from extractinator.core.models import FetchResult
from extractinator.core.policy import URLPolicy
from extractinator.service import ExtractinatorService


class FakeFetcher:
    respect_robots = True
    policy = URLPolicy()

    def __init__(self, result: FetchResult):
        self.result = result

    def fetch(self, url):
        return self.result


def service_for(url, text, content_type="text/html", **kwargs):
    fetched = FetchResult(url=url, status_code=200, content_type=content_type, text=text, **kwargs)
    return ExtractinatorService(fetcher=FakeFetcher(fetched), settings=Settings())


def test_adapter_failure_falls_back_to_generic_with_a_warning():
    broken = "<html><head><title>Books</title></head><body><article class='product_pod'></article><p>hello</p></body></html>"
    result = service_for("https://books.toscrape.com/", broken).extract("https://books.toscrape.com/")
    assert result.adapter is None and result.method == "generic_html"
    assert result.data["metadata"]["title"] == "Books"
    assert "books_to_scrape" in result.warnings[0] and "fell back" in result.warnings[0]


def test_adapter_success_has_no_warnings():
    html = (Path(__file__).parent / "fixtures" / "books_listing.html").read_text(encoding="utf-8")
    result = service_for("https://books.toscrape.com/index.html", html).extract("https://books.toscrape.com/index.html")
    assert result.adapter == "books_to_scrape" and result.warnings == []


def test_provenance_comes_from_the_fetch():
    svc = service_for("https://example.com/final", "<p>x</p>", redirected_from="https://example.com/start", from_cache=True)
    body = svc.extract("https://example.com/start").as_dict()
    assert body["source"]["url"] == "https://example.com/final"
    assert body["source"]["requested_url"] == "https://example.com/start"
    assert body["source"]["content_type"] == "text/html"
    assert body["source"]["cached"] is True


def test_json_responses_are_returned_as_json():
    result = service_for("https://api.test/x", '{"ok": true}', "application/json").extract("https://api.test/x")
    assert (result.type, result.method) == ("json", "json")
    assert result.data["content"] == {"ok": True}


def test_invalid_json_raises_extraction_error():
    with pytest.raises(ExtractionError):
        service_for("https://api.test/x", "{nope", "application/json").extract("https://api.test/x")


def test_plain_text_responses():
    result = service_for("https://x.test/a.txt", "hello", "text/plain").extract("https://x.test/a.txt")
    assert result.type == "text"


def test_truncated_lists_produce_a_warning():
    links = "".join(f'<a href="/p{i}">p{i}</a>' for i in range(150))
    result = service_for("https://x.test/", f"<p>x</p>{links}").extract("https://x.test/")
    assert any("first 100 of 150 links" in w for w in result.warnings)


def test_pages_without_readable_text_hint_at_javascript():
    result = service_for("https://x.test/", "<html><body><div id='root'></div></body></html>").extract("https://x.test/")
    assert any("JavaScript" in w for w in result.warnings)


def test_capabilities_reject_private_urls_and_report_adapters():
    svc = service_for("https://x.test/", "")
    with pytest.raises(URLNotAllowed):
        svc.capabilities("http://127.0.0.1:8000/")
    caps = svc.capabilities("https://books.toscrape.com/")
    assert caps["adapter"] == "books_to_scrape" and caps["respects_robots"] is True
