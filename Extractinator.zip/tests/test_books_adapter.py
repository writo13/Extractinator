from pathlib import Path

from extractinator.adapters.books_to_scrape import BooksToScrapeAdapter
from extractinator.core.models import FetchResult

FIXTURES = Path(__file__).parent / "fixtures"


def test_books_listing_adapter():
    adapter = BooksToScrapeAdapter()
    html = (FIXTURES / "books_listing.html").read_text(encoding="utf-8")
    result = adapter.extract(
        FetchResult(
            url="https://books.toscrape.com/index.html",
            status_code=200,
            content_type="text/html",
            text=html,
        )
    )
    assert result.type == "book_collection"
    assert len(result.data["books"]) == 2
    assert result.data["books"][0]["id"] == 1000
    assert result.data["books"][0]["rating"] == 3


def test_books_detail_adapter():
    adapter = BooksToScrapeAdapter()
    html = (FIXTURES / "books_detail.html").read_text(encoding="utf-8")
    result = adapter.extract(
        FetchResult(
            url="https://books.toscrape.com/catalogue/book-one_1000/index.html",
            status_code=200,
            content_type="text/html",
            text=html,
        )
    )
    assert result.type == "book"
    assert result.data["id"] == 1000
    assert result.data["title"] == "Book One"
    assert result.data["stock_count"] == 22
    assert result.data["description"] == "A book description."


def _extract(html, url="https://books.toscrape.com/catalogue/page-2.html"):
    return BooksToScrapeAdapter().extract(
        FetchResult(url=url, status_code=200, content_type="text/html", text=html)
    )


PAGER = (
    '<article class="product_pod"><h3><a href="a_1/index.html" title="A">A</a></h3>'
    '<p class="price_color">£1,234.50</p><p class="instock availability">In stock</p></article>'
    '<form class="form-horizontal"><strong>40</strong> results</form>'
)


def test_listing_exposes_next_and_previous_page_urls():
    html = PAGER + (
        '<ul class="pager"><li class="previous"><a href="page-1.html">previous</a></li>'
        '<li class="current">Page 2 of 2</li><li class="next"><a href="page-3.html">next</a></li></ul>'
    )
    pagination = _extract(html).data["pagination"]
    assert pagination["prev_url"] == "https://books.toscrape.com/catalogue/page-1.html"
    assert pagination["next_url"] == "https://books.toscrape.com/catalogue/page-3.html"
    assert (pagination["page"], pagination["total_pages"], pagination["total_results"]) == (2, 2, 40)


def test_listing_without_a_pager_is_a_single_page():
    pagination = _extract(PAGER).data["pagination"]
    assert (pagination["page"], pagination["total_pages"]) == (1, 1)
    assert pagination["next_url"] is None and pagination["prev_url"] is None


def test_prices_with_thousands_separators_and_currency():
    book = _extract(PAGER).data["books"][0]
    assert book["price"] == 1234.5 and book["currency"] == "GBP"


def test_listing_exposes_categories():
    html = (FIXTURES / "books_listing.html").read_text(encoding="utf-8")
    categories = _extract(html, "https://books.toscrape.com/index.html").data["categories"]
    assert categories == [
        {"name": "Poetry", "url": "https://books.toscrape.com/catalogue/category/books/poetry_23/index.html"}
    ]


def test_detail_has_a_key_and_book_ids_come_from_the_url():
    html = (FIXTURES / "books_detail.html").read_text(encoding="utf-8")
    data = _extract(html, "https://books.toscrape.com/catalogue/book-one_1000/index.html").data
    assert data["key"] == "book-one_1000" and data["id"] == 1000
    assert BooksToScrapeAdapter._book_id_from_url("https://books.toscrape.com/catalogue/book-one_1000/") == 1000
    assert BooksToScrapeAdapter._book_id_from_url("https://books.toscrape.com/catalogue/page-2.html") is None
