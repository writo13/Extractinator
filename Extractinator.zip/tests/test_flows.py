import base64
import json

from extractinator.core.flows import (
    Flow,
    FlowStore,
    FlowTiming,
    HttpMessage,
    compile_filter,
    flow_to_har,
    har_to_flows,
    redact_headers,
    redact_url,
)


def make_flow(status=200, method="GET", url="https://example.com/api/items", body="hello"):
    flow = Flow(source="test", state="completed")
    flow.request = HttpMessage(
        method=method,
        url=url,
        headers={"Authorization": "secret", "Accept": "application/json"},
        body=None,
    )
    flow.response = HttpMessage(
        status=status,
        reason="OK" if status == 200 else "ERROR",
        url=url,
        headers={"Content-Type": "application/json"},
        body=body,
        body_size=len(body.encode()),
    )
    flow.timing = FlowTiming(send_ms=1, wait_ms=2, receive_ms=3, total_ms=6)
    flow.finish(state="completed")
    return flow


def test_redaction_helpers():
    headers = redact_headers({"Authorization": "Bearer abc", "Accept": "application/json"})
    assert headers["Authorization"] == "<redacted>"
    assert headers["Accept"] == "application/json"
    assert "token=%3Credacted%3E" in redact_url("https://example.com/?token=abc&x=1")


def test_filter_expression_supports_status_method_url_body_and_headers():
    flow = make_flow()
    assert compile_filter('method:GET status:2xx url:example.com body:hello header:content-type=application') (flow)
    assert not compile_filter('method:POST')(flow)
    assert not compile_filter('status:404')(flow)


def test_store_assigns_monotonic_sequences(tmp_path):
    store = FlowStore(str(tmp_path / "flows.db"))
    first = store.save(make_flow())
    second = store.save(make_flow(status=201))
    assert second.sequence == first.sequence + 1


def test_har_round_trip_and_base64_decode():
    flow = make_flow()
    document = {"log": {"version": "1.2", "entries": [flow_to_har(flow)]}}
    imported, warnings = har_to_flows(document)
    assert not warnings
    assert len(imported) == 1
    assert imported[0].request.method == "GET"
    assert imported[0].response.status == 200
    encoded = base64.b64encode(b"encoded-body").decode()
    document["log"]["entries"][0]["response"]["content"] = {
        "text": encoded,
        "encoding": "base64",
        "mimeType": "text/plain",
    }
    imported, _ = har_to_flows(document)
    assert imported[0].response.body == "encoded-body"


def test_har_malformed_entries_are_skipped():
    document = {"log": {"entries": [{"request": {}}, "not-an-object", {"request": {"url": "https://example.com"}}]}}
    imported, warnings = har_to_flows(document)
    assert len(imported) == 1
    assert len(warnings) >= 2


def test_export_import_store(tmp_path):
    store = FlowStore(str(tmp_path / "flows.db"))
    flow = store.save(make_flow())
    exported = store.export_har()
    assert exported["log"]["entries"]
    flows, warnings = har_to_flows(exported)
    assert not warnings and flows[0].request.url == flow.request.url
    saved = store.import_flows(flows)
    assert saved[0].sequence > flow.sequence


def test_fetcher_records_completed_flow(site, make_fetcher, tmp_path):
    from extractinator.core.flows import FlowStore
    site.add("/flow", "<p>captured</p>")
    flow_store = FlowStore(str(tmp_path / "db.sqlite"))
    fetcher = make_fetcher(flow_store=flow_store)
    result = fetcher.fetch(site.url("/flow"))
    assert result.flow_id
    flow = flow_store.get(result.flow_id)
    assert flow is not None
    assert flow.sequence == 1
    assert flow.request.method == "GET"
    assert flow.response.status == 200
    assert "captured" in (flow.response.body or "")
    assert flow.duration_ms is not None


def test_fetcher_records_retry_events(site, make_fetcher, tmp_path):
    from extractinator.core.flows import FlowStore
    from conftest import Resp
    site.add("/retry", Resp(status=503), Resp(body="ok"))
    flow_store = FlowStore(str(tmp_path / "db.sqlite"))
    fetcher = make_fetcher(flow_store=flow_store)
    result = fetcher.fetch(site.url("/retry"))
    flow = flow_store.get(result.flow_id)
    assert any(event.name == "retry" for event in flow.events)
