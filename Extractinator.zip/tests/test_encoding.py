import codecs

from extractinator.core.encoding import decode_body


def test_utf8_without_any_declaration():
    text, enc = decode_body("Café £51.77".encode("utf-8"))
    assert text == "Café £51.77" and enc == "utf-8"


def test_header_charset_is_honoured():
    text, _ = decode_body(b"caf\xe9", "text/html; charset=iso-8859-1")
    assert text == "café"


def test_meta_charset_is_used_when_header_has_none():
    html = '<html><head><meta charset="windows-1251"></head>'.encode("ascii") + "Привет".encode("cp1251")
    text, enc = decode_body(html, "text/html")
    assert "Привет" in text and enc == "windows-1251"


def test_http_equiv_meta_charset():
    html = b'<meta http-equiv="Content-Type" content="text/html; charset=shift_jis">' + "日本語".encode("shift_jis")
    text, _ = decode_body(html)
    assert "日本語" in text


def test_header_wins_over_meta():
    html = b'<meta charset="utf-8">caf\xe9'
    text, _ = decode_body(html, "text/html; charset=iso-8859-1")
    assert text.endswith("café")


def test_utf8_bom():
    text, _ = decode_body(codecs.BOM_UTF8 + "héllo".encode("utf-8"), "text/html; charset=iso-8859-1")
    assert text == "héllo"


def test_invalid_utf8_falls_back_to_cp1252():
    text, enc = decode_body(b"\x93quoted\x94")
    assert text == "\u201cquoted\u201d" and enc == "cp1252"


def test_unknown_charset_label_is_ignored():
    text, _ = decode_body("Café".encode("utf-8"), "text/html; charset=not-a-real-charset")
    assert text == "Café"
