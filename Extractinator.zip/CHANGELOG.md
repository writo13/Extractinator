# Changelog

## 0.3.0

### Added

- Request Lab for initiating public HTTP requests.
- Optional local mitmproxy capture addon with credential/cookie stripping.
- SQLite-backed API Forge for creating token-protected GET/HEAD wrappers over public upstream endpoints.
- Local bearer-token creation, listing and revocation; token plaintext is returned only once.
- OpenAPI 3.1 and Postman Collection 2.1 exports for generated APIs.
- Dashboard workbench for Request Lab, captures, API generation and token management.
- Admin protection for management operations when the app is exposed beyond loopback.

### Safety

- Generated APIs do not forward upstream Authorization, Cookie, API-key or CSRF headers.
- The Forge only publishes GET/HEAD upstream methods; state-changing requests stay in the deliberate Request Lab path.
- The local proxy integration captures traffic from the user's own browser and intentionally strips credentials.


## 0.2.0

### Bugs fixed

- **Mojibake.** UTF-8 pages without a charset header came back garbled ("£" became "Â£") because `requests` assumes ISO-8859-1 for `text/*`. Decoding now follows BOM, then header charset, then `<meta charset>`, then UTF-8, then cp1252.
- **Redirects.** Four or more redirects in a row failed with a generic "Fetch failed.", because every hop used up a retry attempt. Redirects now have their own budget (5 hops) and every hop is still validated, robots-checked and throttled.
- **Throttle.** The per-host delay slept while holding one global lock, so a single slow host stalled requests to every other host.
- **robots.txt.**
  - Python's built-in parser ignores `*` and `$` patterns, so rules like `Disallow: /*?action=` were never enforced.
  - A `robots.txt` that answered 5xx was treated as "allow everything" (RFC 9309 says the opposite).
  - A `robots.txt` that redirected was ignored.
  - Rules were matched against the whole User-Agent string instead of the product token, `Crawl-delay` was ignored, and rules were cached forever.
  - Now uses Protego, follows RFC 9309, caches for 24 h, and retries a failed fetch after 5 minutes.
- **`/capabilities`** said "ready" for any URL, including ones `/extract` would reject. It now validates the URL (no network request is made).
- **URL policy.**
  - A malformed port (`http://host:abc/`) crashed it with an unhandled `ValueError`, which surfaced as HTTP 500. It is now a 400.
  - Carrier-grade NAT addresses (100.64.0.0/10, which includes Tailscale) were allowed. The policy now requires globally routable addresses, refuses `localhost`, `.local` and `.internal` names, and unwraps IPv4 hidden in IPv6 (mapped, NAT64, 6to4, Teredo) so the result no longer depends on the Python version.
- **Error codes.** A missing page, an oversized response, an unsupported content type, a parse failure and a timeout all returned 502. They now return 404, 413, 415, 422 and 504. Validation errors use the same `{"error", "type"}` body as every other error. `HEAD /` and `HEAD /health` return 200 instead of 405.
- **Scripts.** `scripts/live_smoke.py` and `scripts/demo.py` crashed with `ModuleNotFoundError` when run the way the README said.
- **Adapter failure** surfaced as an error. It now falls back to generic extraction and adds a warning.
- **JSON-LD.** An `Organization` listed before a `Product` or `Article` won, and full-URL types such as `https://schema.org/Article` were not recognised.
- **JSON and plain-text responses** were pushed through the HTML parser and came back empty. They are now returned as they are.
- **Books adapter.** Prices with thousands separators parsed wrongly (`£1,234.50` became `1.0`), currency was hard-coded to GBP, next/previous page URLs and the category list were not returned, and single-page results had `page: null`.
- **Dashboard.** Enter did not submit; a slow capability check could overwrite a newer one; `localStorage` was unguarded and throws in some private-browsing modes.

### Added

- Settings through `EXTRACTINATOR_*` environment variables (`core/config.py`).
- Provenance: `source.requested_url`, `source.content_type`, `source.cached`. Generic content has `counts` (totals before truncation), metadata has `language`, and warnings flag truncated lists and pages that need JavaScript.
- Bounded LRU page cache.
- Stateless fetching: cookies are never stored, so API callers cannot share session state.
- Dashboard: results as tables and a collapsible tree, clickable links, warning panel, timing, ARIA tabs with arrow-key navigation, Enter to submit, cancellation of superseded requests, scheme-less input (`books.toscrape.com`), downloads named by host and time, live status refresh, strict Content-Security-Policy and security headers.
- 161 offline tests (the new code had 15). The fetcher tests run against a real local HTTP server. New `requirements-dev.txt` and `pytest.ini`.

### Changed

- One version string (`extractinator.__version__`) instead of four hard-coded copies. The default User-Agent no longer points at a placeholder `.invalid` URL; set a real contact with `EXTRACTINATOR_USER_AGENT`.
- Exceptions carry their own HTTP status.
- `pytest` runs `tests/` only. The legacy suite runs with `python -m pytest legacy`.
- `start.bat` launches through `run.py` (so `EXTRACTINATOR_HOST` and `_PORT` apply). Both batch files keep the window open on failure, and `test.bat` installs the dev requirements.
- `pytest` and `httpx` moved out of `requirements.txt`.

### Removed

- The stray root-level `smoke_test.py` (pytest imported it on every run because of its `*_test.py` name) and the `__pycache__` folders that were shipped in the zip.

### Not changed

- DNS-rebinding protection is still defence in depth only; see "Known limitations" in the README.
- The `legacy/` folder is untouched.

## 0.4.0 — Flow Inspector + HAR workbench

- Added a persistent flow model for request/response exchanges, lifecycle state, timing, redirects, events, errors and extraction outcomes.
- Added a SQLite-backed `FlowStore` with bounded listing and expression filtering.
- Added filter syntax for method, status/status-class, URL, headers, body text, source, errors, redirects and body presence.
- Added HAR 1.2 export and tolerant HAR import with base64/text decoding and per-entry warnings.
- Added default redaction for authentication, cookie, API-key, CSRF and sensitive query parameters.
- Added flow recording to the Fetcher, including retries, redirects, timing and cache outcomes.
- Added offline extraction from stored response bodies and safe replay through the existing Request Lab policy.
- Added `/flows` APIs for listing, viewing, deleting, clearing, importing/exporting HAR, replay and offline extraction.
- Added a dedicated Flow Inspector dashboard at `/flows-ui`.
- Added a queued mitmproxy addon that streams sanitized response-complete flows to Extractinator.
- Added CLI commands: `dump`, `export-har`, `import-har`, `extract-flow`, `replay`.

- 2026-10-03: Refreshed the dashboard and Flow Inspector with an original light fintech/developer-console theme and added copyright attribution for Writobrata Chatterjee.
