@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Run start.bat first to create the virtual environment.
  pause
  exit /b 1
)
call .venv\Scripts\activate.bat
python -m pip install -r requirements-proxy.txt
mitmdump -s scripts\mitmproxy_capture.py
pause
