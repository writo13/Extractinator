# Notes: unofficial API for books.toscrape.com

**Target:** https://books.toscrape.com/. It has no public API and is a sandbox built for scraping practice. Only public pages are read: no login, no private data, no access-control bypass. robots.txt is honoured, requests are throttled and cached, and the client refuses to fetch anything off-site.

**Endpoints:** `GET /categories`, `/books?page=&category=`, `/books/{key|id}`, `/search?q=&min_rating=&max_price=&category=&limit=`, `/health`. The same operations are available in Python via `BooksClient`.

## Limitations
- **Fragile by nature.** Parsing depends on CSS classes and page layout. A redesign breaks it. The client raises `ParseError` (HTTP 502 in the facade) instead of returning wrong data, but it still breaks.
- **No server-side search or filtering.** `search` crawls listing pages and filters client-side (up to 50 requests for the full catalogue). Use `limit`, `category` and `max_pages` to cut this down.
- **Numeric ID lookup is a workaround.** Product URLs need the slug (`a-light-in-the-attic_1000`), so lookup by number alone builds a one-off index by crawling every listing page.
- **No change notification, no consistency guarantees.** Data is as fresh as the cache. Prices on this site are random demo values.
- **Throughput is capped** at about 2 requests/second by design. There is no auth, rate limiting or persistence on the facade (it is a demo server, not production).
- **Tested offline against reconstructed fixtures**, mirroring the markup I inspected. `python test_books_api.py --live` runs a few read-only smoke tests against the real site; run it once from a machine with internet access to confirm the selectors.

## Appropriate long-term fix
Scraping is a stopgap. The durable solution is for the site owner to expose an official, versioned API (REST/JSON, with search, filtering, pagination and stable IDs) or a data feed or sitemap, and for consumers to switch to it. Until then, keep the scraper isolated behind this interface (so consumers don't change when the backend does), add the live smoke tests to CI or a scheduled job to catch layout changes early, and agree access terms with the owner if usage grows.
