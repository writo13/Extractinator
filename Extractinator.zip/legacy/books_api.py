"""
books_api.py - a small, polite "API" over books.toscrape.com (no public API exists).

Target: https://books.toscrape.com/ - a sandbox site published for scraping practice.
Only public, unauthenticated pages are read. No login, no private data, no
access-control bypass. robots.txt is honoured and requests are throttled.

Two layers:
  1. BooksClient  - Python API   (categories, books, book detail, search)
  2. make_server  - tiny JSON-over-HTTP facade around BooksClient

Run the facade:   python books_api.py serve --port 8000
Quick demo:       python books_api.py demo

Endpoints (facade):
  GET /health
  GET /categories
  GET /books?page=1&category=poetry_23        (category = id, slug or name)
  GET /books/{key}                            (key = a-light-in-the-attic_1000 | numeric id)
  GET /search?q=light&min_rating=3&max_price=40&category=Poetry&limit=10
"""
from __future__ import annotations

import json
import re
import sys
import threading
import time
from dataclasses import asdict, dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Iterator, Optional
from urllib.parse import parse_qs, unquote, urljoin, urlparse
from urllib.robotparser import RobotFileParser

import requests
from bs4 import BeautifulSoup

BASE_URL = "https://books.toscrape.com/"
USER_AGENT = "books-api-wrapper/1.0 (educational project)"
RATING_WORDS = {"One": 1, "Two": 2, "Three": 3, "Four": 4, "Five": 5}
KEY_RE = re.compile(r"^[a-z0-9-]+_(\d+)$")


# --------------------------------------------------------------------------- errors
class BooksAPIError(Exception):
    """Base error."""


class NotFoundError(BooksAPIError):
    """Upstream page does not exist (HTTP 404) or an unknown category/book was requested."""


class ParseError(BooksAPIError):
    """Upstream HTML no longer matches what the parser expects (site layout changed)."""


class RobotsDisallowed(BooksAPIError):
    """robots.txt forbids fetching this URL for our user agent."""


# --------------------------------------------------------------------------- models
@dataclass
class Category:
    id: int
    name: str
    slug: str
    url: str


@dataclass
class BookSummary:
    id: int
    key: str
    title: str
    url: str
    price: float
    currency: Optional[str]
    rating: Optional[int]
    in_stock: bool
    image: Optional[str]


@dataclass
class Book(BookSummary):
    upc: Optional[str] = None
    product_type: Optional[str] = None
    category: Optional[str] = None
    description: Optional[str] = None
    price_excl_tax: Optional[float] = None
    price_incl_tax: Optional[float] = None
    tax: Optional[float] = None
    stock_count: Optional[int] = None
    num_reviews: Optional[int] = None


@dataclass
class Page:
    books: list
    page: int
    total_pages: int
    total_results: int
    has_next: bool


# --------------------------------------------------------------------------- helpers
def _price(text: str) -> float:
    m = re.search(r"\d+(?:\.\d+)?", text or "")
    if not m:
        raise ParseError(f"no price in {text!r}")
    return float(m.group())


def _rating(tag) -> Optional[int]:
    if tag is None:
        return None
    for cls in tag.get("class", []):
        if cls in RATING_WORDS:
            return RATING_WORDS[cls]
    return None


def _key_from_url(url: str) -> str:
    parts = [p for p in urlparse(url).path.split("/") if p]
    # .../catalogue/<key>/index.html
    if len(parts) >= 2 and KEY_RE.match(parts[-2]):
        return parts[-2]
    raise ParseError(f"cannot derive book key from {url}")


# --------------------------------------------------------------------------- client
class BooksClient:
    def __init__(
        self,
        base_url: str = BASE_URL,
        session: Optional[requests.Session] = None,
        delay: float = 0.5,
        retries: int = 3,
        backoff: float = 1.0,
        timeout: float = 15,
        respect_robots: bool = True,
        sleep=time.sleep,
        clock=time.monotonic,
    ):
        parsed_base = urlparse(base_url)
        if parsed_base.scheme not in {"http", "https"} or not parsed_base.netloc:
            raise ValueError("base_url must be an absolute HTTP(S) URL")
        self.base_url = base_url if base_url.endswith("/") else base_url + "/"
        self._base_origin = (parsed_base.scheme.lower(), parsed_base.netloc.lower())
        self.session = session or requests.Session()
        self.session.headers.update({"User-Agent": USER_AGENT}) if hasattr(self.session, "headers") else None
        self.delay, self.retries, self.backoff, self.timeout = delay, retries, backoff, timeout
        self.respect_robots = respect_robots
        self._sleep, self._clock = sleep, clock
        self._last: Optional[float] = None
        self._lock = threading.Lock()
        self._cache: dict[str, str] = {}
        self._robots: Optional[RobotFileParser] = None
        self._categories: Optional[list[Category]] = None
        self._index: Optional[dict[int, str]] = None

    # ---- transport -------------------------------------------------------
    def _throttle(self) -> None:
        with self._lock:
            now = self._clock()
            if self._last is not None:
                wait = self.delay - (now - self._last)
                if wait > 0:
                    self._sleep(wait)
            self._last = self._clock()

    def _check_robots(self, url: str) -> None:
        if not self.respect_robots:
            return
        if self._robots is None:
            rp = RobotFileParser()
            try:
                self._throttle()
                r = self.session.get(urljoin(self.base_url, "robots.txt"), timeout=self.timeout)
                if r.status_code == 200:
                    rp.parse(r.text.splitlines())
                else:
                    rp.parse([])  # no robots.txt -> everything allowed
            except requests.RequestException:
                rp.parse([])
            self._robots = rp
        if not self._robots.can_fetch(USER_AGENT, url):
            raise RobotsDisallowed(url)

    def _get(self, path_or_url: str) -> BeautifulSoup:
        url = urljoin(self.base_url, path_or_url)
        parsed_url = urlparse(url)
        if (parsed_url.scheme.lower(), parsed_url.netloc.lower()) != self._base_origin:
            raise ValueError("refusing to fetch outside the target site")
        if not parsed_url.path.startswith(urlparse(self.base_url).path):
            raise ValueError("refusing to fetch outside the configured base path")
        if url in self._cache:
            return BeautifulSoup(self._cache[url], "html.parser")
        self._check_robots(url)

        last_err: Exception = BooksAPIError("unreachable")
        for attempt in range(self.retries + 1):
            self._throttle()
            try:
                r = self.session.get(url, timeout=self.timeout)
            except requests.RequestException as e:
                last_err = BooksAPIError(f"network error: {e}")
            else:
                if r.status_code == 200:
                    r.encoding = "utf-8"  # site omits charset; avoids "Â£" mojibake
                    self._cache[url] = r.text
                    return BeautifulSoup(r.text, "html.parser")
                if r.status_code == 404:
                    raise NotFoundError(url)
                last_err = BooksAPIError(f"HTTP {r.status_code} for {url}")
                if r.status_code not in (429, 500, 502, 503, 504):
                    raise last_err
                ra = (getattr(r, "headers", None) or {}).get("Retry-After", "")
                if ra.isdigit():
                    self._sleep(min(int(ra), 30))
            if attempt < self.retries:
                self._sleep(self.backoff * 2 ** attempt)
        raise last_err

    # ---- parsing ---------------------------------------------------------
    def _parse_listing(self, soup: BeautifulSoup, page_url: str, page: int) -> Page:
        pods = soup.select("article.product_pod")
        strong = soup.select_one("form.form-horizontal strong")
        if not pods and not (strong and strong.get_text(strip=True) == "0"):
            raise ParseError("listing page has no product_pod elements")
        books = []
        for pod in pods:
            a = pod.select_one("h3 a")
            price = pod.select_one("p.price_color")
            if a is None or price is None:
                raise ParseError("product_pod missing title link or price")
            href = urljoin(page_url, a["href"])
            img = pod.select_one("img")
            avail = pod.select_one("p.availability")
            key = _key_from_url(href)
            books.append(
                BookSummary(
                    id=int(KEY_RE.match(key).group(1)),
                    key=key,
                    title=a.get("title") or a.get_text(strip=True),
                    url=href,
                    price=_price(price.get_text()),
                    currency="GBP" if "£" in price.get_text() else None,
                    rating=_rating(pod.select_one("p.star-rating")),
                    in_stock=bool(avail and "in stock" in avail.get_text().lower()),
                    image=urljoin(page_url, img["src"]) if img and img.get("src") else None,
                )
            )
        total_results = int(strong.get_text(strip=True)) if strong and strong.get_text(strip=True).isdigit() else len(books)
        cur = soup.select_one("ul.pager li.current")
        m = re.search(r"Page\s+(\d+)\s+of\s+(\d+)", cur.get_text() if cur else "")
        total_pages = int(m.group(2)) if m else 1
        return Page(books, page, total_pages, total_results, page < total_pages)

    def _parse_book(self, soup: BeautifulSoup, url: str) -> Book:
        main = soup.select_one("div.product_main")
        h1 = main.select_one("h1") if main else None
        price = main.select_one("p.price_color") if main else None
        if not (main and h1 and price):
            raise ParseError("book page missing product_main/title/price")
        table = {
            r.th.get_text(strip=True): r.td.get_text(strip=True)
            for r in soup.select("table.table-striped tr") if r.th and r.td
        }
        crumbs = soup.select("ul.breadcrumb li")
        category = crumbs[2].get_text(strip=True) if len(crumbs) >= 4 else None
        desc_div = soup.select_one("#product_description")
        desc_p = desc_div.find_next_sibling("p") if desc_div else None
        stock = (main.select_one("p.availability") or h1).get_text(" ", strip=True)
        m = re.search(r"(\d+)\s+available", stock)
        img = soup.select_one("#product_gallery img")
        money = lambda k: _price(table[k]) if k in table else None  # noqa: E731
        key = _key_from_url(url)
        return Book(
            id=int(KEY_RE.match(key).group(1)),
            key=key,
            title=h1.get_text(strip=True),
            url=url,
            price=_price(price.get_text()),
            currency="GBP" if "£" in price.get_text() else None,
            rating=_rating(main.select_one("p.star-rating")),
            in_stock="in stock" in stock.lower(),
            image=urljoin(url, img["src"]) if img and img.get("src") else None,
            upc=table.get("UPC"),
            product_type=table.get("Product Type"),
            category=category,
            description=desc_p.get_text(strip=True) if desc_p else None,
            price_excl_tax=money("Price (excl. tax)"),
            price_incl_tax=money("Price (incl. tax)"),
            tax=money("Tax"),
            stock_count=int(m.group(1)) if m else None,
            num_reviews=int(table["Number of reviews"]) if table.get("Number of reviews", "").isdigit() else None,
        )

    # ---- public API ------------------------------------------------------
    def categories(self) -> list[Category]:
        if self._categories is None:
            soup = self._get("index.html")
            links = soup.select("div.side_categories ul ul li a")
            if not links:
                raise ParseError("category sidebar not found")
            cats = []
            for a in links:
                url = urljoin(self.base_url, a["href"])
                slug = url.rstrip("/").split("/")[-2]
                m = KEY_RE.match(slug)
                if not m:
                    raise ParseError(f"unexpected category slug {slug!r}")
                cats.append(Category(int(m.group(1)), a.get_text(strip=True), slug, url))
            self._categories = cats
        return list(self._categories)

    def _resolve_category(self, ref) -> Category:
        ref_s = str(ref).strip().lower()
        for c in self.categories():
            if ref_s in (str(c.id), c.slug.lower(), c.name.lower()):
                return c
        raise NotFoundError(f"unknown category {ref!r}")

    def books(self, page: int = 1, category=None) -> Page:
        if not isinstance(page, int) or page < 1:
            raise ValueError("page must be an integer >= 1")
        if category is None:
            path = f"catalogue/page-{page}.html"
        else:
            slug = self._resolve_category(category).slug
            leaf = "index.html" if page == 1 else f"page-{page}.html"
            path = f"catalogue/category/books/{slug}/{leaf}"
        url = urljoin(self.base_url, path)
        return self._parse_listing(self._get(url), url, page)

    def iter_books(self, category=None, max_pages: Optional[int] = None) -> Iterator[BookSummary]:
        if max_pages is not None and (not isinstance(max_pages, int) or isinstance(max_pages, bool) or max_pages < 1):
            raise ValueError("max_pages must be an integer >= 1")
        page = 1
        while True:
            p = self.books(page, category)
            yield from p.books
            if not p.has_next or (max_pages and page >= max_pages):
                return
            page += 1

    def book(self, ref) -> Book:
        """ref: numeric id, 'slug_id' key, or a full product URL on the target site."""
        if isinstance(ref, str) and ref.isdigit():
            ref = int(ref)
        if isinstance(ref, int):
            if self._index is None:  # no id->slug mapping exists upstream; build it once
                self._index = {b.id: b.url for b in self.iter_books()}
            if ref not in self._index:
                raise NotFoundError(f"no book with id {ref}")
            url = self._index[ref]
        elif isinstance(ref, str) and ref.startswith("http"):
            url = ref
            parsed = urlparse(url)
            if ((parsed.scheme.lower(), parsed.netloc.lower()) != self._base_origin
                    or not parsed.path.startswith(urlparse(self.base_url).path)
                    or not parsed.path.endswith("/index.html")):
                raise ValueError("url must be a product page on the target site")
        elif isinstance(ref, str) and KEY_RE.match(ref):
            url = urljoin(self.base_url, f"catalogue/{ref}/index.html")
        else:
            raise ValueError(f"unrecognised book reference {ref!r}")
        return self._parse_book(self._get(url), url)

    def search(
        self, q: Optional[str] = None, *, category=None, min_rating: Optional[int] = None,
        min_price: Optional[float] = None, max_price: Optional[float] = None,
        in_stock: Optional[bool] = None, limit: Optional[int] = None, max_pages: Optional[int] = None,
    ) -> list[BookSummary]:
        """Client-side filtering: the site has no search endpoint, so this crawls listing pages."""
        if limit is not None and (not isinstance(limit, int) or isinstance(limit, bool) or limit < 0):
            raise ValueError("limit must be an integer >= 0")
        if min_rating is not None and not 1 <= min_rating <= 5:
            raise ValueError("min_rating must be between 1 and 5")
        if min_price is not None and min_price < 0 or max_price is not None and max_price < 0:
            raise ValueError("prices must be >= 0")
        if min_price is not None and max_price is not None and min_price > max_price:
            raise ValueError("min_price cannot exceed max_price")
        if limit == 0:
            return []
        out = []
        for b in self.iter_books(category, max_pages):
            if q and q.lower() not in b.title.lower():
                continue
            if min_rating is not None and (b.rating or 0) < min_rating:
                continue
            if min_price is not None and b.price < min_price:
                continue
            if max_price is not None and b.price > max_price:
                continue
            if in_stock is not None and b.in_stock != in_stock:
                continue
            out.append(b)
            if limit is not None and len(out) >= limit:
                break
        return out


# --------------------------------------------------------------------------- HTTP facade
def make_server(client: BooksClient, host: str = "127.0.0.1", port: int = 8000) -> ThreadingHTTPServer:
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *a):  # keep stdout quiet
            pass

        def _send(self, status: int, payload) -> None:
            body = json.dumps(payload, ensure_ascii=False).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):  # noqa: N802
            u = urlparse(self.path)
            qs = {k: v[0] for k, v in parse_qs(u.query).items()}
            path = unquote(u.path).rstrip("/") or "/"
            try:
                if path == "/health":
                    return self._send(200, {"status": "ok"})
                if path == "/categories":
                    return self._send(200, [asdict(c) for c in client.categories()])
                if path == "/books":
                    p = client.books(int(qs.get("page", 1)), qs.get("category"))
                    return self._send(200, {**asdict(p)})
                if path.startswith("/books/"):
                    return self._send(200, asdict(client.book(path[len("/books/"):])))
                if path == "/search":
                    res = client.search(
                        qs.get("q"), category=qs.get("category"),
                        min_rating=int(qs["min_rating"]) if "min_rating" in qs else None,
                        min_price=float(qs["min_price"]) if "min_price" in qs else None,
                        max_price=float(qs["max_price"]) if "max_price" in qs else None,
                        in_stock={"true": True, "false": False}.get(qs.get("in_stock", "").lower()),
                        limit=int(qs.get("limit", 20)),
                        max_pages=int(qs["max_pages"]) if "max_pages" in qs else None,
                    )
                    return self._send(200, {"count": len(res), "results": [asdict(b) for b in res]})
                return self._send(404, {"error": "unknown route"})
            except NotFoundError as e:
                self._send(404, {"error": str(e)})
            except ValueError as e:
                self._send(400, {"error": f"bad request: {e}"})
            except RobotsDisallowed as e:
                self._send(403, {"error": f"blocked by robots.txt: {e}"})
            except BooksAPIError as e:  # ParseError, upstream failures
                self._send(502, {"error": str(e), "type": type(e).__name__})

    return ThreadingHTTPServer((host, port), Handler)


# --------------------------------------------------------------------------- CLI
if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "demo"
    if cmd == "serve":
        port = int(sys.argv[sys.argv.index("--port") + 1]) if "--port" in sys.argv else 8000
        srv = make_server(BooksClient(), port=port)
        print(f"Serving on http://127.0.0.1:{port}  (Ctrl-C to stop)")
        srv.serve_forever()
    else:
        c = BooksClient()
        print("categories:", len(c.categories()))
        p = c.books(1)
        print(f"page 1: {len(p.books)} books of {p.total_results}; first = {p.books[0].title!r}")
        print(json.dumps(asdict(c.book(p.books[0].key)), indent=2, ensure_ascii=False)[:600])
