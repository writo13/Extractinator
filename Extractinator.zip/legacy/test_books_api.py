"""
Tests for books_api.py.

  python test_books_api.py          # offline: fixtures mirror the real books.toscrape.com markup
  python test_books_api.py --live   # also runs read-only smoke tests against the real site
                                    # (a handful of requests, throttled, robots.txt honoured)
"""
import json
import sys
import threading
import unittest
import urllib.error
import urllib.request
from urllib.parse import urljoin

import requests

from books_api import (
    BASE_URL, BooksAPIError, BooksClient, NotFoundError, ParseError,
    RobotsDisallowed, make_server,
)

LIVE = "--live" in sys.argv
if LIVE:
    sys.argv.remove("--live")

# ----------------------------------------------------------------------------
# Fake site: 45 books. 0-24 Poetry, 25-39 Travel, 40-44 Mystery. 20 books per page.
# ----------------------------------------------------------------------------
CATS = [("Travel", 2, "travel_2"), ("Mystery", 3, "mystery_3"), ("Poetry", 23, "poetry_23")]
WORDS = ["One", "Two", "Three", "Four", "Five"]


def make_books():
    books = []
    for i in range(45):
        cat = "poetry_23" if i < 25 else "travel_2" if i < 40 else "mystery_3"
        title = f"Light Book {i}" if i % 5 == 0 else f"Plain Book {i}"
        books.append(dict(
            id=1000 - i, key=f"book-{i}_{1000 - i}", title=title, price=10 + i,
            rating=WORDS[i % 5], stock=(i % 7 != 0), cat=cat,
            desc=None if i == 3 else f"Description of book {i}.",
        ))
    return books


BOOKS = make_books()
LONG_TITLE = "x" * 60  # listing truncates titles in visible text; full title is in the attribute


def sidebar():
    lis = "".join(f'<li><a href="catalogue/category/books/{s}/index.html"> {n} </a></li>' for n, _, s in CATS)
    return ('<div class="side_categories"><ul class="nav nav-list"><li><a href="catalogue/category/books_1/'
            f'index.html">Books</a><ul>{lis}</ul></li></ul></div>')


def pod(b, rel):
    return (f'<li><article class="product_pod"><div class="image_container"><a href="{rel}{b["key"]}/index.html">'
            f'<img src="../media/cache/aa/{b["id"]}.jpg" alt="x"></a></div>'
            f'<p class="star-rating {b["rating"]}"><i class="icon-star"></i></p>'
            f'<h3><a href="{rel}{b["key"]}/index.html" title="{b["title"]}">{b["title"][:10]}...</a></h3>'
            f'<div class="product_price"><p class="price_color">£{b["price"]:.2f}</p>'
            f'<p class="instock availability"><i class="icon-ok"></i>\n  {"In stock" if b["stock"] else "Out of stock"}\n</p>'
            '</div></article></li>')


def listing(books, page, per=20, rel=""):
    total = len(books)
    pages = max(1, -(-total // per))
    chunk = books[(page - 1) * per: page * per]
    pager = f'<li class="current">Page {page} of {pages}</li>' if pages > 1 else ""
    nxt = f'<li class="next"><a href="page-{page + 1}.html">next</a></li>' if page < pages else ""
    return (f'<html><body>{sidebar()}<form class="form-horizontal"><div><strong>{total}</strong> results - showing '
            f'<strong>{(page - 1) * per + 1}</strong> to <strong>{(page - 1) * per + len(chunk)}</strong></div></form>'
            f'<ol>{"".join(pod(b, rel) for b in chunk)}</ol><ul class="pager">{pager}{nxt}</ul></body></html>')


def detail(b):
    catname = next(n for n, _, s in CATS if s == b["cat"])
    desc = (f'<div id="product_description" class="sub-header"><h2>Product Description</h2></div><p>{b["desc"]}</p>'
            if b["desc"] else "")
    stock = "In stock (22 available)" if b["stock"] else "Out of stock"
    return (f'<html><body><ul class="breadcrumb"><li><a href="../../index.html">Home</a></li>'
            f'<li><a href="../category/books_1/index.html">Books</a></li>'
            f'<li><a href="../category/books/{b["cat"]}/index.html">{catname}</a></li><li class="active">{b["title"]}</li></ul>'
            f'<div id="product_gallery"><div class="item active"><img src="../../media/cache/aa/{b["id"]}.jpg"></div></div>'
            f'<div class="col-sm-6 product_main"><h1>{b["title"]}</h1><p class="price_color">£{b["price"]:.2f}</p>'
            f'<p class="instock availability"><i class="icon-ok"></i> {stock}</p>'
            f'<p class="star-rating {b["rating"]}"></p></div>{desc}'
            f'<table class="table table-striped"><tr><th>UPC</th><td>upc{b["id"]}</td></tr>'
            f'<tr><th>Product Type</th><td>Books</td></tr><tr><th>Price (excl. tax)</th><td>£{b["price"]:.2f}</td></tr>'
            f'<tr><th>Price (incl. tax)</th><td>£{b["price"]:.2f}</td></tr><tr><th>Tax</th><td>£0.00</td></tr>'
            f'<tr><th>Availability</th><td>{stock}</td></tr><tr><th>Number of reviews</th><td>0</td></tr></table>'
            '</body></html>')


def route(path):
    """Return (status, body) for a site-relative path, like the real site would."""
    if path == "index.html":
        return 200, listing(BOOKS, 1, rel="catalogue/")
    if path.startswith("catalogue/page-"):
        n = int(path.split("page-")[1].split(".")[0])
        return (200, listing(BOOKS, n)) if 1 <= n <= 3 else (404, "nope")
    if path.startswith("catalogue/category/books/"):
        slug, leaf = path[len("catalogue/category/books/"):].split("/")
        cb = [b for b in BOOKS if b["cat"] == slug]
        n = 1 if leaf == "index.html" else int(leaf.split("-")[1].split(".")[0])
        if not cb or n > max(1, -(-len(cb) // 20)):
            return 404, "nope"
        return 200, listing(cb, n, rel="../../../")
    if path.endswith("/index.html"):
        key = path.split("/")[1]
        b = next((b for b in BOOKS if b["key"] == key), None)
        return (200, detail(b)) if b else (404, "nope")
    return 404, "nope"


class FakeResponse:
    def __init__(self, status, text, headers=None):
        self.status_code, self.text, self.headers, self.encoding = status, text, headers or {}, None


class FakeSession:
    def __init__(self):
        self.headers = {}
        self.log = []
        self.robots = None           # robots.txt body, or None for 404
        self.fail_first = {}         # path -> list of statuses to return before success

    def get(self, url, timeout=None):
        path = url[len(BASE_URL):]
        self.log.append(path)
        if path == "robots.txt":
            return FakeResponse(200, self.robots) if self.robots else FakeResponse(404, "")
        queued = self.fail_first.get(path)
        if queued:
            return FakeResponse(queued.pop(0), "", {"Retry-After": "1"})
        return FakeResponse(*route(path))

    def pages_hit(self):
        return [p for p in self.log if p != "robots.txt"]


def client(session=None, **kw):
    s = session or FakeSession()
    return BooksClient(session=s, delay=0, sleep=lambda _: None, **kw), s


# ----------------------------------------------------------------------------
class OfflineTests(unittest.TestCase):
    def test_categories(self):
        c, _ = client()
        cats = c.categories()
        self.assertEqual([x.name for x in cats], ["Travel", "Mystery", "Poetry"])  # whitespace trimmed
        self.assertEqual(cats[2].id, 23)
        self.assertEqual(cats[2].slug, "poetry_23")

    def test_listing_page_fields(self):
        c, _ = client()
        p = c.books(1)
        self.assertEqual((len(p.books), p.page, p.total_pages, p.total_results, p.has_next), (20, 1, 3, 45, True))
        b = p.books[0]
        self.assertEqual((b.id, b.key, b.title, b.price, b.currency), (1000, "book-0_1000", "Light Book 0", 10.0, "GBP"))
        self.assertEqual(b.rating, 1)
        self.assertFalse(b.in_stock)  # i % 7 == 0 -> out of stock
        self.assertTrue(b.url.startswith(BASE_URL + "catalogue/"))
        self.assertTrue(b.image.startswith(BASE_URL))

    def test_last_page_and_out_of_range(self):
        c, _ = client()
        p = c.books(3)
        self.assertEqual((len(p.books), p.has_next), (5, False))
        with self.assertRaises(NotFoundError):
            c.books(4)
        with self.assertRaises(ValueError):
            c.books(0)

    def test_category_resolution_and_pagination(self):
        c, _ = client()
        by_name, by_slug, by_id = c.books(1, "poetry"), c.books(1, "poetry_23"), c.books(1, 23)
        self.assertEqual(by_name.books[0].key, by_slug.books[0].key)
        self.assertEqual(by_slug.books[0].key, by_id.books[0].key)
        self.assertEqual((by_name.total_results, by_name.total_pages), (25, 2))
        self.assertEqual(len(c.books(2, "Poetry").books), 5)
        with self.assertRaises(NotFoundError):
            c.books(1, "does-not-exist")

    def test_book_detail(self):
        c, _ = client()
        b = c.book("book-1_999")
        self.assertEqual((b.title, b.category, b.upc, b.product_type), ("Plain Book 1", "Poetry", "upc999", "Books"))
        self.assertEqual((b.price_excl_tax, b.price_incl_tax, b.tax), (11.0, 11.0, 0.0))
        self.assertEqual((b.stock_count, b.num_reviews, b.in_stock), (22, 0, True))
        self.assertEqual(b.description, "Description of book 1.")
        self.assertTrue(b.image.startswith(BASE_URL + "media/"))

    def test_book_without_description(self):
        c, _ = client()
        self.assertIsNone(c.book("book-3_997").description)

    def test_book_by_url_and_numeric_id(self):
        c, s = client()
        by_key = c.book("book-5_995")
        by_url = c.book(BASE_URL + "catalogue/book-5_995/index.html")
        by_id = c.book(995)
        by_id_str = c.book("995")
        self.assertEqual({by_key.key, by_url.key, by_id.key, by_id_str.key}, {"book-5_995"})
        with self.assertRaises(NotFoundError):
            c.book(1)  # id not in catalogue

    def test_book_ref_validation(self):
        c, s = client()
        for bad in ["../../etc/passwd", "http://evil.example/catalogue/x_1/index.html", "Not A Key", ""]:
            with self.assertRaises(ValueError, msg=bad):
                c.book(bad)
        self.assertEqual(s.pages_hit(), [])  # nothing fetched for rejected input
        with self.assertRaises(NotFoundError):
            c.book("ghost-book_5")

    def test_search_argument_validation(self):
        c, _ = client()
        for kwargs in (
            {"limit": -1},
            {"min_rating": 0},
            {"min_rating": 6},
            {"min_price": -0.01},
            {"max_price": -1},
            {"min_price": 20, "max_price": 10},
        ):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                c.search(**kwargs)
        self.assertEqual(c.search(limit=0), [])
        with self.assertRaises(ValueError):
            list(c.iter_books(max_pages=0))

    def test_same_origin_validation_is_not_prefix_based(self):
        c, _ = client()
        with self.assertRaises(ValueError):
            c._get("https://books.toscrape.com.evil.example/catalogue/page-1.html")

    def test_search_filters(self):
        c, _ = client()
        light = c.search("light")
        self.assertEqual(len(light), 9)  # i % 5 == 0 over 45 books
        self.assertTrue(all("light" in b.title.lower() for b in light))
        combo = c.search("light", min_rating=1, max_price=30, in_stock=True, category="poetry")
        self.assertTrue(all(b.in_stock and b.price <= 30 for b in combo))
        self.assertEqual(len(c.search(limit=3)), 3)
        self.assertEqual(len(c.search(category="mystery")), 5)
        self.assertEqual(c.search("zzz-nothing"), [])

    def test_search_limit_stops_crawling_early(self):
        c, s = client()
        c.search(limit=2)
        self.assertEqual([p for p in s.pages_hit() if p.startswith("catalogue/page-")], ["catalogue/page-1.html"])

    def test_cache_prevents_repeat_requests(self):
        c, s = client()
        c.books(1)
        n = len(s.pages_hit())
        c.books(1)
        self.assertEqual(len(s.pages_hit()), n)

    def test_throttle_spaces_requests(self):
        sleeps = []
        c = BooksClient(session=FakeSession(), delay=1.0, sleep=sleeps.append, clock=lambda: 0.0, respect_robots=False)
        c.books(1)
        c.books(2)
        self.assertIn(1.0, sleeps)

    def test_retry_then_success(self):
        s = FakeSession()
        s.fail_first["catalogue/page-1.html"] = [503, 429]
        c, _ = client(s)
        self.assertEqual(len(c.books(1).books), 20)
        self.assertEqual(s.log.count("catalogue/page-1.html"), 3)

    def test_persistent_failure_raises(self):
        s = FakeSession()
        s.fail_first["catalogue/page-1.html"] = [503] * 10
        c, _ = client(s)
        with self.assertRaises(BooksAPIError):
            c.books(1)

    def test_network_error_wrapped(self):
        class Boom(FakeSession):
            def get(self, url, timeout=None):
                if url.endswith("robots.txt"):
                    return FakeResponse(404, "")
                raise requests.ConnectionError("down")
        c, _ = client(Boom())
        with self.assertRaises(BooksAPIError):
            c.books(1)

    def test_layout_change_raises_parse_error(self):
        s = FakeSession()
        s.robots = None
        c, _ = client(s)
        c._cache[BASE_URL + "catalogue/page-1.html"] = "<html><body><div class='redesigned'></div></body></html>"
        with self.assertRaises(ParseError):
            c.books(1)
        c._cache[BASE_URL + "catalogue/book-0_1000/index.html"] = "<html><h1>hi</h1></html>"
        with self.assertRaises(ParseError):
            c.book("book-0_1000")

    def test_robots_disallow_is_honoured(self):
        s = FakeSession()
        s.robots = "User-agent: *\nDisallow: /catalogue/\n"
        c, _ = client(s)
        with self.assertRaises(RobotsDisallowed):
            c.books(1)
        self.assertEqual(s.pages_hit(), [])

    def test_refuses_off_site_fetch(self):
        c, _ = client()
        with self.assertRaises(ValueError):
            c._get("http://evil.example/")


class FacadeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        c, _ = client()
        cls.srv = make_server(c, port=0)
        cls.base = f"http://127.0.0.1:{cls.srv.server_address[1]}"
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()
        cls.srv.server_close()

    def get(self, path):
        try:
            with urllib.request.urlopen(self.base + path, timeout=10) as r:
                return r.status, json.load(r)
        except urllib.error.HTTPError as e:
            return e.code, json.load(e)

    def test_health_and_categories(self):
        self.assertEqual(self.get("/health"), (200, {"status": "ok"}))
        st, body = self.get("/categories")
        self.assertEqual((st, len(body)), (200, 3))

    def test_books_and_detail(self):
        st, body = self.get("/books?page=2&category=poetry_23")
        self.assertEqual((st, body["page"], len(body["books"])), (200, 2, 5))
        st, body = self.get("/books/book-2_998")
        self.assertEqual((st, body["title"], body["category"]), (200, "Plain Book 2", "Poetry"))
        st, body = self.get("/books/998")
        self.assertEqual((st, body["key"]), (200, "book-2_998"))

    def test_search(self):
        st, body = self.get("/search?q=light&min_rating=1&limit=4")
        self.assertEqual((st, body["count"]), (200, 4))

    def test_error_mapping(self):
        self.assertEqual(self.get("/books?page=abc")[0], 400)
        self.assertEqual(self.get("/books?page=99")[0], 404)
        self.assertEqual(self.get("/books/ghost_1")[0], 404)
        self.assertEqual(self.get("/books/not%20a%20key")[0], 400)
        self.assertEqual(self.get("/nope")[0], 404)
        self.assertEqual(self.get("/search?min_rating=x")[0], 400)


@unittest.skipUnless(LIVE, "pass --live to hit the real site")
class LiveSmokeTests(unittest.TestCase):
    """Few, throttled, read-only requests against the public sandbox site."""

    @classmethod
    def setUpClass(cls):
        cls.c = BooksClient(delay=1.0)

    def test_categories(self):
        cats = self.c.categories()
        self.assertGreaterEqual(len(cats), 50)
        self.assertIn("Poetry", [x.name for x in cats])

    def test_first_page(self):
        p = self.c.books(1)
        self.assertEqual((len(p.books), p.total_pages, p.total_results), (20, 50, 1000))
        self.assertEqual(p.books[0].title, "A Light in the Attic")
        self.assertEqual(p.books[0].price, 51.77)

    def test_book_detail(self):
        b = self.c.book("a-light-in-the-attic_1000")
        self.assertEqual((b.upc, b.category, b.stock_count, b.tax), ("a897fe39b1053632", "Poetry", 22, 0.0))

    def test_category_listing(self):
        p = self.c.books(1, "Poetry")
        self.assertGreater(len(p.books), 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
