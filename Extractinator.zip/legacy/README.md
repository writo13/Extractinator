# Books.toscrape unofficial API

An educational reverse-engineering project that wraps the publicly accessible pages at [books.toscrape.com](https://books.toscrape.com/) in a small Python client and JSON-over-HTTP interface. The target is a scraping-practice sandbox, not a production commerce site.

## Scope and responsible use

- Reads only public, unauthenticated pages.
- Does not bypass logins, CAPTCHAs, paywalls, or other access controls, and does not collect private data.
- Checks `robots.txt`, throttles requests, caches fetched pages in memory, and restricts requests to the configured site origin.
- The wrapper is intended for local demonstration and testing. Confirm the target's current access terms before deploying or increasing request volume.

## Setup

Python 3.10+ is recommended.

```bash
python -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
# macOS/Linux: source .venv/bin/activate
python -m pip install requests beautifulsoup4
```

## Run tests

```bash
python -m unittest -v test_books_api.py
```

The default suite uses deterministic, reconstructed HTML fixtures and makes no internet requests. To run the small live smoke-test set (requires internet access):

```bash
python test_books_api.py --live
```

Live tests are read-only, throttled, and may fail if the website changes or is temporarily unavailable.

## Start the local API

```bash
python books_api.py serve --port 8000
```

The server binds to `127.0.0.1` by default. Example requests:

```bash
curl http://127.0.0.1:8000/health
curl http://127.0.0.1:8000/categories
curl 'http://127.0.0.1:8000/books?page=1&category=Poetry'
curl http://127.0.0.1:8000/books/a-light-in-the-attic_1000
curl 'http://127.0.0.1:8000/search?q=light&min_rating=3&max_price=40&limit=10'
```

## Endpoint contract

| Method and route | Purpose | Important inputs |
|---|---|---|
| `GET /health` | Local process health | None; does not verify upstream availability |
| `GET /categories` | List category IDs, names, slugs, and source URLs | None |
| `GET /books` | Paginated book summaries | `page` (1-based), optional `category` (ID, slug, or name) |
| `GET /books/{ref}` | Full book details | Product slug/key, numeric book ID, or same-site product URL |
| `GET /search` | Search/filter summaries | `q`, `category`, `min_rating` (1–5), `min_price`, `max_price`, `in_stock` (`true`/`false`), `limit`, `max_pages` |

Responses are JSON. Errors use HTTP 400 for invalid inputs, 403 when disallowed by `robots.txt`, 404 for unknown routes/resources, and 502 for upstream, network, or parsing failures. `GET /health` only indicates that the local facade is responding.

## Architecture

1. `BooksClient` handles HTTP transport, robots checks, throttling, retry/backoff, in-memory caching, parsing, and filtering.
2. Dataclasses define stable response shapes independent of the source HTML.
3. `make_server` exposes the client through a small standard-library HTTP server.
4. `test_books_api.py` validates parsing and endpoint behavior against fixtures; optional live smoke tests detect drift in the real site.

## Limitations and long-term fix

- **HTML scraping is brittle:** CSS selectors and page structure can change. Parsing failures are surfaced rather than silently returning guessed data, but maintenance is still required.
- **Search is client-side:** the source has no search API, so filters require crawling listing pages. Limit the scope with `category`, `limit`, and `max_pages`.
- **Numeric-ID lookup is expensive:** the source URLs use slug-based identifiers, so resolving a numeric ID may require building an index by traversing listings.
- **Cache is process-local and has no TTL:** values can become stale until the process restarts; separate processes do not share cached responses.
- **Demo data is not authoritative commerce data:** prices and availability may be illustrative or change without notice.
- **Not production-hardened:** no authentication, persistent storage, distributed rate limiting, metrics, or formal service-level guarantees.

The durable fix is for the site owner to publish a documented, versioned API or data feed with stable IDs, pagination, and server-side filtering. Until then, keep scraping isolated behind this client, monitor selector health with scheduled live tests, respect the site's access policy, and obtain permission before scaling usage.
