from __future__ import annotations

import re
import threading
import time
from http.cookiejar import CookiePolicy
from collections import OrderedDict
from contextlib import closing
from dataclasses import dataclass, replace
from typing import Callable, TYPE_CHECKING
from urllib.parse import urljoin, urlparse

import requests
from protego import Protego

from extractinator import __version__

from .config import Settings
from .encoding import decode_body
from .exceptions import (
    FetchError,
    FetchTimeout,
    NetworkError,
    ResponseTooLarge,
    RobotsDisallowed,
    UnsupportedContentType,
    UpstreamError,
)
from .models import FetchResult
from .flows import redact_headers

if TYPE_CHECKING:
    from .flows import Flow, FlowStore
from .policy import URLPolicy

REDIRECT_CODES = {301, 302, 303, 307, 308}
MAX_REDIRECTS = 5
ROBOTS_MAX_BYTES = 512 * 1024  # RFC 9309: parsers must handle at least 500 KiB
ROBOTS_TTL = 24 * 3600.0
ROBOTS_FAILURE_TTL = 300.0
MAX_CRAWL_DELAY = 10.0
MAX_CACHEABLE_CHARS = 2_000_000
MAX_TRACKED_HOSTS = 1024


class _NoCookies(CookiePolicy):
    """Fetches are stateless: never store or send cookies, so API callers cannot share session state."""

    netscape = True
    rfc2965 = False
    hide_cookie2 = False

    def set_ok(self, cookie, request):
        return False

    def return_ok(self, cookie, request):
        return False

    def domain_return_ok(self, domain, request):
        return False

    def path_return_ok(self, path, request):
        return False


@dataclass
class _RobotsEntry:
    fetched_at: float
    ttl: float
    parser: Protego | None  # None means robots.txt was unreachable -> disallow everything
    crawl_delay: float | None = None


class Fetcher:
    """Polite HTTP fetcher for publicly accessible web pages."""

    RETRYABLE = {429, 500, 502, 503, 504}
    DEFAULT_CONTENT_TYPES = {
        "text/html",
        "application/xhtml+xml",
        "application/json",
        "application/ld+json",
        "text/plain",
    }

    def __init__(
        self,
        *,
        user_agent: str = f"Extractinator/{__version__}",
        delay: float = 0.5,
        retries: int = 3,
        backoff: float = 1.0,
        timeout: float = 15.0,
        max_bytes: int = 5_000_000,
        respect_robots: bool = True,
        cache_ttl: float = 3600.0,
        cache_max_entries: int = 64,
        session: requests.Session | None = None,
        policy: URLPolicy | None = None,
        clock: Callable[[], float] = time.monotonic,
        sleep: Callable[[float], None] = time.sleep,
        flow_store: "FlowStore | None" = None,
    ):
        self.user_agent = user_agent
        self.delay = max(0.0, delay)
        self.retries = max(0, retries)
        self.backoff = max(0.0, backoff)
        self.timeout = timeout
        self.max_bytes = max_bytes
        self.respect_robots = respect_robots
        self.cache_ttl = cache_ttl
        self.cache_max_entries = max(1, cache_max_entries)
        self.policy = policy or URLPolicy()
        self._clock = clock
        self._sleep = sleep
        self.flow_store = flow_store

        if session is None:
            session = requests.Session()
            session.cookies.set_policy(_NoCookies())
        self.session = session
        self.session.headers.update(
            {
                "User-Agent": self.user_agent,
                "Accept": "text/html,application/xhtml+xml,application/json,application/ld+json;q=0.9,*/*;q=0.1",
            }
        )

        # robots.txt matches on the product token ("Extractinator"), not the full UA string.
        self._agent_token = re.split(r"[/\s]", self.user_agent.strip(), maxsplit=1)[0]

        self._lock = threading.Lock()
        self._cache: OrderedDict[str, tuple[float, FetchResult]] = OrderedDict()
        self._robots: dict[str, _RobotsEntry] = {}
        self._next_slot: dict[str, float] = {}

    @classmethod
    def from_settings(cls, settings: Settings, **overrides) -> "Fetcher":
        options = dict(
            user_agent=settings.user_agent,
            delay=settings.delay,
            retries=settings.retries,
            backoff=settings.backoff,
            timeout=settings.timeout,
            max_bytes=settings.max_bytes,
            cache_ttl=settings.cache_ttl,
            cache_max_entries=settings.cache_max_entries,
        )
        options.update(overrides)
        return cls(**options)

    # ------------------------------------------------------------------ throttle
    @staticmethod
    def _origin(url: str) -> str:
        parsed = urlparse(url)
        return f"{parsed.scheme}://{parsed.netloc}".lower()

    def _delay_for(self, url: str) -> float:
        with self._lock:
            entry = self._robots.get(self._origin(url))
        if entry and entry.crawl_delay:
            return max(self.delay, min(entry.crawl_delay, MAX_CRAWL_DELAY))
        return self.delay

    def _throttle(self, url: str) -> None:
        """Space requests to one host `delay` seconds apart. Never sleeps while holding the lock."""
        key = urlparse(url).netloc.lower()
        delay = self._delay_for(url)
        with self._lock:
            now = self._clock()
            slot = max(now, self._next_slot.get(key, 0.0))
            self._next_slot[key] = slot + delay
            if len(self._next_slot) > MAX_TRACKED_HOSTS:
                self._next_slot.pop(next(iter(self._next_slot)))
        wait = slot - now
        if wait > 0:
            self._sleep(wait)

    # -------------------------------------------------------------------- robots
    def _robots_entry(self, url: str) -> _RobotsEntry:
        origin = self._origin(url)
        with self._lock:
            entry = self._robots.get(origin)
            if entry and self._clock() - entry.fetched_at < entry.ttl:
                return entry
        entry = self._download_robots(origin)
        with self._lock:
            self._robots[origin] = entry
            if len(self._robots) > MAX_TRACKED_HOSTS:
                self._robots.pop(next(iter(self._robots)))
        return entry

    def _download_robots(self, origin: str) -> _RobotsEntry:
        """RFC 9309: 2xx -> parse, 4xx -> no rules, 5xx / unreachable -> disallow everything."""
        now = self._clock()
        unreachable = _RobotsEntry(now, ROBOTS_FAILURE_TTL, None)
        try:
            response, _ = self._get(
                f"{origin}/robots.txt", check_robots=False, retries=min(self.retries, 1), record_flow=False
            )
        except FetchError:
            return unreachable

        with closing(response):
            status = response.status_code
            if 200 <= status < 300:
                try:
                    raw = self._read_body(response, ROBOTS_MAX_BYTES, truncate=True)
                except FetchError:
                    return unreachable
                text, _ = decode_body(raw, response.headers.get("Content-Type", ""))
                parser = Protego.parse(text)
                return _RobotsEntry(now, ROBOTS_TTL, parser, parser.crawl_delay(self._agent_token))
            if 400 <= status < 500:
                return _RobotsEntry(now, ROBOTS_TTL, Protego.parse(""))
        return unreachable

    def _check_robots(self, url: str) -> None:
        entry = self._robots_entry(url)
        if entry.parser is None:
            raise RobotsDisallowed(
                f"robots.txt for {self._origin(url)} could not be retrieved, "
                "so fetching is refused (RFC 9309)."
            )
        if not entry.parser.can_fetch(url, self._agent_token):
            raise RobotsDisallowed(f"Blocked by robots.txt: {url}")

    # --------------------------------------------------------------------- cache
    def _cache_get(self, url: str) -> FetchResult | None:
        with self._lock:
            item = self._cache.get(url)
            if item is None:
                return None
            stamp, result = item
            if self._clock() - stamp > self.cache_ttl:
                del self._cache[url]
                return None
            self._cache.move_to_end(url)
            return result

    def _cache_put(self, url: str, result: FetchResult) -> None:
        if len(result.text) > MAX_CACHEABLE_CHARS:
            return
        with self._lock:
            self._cache[url] = (self._clock(), result)
            self._cache.move_to_end(url)
            while len(self._cache) > self.cache_max_entries:
                self._cache.popitem(last=False)

    # ---------------------------------------------------------------------- http
    def _open(self, url: str, *, check_robots: bool, capture: "Flow | None" = None) -> tuple[requests.Response, str]:
        """GET `url`, following redirects by hand so every hop is validated, robots-checked and throttled."""
        current = url
        for _ in range(MAX_REDIRECTS + 1):
            self.policy.validate(current)
            if check_robots:
                self._check_robots(current)
            self._throttle(current)
            if capture is not None:
                capture.add_event("request", f"GET {current}")

            try:
                response = self.session.get(
                    current, timeout=self.timeout, allow_redirects=False, stream=True
                )
            except requests.Timeout as exc:
                raise FetchTimeout(f"Timed out fetching {current}") from exc
            except requests.RequestException as exc:
                raise NetworkError(
                    f"Network error fetching {current}: {type(exc).__name__}: {str(exc)[:200]}"
                ) from exc

            if capture is not None:
                capture.response.status = response.status_code
                capture.response.url = current
                capture.response.reason = response.reason or ""
                capture.response.headers = redact_headers(response.headers)

            if response.status_code not in REDIRECT_CODES:
                return response, current

            location = response.headers.get("Location")
            response.close()
            if not location:
                raise FetchError("Redirect response did not include Location.")
            target = urljoin(current, location).split("#", 1)[0]
            if capture is not None:
                capture.redirects.append(target)
                capture.add_event("redirect", f"{response.status_code} -> {target}")
            if target == current:
                raise FetchError("Redirect loop detected.")
            current = target
        raise FetchError("Maximum redirect count exceeded.")

    def _get(
        self, url: str, *, check_robots: bool, retries: int | None = None, record_flow: bool = True, capture: "Flow | None" = None
    ) -> tuple[requests.Response, str]:
        """Like _open, but retries network failures and 429/5xx with exponential backoff.

        Returns any non-retryable response (including 4xx) for the caller to interpret.
        """
        attempts = self.retries if retries is None else retries
        last_error: FetchError | None = None
        for attempt in range(attempts + 1):
            pause = self.backoff * (2**attempt)
            try:
                response, final_url = self._open(url, check_robots=check_robots, capture=capture if record_flow else None)
            except (NetworkError, FetchTimeout) as exc:
                last_error = exc
                if capture is not None:
                    capture.add_event("error", str(exc))
            else:
                if response.status_code not in self.RETRYABLE:
                    return response, final_url
                status = response.status_code
                retry_after = response.headers.get("Retry-After", "")
                response.close()
                last_error = UpstreamError(f"HTTP {status} from {final_url}", status)
                if capture is not None:
                    capture.add_event("retry", f"HTTP {status}")
                if retry_after.isdigit():
                    pause = max(pause, min(int(retry_after), 30))
            if attempt < attempts:
                self._sleep(pause)
        assert last_error is not None
        raise last_error

    def _read_body(self, response: requests.Response, max_bytes: int, *, truncate: bool = False) -> bytes:
        declared = response.headers.get("Content-Length", "")
        if declared.isdigit() and int(declared) > max_bytes and not truncate:
            raise ResponseTooLarge(f"Response is {declared} bytes; the limit is {max_bytes}.")

        data = bytearray()
        try:
            for chunk in response.iter_content(chunk_size=64 * 1024):
                if not chunk:
                    continue
                data.extend(chunk)
                if len(data) > max_bytes:
                    if truncate:
                        return bytes(data[:max_bytes])
                    raise ResponseTooLarge(f"Response exceeded {max_bytes} bytes.")
        except requests.Timeout as exc:
            raise FetchTimeout("Timed out while reading the response body.") from exc
        except requests.RequestException as exc:
            raise NetworkError(
                f"Error while reading the response body: {type(exc).__name__}: {str(exc)[:200]}"
            ) from exc
        return bytes(data)

    # --------------------------------------------------------------------- fetch
    def fetch(self, url: str) -> FetchResult:
        from .flows import Flow, HttpMessage, FlowTiming
        start = self._clock()
        capture = Flow(source="fetcher")
        capture.request = HttpMessage(
            method="GET",
            url=url,
            headers={k: v for k, v in self.session.headers.items()},
        )
        if self.flow_store is not None:
            capture.add_event("started", "fetch")

        try:
            self.policy.validate(url)
            cached = self._cache_get(url)
            if cached is not None:
                capture.from_cache = True
                capture.state = "cached"
                capture.request.url = url
                capture.response = HttpMessage(
                    status=cached.status_code,
                    reason="OK",
                    http_version="HTTP/1.1",
                    headers={},
                    body=cached.text,
                    body_size=len(cached.text.encode("utf-8", errors="replace")),
                    url=cached.url,
                )
                capture.timing.total_ms = max(0.0, (self._clock() - start) * 1000)
                capture.finish(state="cached")
                if self.flow_store is not None:
                    self.flow_store.save(capture)
                return replace(cached, from_cache=True, flow_id=capture.id)

            response, final_url = self._get(
                url,
                check_robots=self.respect_robots,
                record_flow=True,
                capture=capture,
            )
            with closing(response):
                status = response.status_code
                header = response.headers.get("Content-Type", "")
                capture.response.status = status
                capture.response.reason = response.reason or ""
                capture.response.url = final_url
                capture.response.headers = redact_headers(response.headers)
                capture.request.url = url
                capture.add_event("response", f"HTTP {status}")
                if not 200 <= status < 300:
                    raise UpstreamError(f"HTTP {status} from {final_url}", status)

                content_type = header.split(";", 1)[0].strip().lower()
                if content_type and content_type not in self.DEFAULT_CONTENT_TYPES:
                    raise UnsupportedContentType(f"Unsupported content type: {content_type}")

                raw = self._read_body(response, self.max_bytes)

            text, encoding = decode_body(raw, header)
            response_size = len(raw)
            capture.response.body = text[:MAX_CACHEABLE_CHARS]
            capture.response.body_encoding = None
            capture.response.body_size = response_size
            elapsed_ms = max(0.0, (self._clock() - start) * 1000)
            capture.timing = FlowTiming(total_ms=elapsed_ms, wait_ms=elapsed_ms)
            capture.finish(state="completed")
            if self.flow_store is not None:
                self.flow_store.save(capture)

            result = FetchResult(
                url=final_url,
                status_code=status,
                content_type=content_type or "text/html",
                text=text,
                encoding=encoding,
                redirected_from=url if final_url != url else None,
                flow_id=capture.id,
            )
            self._cache_put(url, result)
            return result
        except Exception as exc:
            capture.timing.total_ms = max(0.0, (self._clock() - start) * 1000)
            capture.finish(state="error", error=exc)
            if self.flow_store is not None:
                self.flow_store.save(capture)
            raise
