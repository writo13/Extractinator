from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


@dataclass
class FetchResult:
    url: str  # final URL, after redirects
    status_code: int
    content_type: str
    text: str
    encoding: str | None = None
    redirected_from: str | None = None
    from_cache: bool = False
    flow_id: str | None = None

    @property
    def requested_url(self) -> str:
        return self.redirected_from or self.url


@dataclass
class ExtractionResult:
    url: str
    type: str
    data: dict[str, Any]
    method: str
    adapter: str | None = None
    warnings: list[str] = field(default_factory=list)
    retrieved_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    requested_url: str | None = None
    content_type: str | None = None
    cached: bool = False

    def as_dict(self) -> dict[str, Any]:
        return {
            "source": {
                "url": self.url,
                "requested_url": self.requested_url or self.url,
                "retrieved_at": self.retrieved_at,
                "method": self.method,
                "adapter": self.adapter,
                "content_type": self.content_type,
                "cached": self.cached,
            },
            "data": self.data,
            "warnings": self.warnings,
        }
