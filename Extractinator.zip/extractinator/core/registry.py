from __future__ import annotations

from typing import Iterable

from extractinator.adapters.base import Adapter


class AdapterRegistry:
    def __init__(self, adapters: Iterable[Adapter] | None = None):
        self._adapters: list[Adapter] = list(adapters or [])

    def register(self, adapter: Adapter) -> None:
        self._adapters.append(adapter)

    def find(self, url: str) -> Adapter | None:
        for adapter in self._adapters:
            if adapter.can_handle(url):
                return adapter
        return None

    def names(self) -> list[str]:
        return [adapter.name for adapter in self._adapters]
