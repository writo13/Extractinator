"""Exception hierarchy. Each class carries the HTTP status the API should answer with."""


class ExtractinatorError(Exception):
    """Base exception for Extractinator."""

    status_code = 500


class FetchError(ExtractinatorError):
    """Upstream fetching failed."""

    status_code = 502


class NetworkError(FetchError):
    """Could not connect to, or read from, the upstream server."""

    status_code = 502


class FetchTimeout(FetchError):
    """The upstream server did not answer in time."""

    status_code = 504


class UpstreamError(FetchError):
    """The upstream server answered with an error status."""

    def __init__(self, message: str, upstream_status: int | None = None):
        super().__init__(message)
        self.upstream_status = upstream_status

    @property
    def status_code(self) -> int:  # type: ignore[override]
        return 404 if self.upstream_status in (404, 410) else 502


class RobotsDisallowed(FetchError):
    """The requested URL is disallowed by robots.txt (or robots.txt is unreachable)."""

    status_code = 403


class URLNotAllowed(FetchError):
    """The URL is outside the public-web policy."""

    status_code = 400


class ResponseTooLarge(FetchError):
    """The upstream response exceeded the configured size limit."""

    status_code = 413


class UnsupportedContentType(FetchError):
    """The response content type is not supported."""

    status_code = 415


class ExtractionError(ExtractinatorError):
    """A page could not be extracted."""

    status_code = 422
