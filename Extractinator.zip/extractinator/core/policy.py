from __future__ import annotations

import ipaddress
import socket
from urllib.parse import urlparse

from .exceptions import URLNotAllowed

_BLOCKED_NAMES = ("localhost",)
_BLOCKED_SUFFIXES = (".localhost", ".local", ".internal", ".localdomain", ".home.arpa")
_NAT64 = ipaddress.ip_network("64:ff9b::/96")


class URLPolicy:
    """Conservative public-web URL policy used by the fetcher."""

    def __init__(self, allow_ports: set[int] | None = None):
        self.allow_ports = allow_ports or {80, 443}

    def validate(self, url: str, *, resolve: bool = True) -> None:
        """Raise URLNotAllowed unless `url` points at the public web.

        With resolve=False no DNS lookup is made (used by the cheap /capabilities check);
        the full check always runs again before a real fetch.
        """
        try:
            parsed = urlparse(url)
            port = parsed.port
        except ValueError as exc:
            raise URLNotAllowed("Malformed URL or invalid port.") from exc

        if parsed.scheme not in {"http", "https"}:
            raise URLNotAllowed("Only HTTP and HTTPS URLs are allowed.")

        host = (parsed.hostname or "").rstrip(".")
        if not host:
            raise URLNotAllowed("URL must contain a hostname.")

        if parsed.username or parsed.password:
            raise URLNotAllowed("URLs containing user credentials are not allowed.")

        if port is not None and port not in self.allow_ports:
            raise URLNotAllowed("Only standard HTTP/HTTPS ports are allowed.")

        if host in _BLOCKED_NAMES or host.endswith(_BLOCKED_SUFFIXES):
            raise URLNotAllowed(f"Local hostnames are not allowed: {host}")

        try:
            address = ipaddress.ip_address(host)
        except ValueError:
            pass
        else:
            self._validate_ip(address)
            return

        if not resolve:
            return

        try:
            infos = socket.getaddrinfo(
                host, port or (443 if parsed.scheme == "https" else 80)
            )
        except socket.gaierror as exc:
            raise URLNotAllowed(f"Unable to resolve hostname: {host}") from exc

        for info in infos:
            self._validate_ip(ipaddress.ip_address(info[4][0]))

    @classmethod
    def _validate_ip(cls, address: ipaddress._BaseAddress) -> None:
        for candidate in cls._embedded_addresses(address):
            if (
                not candidate.is_global
                or candidate.is_private
                or candidate.is_loopback
                or candidate.is_link_local
                or candidate.is_reserved
                or candidate.is_multicast
                or candidate.is_unspecified
            ):
                raise URLNotAllowed(
                    f"Local or non-public network address is not allowed: {address}"
                )

    @staticmethod
    def _embedded_addresses(address: ipaddress._BaseAddress) -> list[ipaddress._BaseAddress]:
        """The address itself plus any IPv4 address smuggled inside an IPv6 one."""
        found: list[ipaddress._BaseAddress] = [address]
        if isinstance(address, ipaddress.IPv6Address):
            if address.ipv4_mapped:
                found.append(address.ipv4_mapped)
            if address.sixtofour:
                found.append(address.sixtofour)
            if address.teredo:
                found.extend(address.teredo)
            if address in _NAT64:
                found.append(ipaddress.IPv4Address(int(address) & 0xFFFFFFFF))
        return found
