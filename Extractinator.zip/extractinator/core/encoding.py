"""Decode HTTP bodies the way browsers do (BOM, header charset, <meta> charset, UTF-8, cp1252).

`requests` defaults text/* responses without a charset to ISO-8859-1, which turns UTF-8
pages into mojibake ("£" becomes "Â£"), so we never rely on `response.encoding`.
"""

from __future__ import annotations

import codecs
import re

_HEADER_CHARSET = re.compile(r"charset\s*=\s*[\"']?\s*([\w.:-]+)", re.I)
_META_CHARSET = re.compile(rb"<meta[^>]{0,400}?charset\s*=\s*[\"']?\s*([\w.:-]+)", re.I)

# The HTML spec treats these labels as windows-1252.
_ALIASES = {"iso-8859-1": "cp1252", "latin1": "cp1252", "latin-1": "cp1252", "ascii": "cp1252", "us-ascii": "cp1252"}

_BOMS = (
    (codecs.BOM_UTF8, "utf-8-sig"),
    (codecs.BOM_UTF16_LE, "utf-16"),
    (codecs.BOM_UTF16_BE, "utf-16"),
)


def _usable(name: str) -> str | None:
    name = _ALIASES.get(name.strip().lower(), name.strip().lower())
    try:
        codecs.lookup(name)
    except LookupError:
        return None
    return name


def decode_body(raw: bytes, content_type_header: str = "") -> tuple[str, str]:
    """Return (text, encoding_used)."""
    for bom, encoding in _BOMS:
        if raw.startswith(bom):
            return raw.decode(encoding, errors="replace"), encoding

    candidates: list[str] = []
    header = _HEADER_CHARSET.search(content_type_header or "")
    if header:
        candidates.append(header.group(1))
    meta = _META_CHARSET.search(raw[:4096])
    if meta:
        candidates.append(meta.group(1).decode("ascii", errors="ignore"))

    for candidate in candidates:
        encoding = _usable(candidate)
        if encoding:
            return raw.decode(encoding, errors="replace"), encoding

    try:
        return raw.decode("utf-8"), "utf-8"
    except UnicodeDecodeError:
        return raw.decode("cp1252", errors="replace"), "cp1252"
