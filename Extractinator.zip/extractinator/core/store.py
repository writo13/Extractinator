from __future__ import annotations

import hashlib
import json
import os
import secrets
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class Store:
    """Small SQLite-backed store for generated APIs, local tokens, and captures.

    Plaintext tokens are never persisted. The token value is returned once at creation time.
    """

    def __init__(self, path: str = "data/extractinator.db"):
        self.path = path
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=10)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS api_tokens (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    token_hash TEXT NOT NULL UNIQUE,
                    prefix TEXT NOT NULL,
                    scopes TEXT NOT NULL,
                    expires_at TEXT,
                    revoked INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS generated_apis (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    slug TEXT NOT NULL UNIQUE,
                    name TEXT NOT NULL,
                    method TEXT NOT NULL,
                    upstream_url TEXT NOT NULL,
                    description TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    enabled INTEGER NOT NULL DEFAULT 1
                );
                CREATE TABLE IF NOT EXISTS captures (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    method TEXT NOT NULL,
                    url TEXT NOT NULL,
                    headers TEXT NOT NULL,
                    body TEXT,
                    created_at TEXT NOT NULL
                );
                """
            )

    @staticmethod
    def _hash_token(token: str) -> str:
        return hashlib.sha256(token.encode("utf-8")).hexdigest()

    def create_token(self, name: str, scopes: list[str], expires_at: str | None) -> dict[str, Any]:
        token = "ext_live_" + secrets.token_urlsafe(32)
        prefix = token[:16]
        token_hash = self._hash_token(token)
        with self._lock, self._connect() as conn:
            cur = conn.execute(
                "INSERT INTO api_tokens(name, token_hash, prefix, scopes, expires_at, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                (name, token_hash, prefix, json.dumps(scopes), expires_at, _now()),
            )
            token_id = cur.lastrowid
        return {
            "id": token_id,
            "name": name,
            "token": token,
            "prefix": prefix,
            "scopes": scopes,
            "expires_at": expires_at,
        }

    def verify_token(self, token: str, required_scope: str = "invoke") -> bool:
        token_hash = self._hash_token(token)
        with self._connect() as conn:
            row = conn.execute(
                "SELECT scopes, expires_at, revoked FROM api_tokens WHERE token_hash = ?",
                (token_hash,),
            ).fetchone()
        if row is None or row["revoked"]:
            return False
        if row["expires_at"]:
            try:
                expires = datetime.fromisoformat(row["expires_at"])
            except ValueError:
                return False
            if expires.tzinfo is None:
                expires = expires.replace(tzinfo=timezone.utc)
            if expires <= datetime.now(timezone.utc):
                return False
        return required_scope in json.loads(row["scopes"])

    def list_tokens(self) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT id, name, prefix, scopes, expires_at, revoked, created_at FROM api_tokens ORDER BY id DESC"
            ).fetchall()
        return [
            {
                "id": row["id"],
                "name": row["name"],
                "prefix": row["prefix"],
                "scopes": json.loads(row["scopes"]),
                "expires_at": row["expires_at"],
                "revoked": bool(row["revoked"]),
                "created_at": row["created_at"],
            }
            for row in rows
        ]

    def revoke_token(self, token_id: int) -> bool:
        with self._lock, self._connect() as conn:
            cur = conn.execute("UPDATE api_tokens SET revoked = 1 WHERE id = ?", (token_id,))
            return cur.rowcount > 0

    def create_api(self, name: str, slug: str, method: str, upstream_url: str, description: str = "") -> dict[str, Any]:
        with self._lock, self._connect() as conn:
            cur = conn.execute(
                "INSERT INTO generated_apis(slug, name, method, upstream_url, description, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                (slug, name, method, upstream_url, description, _now()),
            )
            api_id = cur.lastrowid
        return self.get_api(api_id)

    def get_api(self, api_id: int) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM generated_apis WHERE id = ?", (api_id,)).fetchone()
        return dict(row) if row else None

    def get_api_by_slug(self, slug: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM generated_apis WHERE slug = ? AND enabled = 1", (slug,)).fetchone()
        return dict(row) if row else None

    def list_apis(self) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM generated_apis ORDER BY id DESC").fetchall()
        return [dict(row) for row in rows]

    def disable_api(self, api_id: int) -> bool:
        with self._lock, self._connect() as conn:
            cur = conn.execute("UPDATE generated_apis SET enabled = 0 WHERE id = ?", (api_id,))
            return cur.rowcount > 0

    def add_capture(self, method: str, url: str, headers: dict[str, str], body: str | None = None) -> dict[str, Any]:
        safe_headers = {k: v for k, v in headers.items()}
        with self._lock, self._connect() as conn:
            cur = conn.execute(
                "INSERT INTO captures(method, url, headers, body, created_at) VALUES (?, ?, ?, ?, ?)",
                (method, url, json.dumps(safe_headers), body, _now()),
            )
            capture_id = cur.lastrowid
        return self.get_capture(capture_id)

    def get_capture(self, capture_id: int) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM captures WHERE id = ?", (capture_id,)).fetchone()
        if not row:
            return None
        result = dict(row)
        result["headers"] = json.loads(result["headers"])
        return result

    def list_captures(self, limit: int = 100) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM captures ORDER BY id DESC LIMIT ?",
                (max(1, min(limit, 500)),),
            ).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["headers"] = json.loads(item["headers"])
            result.append(item)
        return result

    def delete_capture(self, capture_id: int) -> bool:
        with self._lock, self._connect() as conn:
            cur = conn.execute("DELETE FROM captures WHERE id = ?", (capture_id,))
            return cur.rowcount > 0
