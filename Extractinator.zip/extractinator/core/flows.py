from __future__ import annotations

import base64
import json
import re
import shlex
import sqlite3
import threading
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

SENSITIVE_HEADERS = {
    "authorization",
    "proxy-authorization",
    "cookie",
    "set-cookie",
    "www-authenticate",
    "x-api-key",
    "x-auth-token",
    "x-access-token",
    "x-csrf-token",
    "x-xsrf-token",
}
SENSITIVE_QUERY_KEYS = {
    "access_token",
    "api_key",
    "apikey",
    "auth",
    "authorization",
    "client_secret",
    "code",
    "id_token",
    "jwt",
    "refresh_token",
    "session",
    "session_id",
    "token",
}
MAX_STORED_BODY = 1_000_000


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def redact_headers(headers: dict[str, Any] | Iterable[tuple[str, Any]]) -> dict[str, str]:
    pairs = headers.items() if hasattr(headers, "items") else headers
    result: dict[str, str] = {}
    for key, value in pairs:
        if key.lower() in SENSITIVE_HEADERS:
            result[str(key)] = "<redacted>"
        else:
            result[str(key)] = str(value)
    return result


def redact_url(url: str) -> str:
    try:
        parsed = urlparse(url)
        query = []
        for key, value in parse_qsl(parsed.query, keep_blank_values=True):
            query.append((key, "<redacted>" if key.lower() in SENSITIVE_QUERY_KEYS else value))
        return urlunparse(parsed._replace(query=urlencode(query, doseq=True)))
    except Exception:
        return url


def decode_har_text(text: Any, encoding: str | None) -> str | None:
    if text is None:
        return None
    if not isinstance(text, str):
        return str(text)
    if encoding != "base64":
        return text
    try:
        raw = base64.b64decode(text, validate=False)
        return raw.decode("utf-8", errors="replace")
    except Exception:
        return None


def body_size(body: str | None) -> int:
    return len(body.encode("utf-8", errors="replace")) if body else 0


@dataclass
class FlowTiming:
    blocked_ms: float | None = None
    dns_ms: float | None = None
    connect_ms: float | None = None
    tls_ms: float | None = None
    send_ms: float | None = None
    wait_ms: float | None = None
    receive_ms: float | None = None
    total_ms: float | None = None


@dataclass
class HttpMessage:
    method: str | None = None
    url: str | None = None
    status: int | None = None
    reason: str | None = None
    http_version: str = "HTTP/1.1"
    headers: dict[str, str] = field(default_factory=dict)
    body: str | None = None
    body_encoding: str | None = None
    body_size: int = 0


@dataclass
class FlowEvent:
    name: str
    at: str
    detail: str | None = None


@dataclass
class Flow:
    id: str = field(default_factory=lambda: uuid.uuid4().hex)
    sequence: int = 0
    source: str = "fetcher"
    state: str = "started"
    started_at: str = field(default_factory=utc_now)
    ended_at: str | None = None
    request: HttpMessage = field(default_factory=HttpMessage)
    response: HttpMessage = field(default_factory=HttpMessage)
    timing: FlowTiming = field(default_factory=FlowTiming)
    redirects: list[str] = field(default_factory=list)
    events: list[FlowEvent] = field(default_factory=list)
    error: str | None = None
    error_type: str | None = None
    extraction: dict[str, Any] | None = None
    tags: list[str] = field(default_factory=list)
    from_cache: bool = False

    @property
    def duration_ms(self) -> float | None:
        return self.timing.total_ms

    @property
    def status(self) -> int | None:
        return self.response.status

    def add_event(self, name: str, detail: str | None = None) -> None:
        self.events.append(FlowEvent(name=name, at=utc_now(), detail=detail))

    def finish(self, *, state: str = "completed", error: Exception | None = None) -> None:
        self.state = state
        self.ended_at = utc_now()
        if error is not None:
            self.error = str(error)[:500]
            self.error_type = type(error).__name__

    def as_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["duration_ms"] = self.duration_ms
        data["status"] = self.status
        return data


@dataclass
class FlowQuery:
    method: str | None = None
    statuses: set[int] = field(default_factory=set)
    status_classes: set[int] = field(default_factory=set)
    url_substring: str | None = None
    source: str | None = None
    header_matches: list[tuple[str, str]] = field(default_factory=list)
    body_terms: list[str] = field(default_factory=list)
    errors_only: bool = False
    redirects_only: bool = False
    has_request_body: bool = False
    has_response_body: bool = False

    def predicate(self, flow: Flow) -> bool:
        if self.method and (flow.request.method or "").upper() != self.method:
            return False
        if self.statuses and flow.status not in self.statuses:
            return False
        if self.status_classes:
            if flow.status is None or flow.status // 100 not in self.status_classes:
                return False
        if self.url_substring:
            haystack = (flow.request.url or "").lower()
            if self.url_substring.lower() not in haystack:
                return False
        if self.source and flow.source.lower() != self.source.lower():
            return False
        if self.errors_only and not flow.error:
            return False
        if self.redirects_only and not flow.redirects:
            return False
        if self.has_request_body and not flow.request.body:
            return False
        if self.has_response_body and not flow.response.body:
            return False
        merged_headers = {**flow.request.headers, **flow.response.headers}
        for key, value in self.header_matches:
            actual = merged_headers.get(key.lower())
            if actual is None:
                actual = next((v for k, v in merged_headers.items() if k.lower() == key.lower()), None)
            if actual is None or value.lower() not in actual.lower():
                return False
        if self.body_terms:
            body = "\n".join(x for x in (flow.request.body, flow.response.body) if x).lower()
            if any(term.lower() not in body for term in self.body_terms):
                return False
        return True


def compile_filter(expression: str = "", *, method: str | None = None, status: str | None = None,
                   header: list[str] | None = None, body: str | None = None,
                   url: str | None = None, source: str | None = None,
                   error: bool = False, redirect: bool = False) -> Callable[[Flow], bool]:
    query = FlowQuery(method=(method or "").upper() or None, url_substring=url, source=source,
                      errors_only=error, redirects_only=redirect)
    if status:
        for token in re.split(r"[,\s]+", status.strip()):
            if not token:
                continue
            if re.fullmatch(r"[1-5]xx", token.lower()):
                query.status_classes.add(int(token[0]))
            else:
                query.statuses.add(int(token))
    if header:
        for item in header:
            key, sep, value = item.partition("=")
            if sep and key.strip():
                query.header_matches.append((key.strip(), value.strip()))
    if body:
        query.body_terms.append(body)
    if expression.strip():
        for token in shlex.split(expression):
            key, sep, value = token.partition(":")
            if not sep:
                query.body_terms.append(token)
                continue
            key = key.lower()
            if key == "method":
                query.method = value.upper()
            elif key == "status":
                if re.fullmatch(r"[1-5]xx", value.lower()):
                    query.status_classes.add(int(value[0]))
                else:
                    query.statuses.add(int(value))
            elif key == "url":
                query.url_substring = value
            elif key == "source":
                query.source = value
            elif key == "header":
                hkey, _, hval = value.partition("=")
                query.header_matches.append((hkey, hval))
            elif key == "body":
                query.body_terms.append(value)
            elif key == "has" and value == "request-body":
                query.has_request_body = True
            elif key == "has" and value == "response-body":
                query.has_response_body = True
            elif key == "error":
                query.errors_only = value.lower() in {"1", "true", "yes"}
            elif key == "redirect":
                query.redirects_only = value.lower() in {"1", "true", "yes"}
    return query.predicate


class FlowStore:
    """SQLite-backed flow store. Body-search is deliberately performed after bounded JSON load."""

    def __init__(self, path: str = "data/extractinator.db"):
        self.path = path
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=10)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS flow_meta (key TEXT PRIMARY KEY, value INTEGER NOT NULL);
                INSERT OR IGNORE INTO flow_meta(key, value) VALUES ('sequence', 0);
                CREATE TABLE IF NOT EXISTS flows (
                    id TEXT PRIMARY KEY,
                    sequence INTEGER NOT NULL UNIQUE,
                    source TEXT NOT NULL,
                    state TEXT NOT NULL,
                    started_at TEXT NOT NULL,
                    ended_at TEXT,
                    status INTEGER,
                    method TEXT,
                    url TEXT,
                    has_error INTEGER NOT NULL DEFAULT 0,
                    payload TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_flows_sequence ON flows(sequence DESC);
                CREATE INDEX IF NOT EXISTS idx_flows_status ON flows(status);
                CREATE INDEX IF NOT EXISTS idx_flows_method ON flows(method);
                """
            )

    def _assign_sequence(self, conn: sqlite3.Connection) -> int:
        row = conn.execute("SELECT value FROM flow_meta WHERE key='sequence'").fetchone()
        seq = int(row[0]) + 1
        conn.execute("UPDATE flow_meta SET value=? WHERE key='sequence'", (seq,))
        return seq

    def save(self, flow: Flow) -> Flow:
        with self._lock, self._connect() as conn:
            if not flow.sequence:
                flow.sequence = self._assign_sequence(conn)
            else:
                row = conn.execute("SELECT sequence FROM flows WHERE id=?", (flow.id,)).fetchone()
                if row is None:
                    max_row = conn.execute("SELECT value FROM flow_meta WHERE key='sequence'").fetchone()
                    if max_row and int(max_row[0]) < flow.sequence:
                        conn.execute("UPDATE flow_meta SET value=? WHERE key='sequence'", (flow.sequence,))
            payload = json.dumps(flow.as_dict(), ensure_ascii=False)
            conn.execute(
                """INSERT INTO flows(id, sequence, source, state, started_at, ended_at, status, method, url, has_error, payload)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                   ON CONFLICT(id) DO UPDATE SET sequence=excluded.sequence, source=excluded.source,
                   state=excluded.state, started_at=excluded.started_at, ended_at=excluded.ended_at,
                   status=excluded.status, method=excluded.method, url=excluded.url,
                   has_error=excluded.has_error, payload=excluded.payload""",
                (flow.id, flow.sequence, flow.source, flow.state, flow.started_at, flow.ended_at,
                 flow.status, flow.request.method, flow.request.url, int(bool(flow.error)), payload),
            )
        return flow

    def get(self, flow_id: str) -> Flow | None:
        with self._connect() as conn:
            row = conn.execute("SELECT payload FROM flows WHERE id=?", (flow_id,)).fetchone()
        return flow_from_dict(json.loads(row[0])) if row else None

    def list(self, predicate: Callable[[Flow], bool] | None = None, limit: int = 200) -> list[Flow]:
        limit = max(1, min(limit, 5000))
        with self._connect() as conn:
            rows = conn.execute("SELECT payload FROM flows ORDER BY sequence DESC LIMIT ?", (limit,)).fetchall()
        flows = [flow_from_dict(json.loads(row[0])) for row in rows]
        return [flow for flow in flows if predicate is None or predicate(flow)]

    def delete(self, flow_id: str) -> bool:
        with self._lock, self._connect() as conn:
            cur = conn.execute("DELETE FROM flows WHERE id=?", (flow_id,))
            return cur.rowcount > 0

    def clear(self) -> int:
        with self._lock, self._connect() as conn:
            cur = conn.execute("DELETE FROM flows")
            return cur.rowcount

    def import_flows(self, flows: Iterable[Flow]) -> list[Flow]:
        saved = []
        for flow in flows:
            flow.sequence = 0  # imported data receives local sequence ordering
            saved.append(self.save(flow))
        return saved

    def export_har(self, predicate: Callable[[Flow], bool] | None = None, limit: int = 5000) -> dict[str, Any]:
        flows = list(reversed(self.list(predicate, limit)))
        return flows_to_har(flows)


def flow_from_dict(data: dict[str, Any]) -> Flow:
    request = HttpMessage(**(data.get("request") or {}))
    response = HttpMessage(**(data.get("response") or {}))
    timing = FlowTiming(**(data.get("timing") or {}))
    events = [FlowEvent(**event) for event in data.get("events", []) if isinstance(event, dict)]
    return Flow(
        id=data.get("id", uuid.uuid4().hex), sequence=int(data.get("sequence", 0) or 0),
        source=data.get("source", "import"), state=data.get("state", "completed"),
        started_at=data.get("started_at") or utc_now(), ended_at=data.get("ended_at"),
        request=request, response=response, timing=timing, redirects=list(data.get("redirects", [])),
        events=events, error=data.get("error"), error_type=data.get("error_type"),
        extraction=data.get("extraction"), tags=list(data.get("tags", [])), from_cache=bool(data.get("from_cache")),
    )


def flow_to_har(flow: Flow) -> dict[str, Any]:
    req = flow.request
    res = flow.response
    parsed = urlparse(req.url or "")
    body = res.body or ""
    content: dict[str, Any] = {
        "size": len(body.encode("utf-8", errors="replace")),
        "mimeType": res.headers.get("Content-Type", "text/plain"),
        "text": body,
    }
    if res.body_encoding == "base64":
        content["encoding"] = "base64"
    total = flow.timing.total_ms or 0.0
    send_ms = flow.timing.send_ms or 0.0
    wait_ms = flow.timing.wait_ms or 0.0
    receive_ms = flow.timing.receive_ms or max(0.0, total - send_ms - wait_ms)
    return {
        "startedDateTime": flow.started_at,
        "time": total,
        "request": {
            "method": req.method or "GET",
            "url": redact_url(req.url or ""),
            "httpVersion": req.http_version,
            "headers": [{"name": k, "value": v} for k, v in redact_headers(req.headers).items()],
            "queryString": [{"name": k, "value": "<redacted>" if k.lower() in SENSITIVE_QUERY_KEYS else v} for k, v in parse_qsl(parsed.query, keep_blank_values=True)],
            "cookies": [],
            "headersSize": -1,
            "bodySize": req.body_size,
            **({"postData": {"mimeType": req.headers.get("Content-Type", ""), "text": req.body}} if req.body else {}),
        },
        "response": {
            "status": res.status or 0,
            "statusText": res.reason or "",
            "httpVersion": res.http_version,
            "headers": [{"name": k, "value": v} for k, v in redact_headers(res.headers).items()],
            "cookies": [],
            "content": content,
            "redirectURL": flow.redirects[-1] if flow.redirects else "",
            "headersSize": -1,
            "bodySize": res.body_size,
        },
        "cache": {},
        "timings": {
            "blocked": flow.timing.blocked_ms if flow.timing.blocked_ms is not None else -1,
            "dns": flow.timing.dns_ms if flow.timing.dns_ms is not None else -1,
            "connect": flow.timing.connect_ms if flow.timing.connect_ms is not None else -1,
            "ssl": flow.timing.tls_ms if flow.timing.tls_ms is not None else -1,
            "send": send_ms,
            "wait": wait_ms,
            "receive": receive_ms,
        },
        "comment": json.dumps({"extractinator": {"id": flow.id, "sequence": flow.sequence, "source": flow.source}}),
    }


def flows_to_har(flows: Iterable[Flow]) -> dict[str, Any]:
    return {
        "log": {
            "version": "1.2",
            "creator": {"name": "Extractinator", "version": "0.4.0"},
            "entries": [flow_to_har(flow) for flow in flows],
        }
    }


def har_to_flows(document: dict[str, Any], *, source: str = "har") -> tuple[list[Flow], list[str]]:
    warnings: list[str] = []
    entries = (((document or {}).get("log") or {}).get("entries"))
    if not isinstance(entries, list):
        return [], ["HAR document has no log.entries array."]
    flows: list[Flow] = []
    for index, entry in enumerate(entries):
        if not isinstance(entry, dict):
            warnings.append(f"Entry {index}: ignored non-object entry.")
            continue
        try:
            request = entry["request"]
            response = entry.get("response") or {}
            url = str(request["url"])
            method = str(request.get("method", "GET")).upper()
            req_headers = {str(h["name"]): str(h.get("value", "")) for h in request.get("headers", []) if isinstance(h, dict) and "name" in h}
            res_headers = {str(h["name"]): str(h.get("value", "")) for h in response.get("headers", []) if isinstance(h, dict) and "name" in h}
            post_data = request.get("postData") or {}
            response_content = response.get("content") or {}
            req_body = post_data.get("text") if isinstance(post_data, dict) else None
            res_body = decode_har_text(response_content.get("text"), response_content.get("encoding")) if isinstance(response_content, dict) else None
            flow = Flow(source=source, state="completed")
            flow.started_at = str(entry.get("startedDateTime") or utc_now())
            flow.request = HttpMessage(method=method, url=redact_url(url), http_version=str(request.get("httpVersion", "HTTP/1.1")), headers=redact_headers(req_headers), body=req_body, body_size=body_size(req_body))
            flow.response = HttpMessage(status=int(response.get("status", 0) or 0), reason=str(response.get("statusText", "")), http_version=str(response.get("httpVersion", "HTTP/1.1")), headers=redact_headers(res_headers), body=res_body, body_encoding=response_content.get("encoding") if isinstance(response_content, dict) else None, body_size=body_size(res_body))
            timings = entry.get("timings") or {}
            send = float(timings.get("send", 0) or 0)
            wait = float(timings.get("wait", 0) or 0)
            receive = float(timings.get("receive", 0) or 0)
            total = float(entry.get("time", send + wait + receive) or 0)
            flow.timing = FlowTiming(blocked_ms=_num(timings.get("blocked")), dns_ms=_num(timings.get("dns")), connect_ms=_num(timings.get("connect")), tls_ms=_num(timings.get("ssl")), send_ms=send, wait_ms=wait, receive_ms=receive, total_ms=total)
            flow.ended_at = flow.started_at
            if response.get("redirectURL"):
                flow.redirects.append(str(response["redirectURL"]))
            comment = entry.get("comment", "")
            try:
                meta = json.loads(comment)
                extract_meta = meta.get("extractinator") if isinstance(meta, dict) else None
                if isinstance(extract_meta, dict) and extract_meta.get("id"):
                    flow.id = str(extract_meta["id"])
            except Exception:
                pass
            flows.append(flow)
        except Exception as exc:
            warnings.append(f"Entry {index}: ignored malformed entry ({type(exc).__name__}: {str(exc)[:120]}).")
    return flows, warnings


def _num(value: Any) -> float | None:
    try:
        n = float(value)
        return None if n < 0 else n
    except Exception:
        return None
