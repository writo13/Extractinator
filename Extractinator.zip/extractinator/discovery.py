from __future__ import annotations

import re
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup


PATTERNS = [
    re.compile(r"(?:https?:)?//[^\"'\\s<>]+(?:/api(?:/|\b)|/graphql(?:/|\b)|/v\d+(?:/|\b)|\.json(?:\?|\b))", re.I),
    re.compile(r"[\"'](/(?:api|graphql|ajax|rest|v\d+)(?:/|\b)[^\"']*)[\"']", re.I),
]


def discover_candidates(html: str, page_url: str) -> list[dict]:
    soup = BeautifulSoup(html, "html.parser")
    text = "\n".join(script.get_text(" ", strip=False) for script in soup.find_all("script"))
    text += "\n" + html
    found: dict[str, dict] = {}
    for pattern in PATTERNS:
        for match in pattern.finditer(text):
            raw = match.group(0)
            if raw.startswith("'") or raw.startswith('"'):
                raw = raw[1:-1]
            url = urljoin(page_url, raw)
            parsed = urlparse(url)
            if parsed.scheme not in {"http", "https"} or not parsed.hostname:
                continue
            if parsed.hostname != urlparse(page_url).hostname:
                continue
            found[url] = {"url": url, "kind": "possible_public_endpoint", "evidence": "page_source"}
            if len(found) >= 100:
                break
    return list(found.values())
