from __future__ import annotations

import re
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup

from extractinator.adapters.base import Adapter
from extractinator.core.exceptions import ExtractionError
from extractinator.core.models import ExtractionResult, FetchResult

RATINGS = {"One": 1, "Two": 2, "Three": 3, "Four": 4, "Five": 5}
KEY_RE = re.compile(r"^(?P<slug>[a-z0-9-]+)_(?P<id>\d+)$")
CURRENCIES = {"£": "GBP", "$": "USD", "€": "EUR"}


class BooksToScrapeAdapter(Adapter):
    name = "books_to_scrape"
    host = "books.toscrape.com"

    def can_handle(self, url: str) -> bool:
        return urlparse(url).hostname == self.host

    @staticmethod
    def _price(text: str) -> float | None:
        match = re.search(r"\d[\d,]*(?:\.\d+)?", text or "")
        return float(match.group().replace(",", "")) if match else None

    @staticmethod
    def _currency(text: str) -> str | None:
        return next((code for symbol, code in CURRENCIES.items() if symbol in (text or "")), None)

    @staticmethod
    def _rating(tag) -> int | None:
        if not tag:
            return None
        for cls in tag.get("class", []):
            if cls in RATINGS:
                return RATINGS[cls]
        return None

    @staticmethod
    def _book_key(url: str) -> str | None:
        """'.../catalogue/a-light-in-the-attic_1000/index.html' -> 'a-light-in-the-attic_1000'."""
        parts = [part for part in urlparse(url).path.split("/") if part]
        return next((part for part in reversed(parts) if KEY_RE.match(part)), None)

    @classmethod
    def _book_id_from_url(cls, url: str) -> int | None:
        key = cls._book_key(url)
        return int(KEY_RE.match(key).group("id")) if key else None

    @staticmethod
    def _pagination(soup: BeautifulSoup, page_url: str, book_count: int) -> dict:
        count_tag = soup.select_one("form.form-horizontal strong")
        count_text = count_tag.get_text(strip=True) if count_tag else ""
        total_results = int(count_text) if count_text.isdigit() else book_count

        current_page = total_pages = None
        pager = soup.select_one("ul.pager li.current")
        if pager:
            match = re.search(r"Page\s+(\d+)\s+of\s+(\d+)", pager.get_text(" ", strip=True))
            if match:
                current_page, total_pages = int(match.group(1)), int(match.group(2))
        else:
            current_page = total_pages = 1  # no pager means everything fits on one page

        def link(selector: str) -> str | None:
            anchor = soup.select_one(selector)
            return urljoin(page_url, anchor["href"]) if anchor and anchor.get("href") else None

        return {
            "page": current_page,
            "total_pages": total_pages,
            "total_results": total_results,
            "next_url": link("ul.pager li.next a"),
            "prev_url": link("ul.pager li.previous a"),
        }

    def _parse_listing(self, soup: BeautifulSoup, result: FetchResult) -> dict:
        books = []
        for pod in soup.select("article.product_pod"):
            link = pod.select_one("h3 a")
            price = pod.select_one("p.price_color")
            availability = pod.select_one("p.availability")
            image = pod.select_one("img")
            if not link or not price:
                raise ExtractionError("Book listing markup is missing required fields.")

            item_url = urljoin(result.url, link.get("href", ""))
            price_text = price.get_text(" ", strip=True)
            books.append(
                {
                    "id": self._book_id_from_url(item_url),
                    "title": link.get("title") or link.get_text(" ", strip=True),
                    "url": item_url,
                    "price": self._price(price_text),
                    "currency": self._currency(price_text),
                    "rating": self._rating(pod.select_one("p.star-rating")),
                    "in_stock": bool(
                        availability
                        and "in stock" in availability.get_text(" ", strip=True).lower()
                    ),
                    "image": urljoin(result.url, image["src"]) if image and image.get("src") else None,
                }
            )

        if not books:
            return {"type": "book_collection", "books": []}

        data = {
            "type": "book_collection",
            "books": books,
            "pagination": self._pagination(soup, result.url, len(books)),
        }

        categories = [
            {"name": a.get_text(" ", strip=True), "url": urljoin(result.url, a["href"])}
            for a in soup.select("div.side_categories ul li ul li a")
            if a.get("href")
        ]
        if categories:
            data["categories"] = categories
        return data

    def _parse_detail(self, soup: BeautifulSoup, result: FetchResult) -> dict:
        main = soup.select_one("div.product_main")
        title = main.select_one("h1") if main else None
        price = main.select_one("p.price_color") if main else None
        if not main or not title or not price:
            raise ExtractionError("Book detail markup is missing required fields.")

        table = {}
        for row in soup.select("table.table-striped tr"):
            th = row.find("th")
            td = row.find("td")
            if th and td:
                table[th.get_text(strip=True)] = td.get_text(" ", strip=True)

        crumbs = soup.select("ul.breadcrumb li")
        category = crumbs[2].get_text(strip=True) if len(crumbs) >= 4 else None
        description = None
        description_header = soup.select_one("#product_description")
        if description_header:
            paragraph = description_header.find_next_sibling("p")
            if paragraph:
                description = paragraph.get_text(" ", strip=True)

        availability = main.select_one("p.availability")
        stock_text = availability.get_text(" ", strip=True) if availability else ""
        count = re.search(r"(\d+)\s+available", stock_text)
        image = soup.select_one("#product_gallery img")
        price_text = price.get_text(" ", strip=True)

        return {
            "type": "book",
            "id": self._book_id_from_url(result.url),
            "key": self._book_key(result.url),
            "title": title.get_text(" ", strip=True),
            "url": result.url,
            "price": self._price(price_text),
            "currency": self._currency(price_text),
            "rating": self._rating(main.select_one("p.star-rating")),
            "in_stock": "in stock" in stock_text.lower(),
            "image": urljoin(result.url, image["src"]) if image and image.get("src") else None,
            "upc": table.get("UPC"),
            "product_type": table.get("Product Type"),
            "category": category,
            "description": description,
            "price_excl_tax": self._price(table.get("Price (excl. tax)", "")),
            "price_incl_tax": self._price(table.get("Price (incl. tax)", "")),
            "tax": self._price(table.get("Tax", "")),
            "stock_count": int(count.group(1)) if count else None,
            "num_reviews": int(table["Number of reviews"]) if table.get("Number of reviews", "").isdigit() else None,
        }

    def extract(self, result: FetchResult) -> ExtractionResult:
        soup = BeautifulSoup(result.text, "html.parser")
        if soup.select_one("div.product_main"):
            data = self._parse_detail(soup, result)
            return ExtractionResult(
                url=result.url,
                type="book",
                data=data,
                method="site_adapter",
                adapter=self.name,
            )

        data = self._parse_listing(soup, result)
        return ExtractionResult(
            url=result.url,
            type="book_collection",
            data=data,
            method="site_adapter",
            adapter=self.name,
        )
