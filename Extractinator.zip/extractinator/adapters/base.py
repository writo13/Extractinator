from __future__ import annotations

from abc import ABC, abstractmethod

from extractinator.core.models import ExtractionResult, FetchResult


class Adapter(ABC):
    name = "base"

    @abstractmethod
    def can_handle(self, url: str) -> bool:
        raise NotImplementedError

    @abstractmethod
    def extract(self, result: FetchResult) -> ExtractionResult:
        raise NotImplementedError
