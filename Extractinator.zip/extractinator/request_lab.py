from __future__ import annotations

from typing import Any

import requests

from .core.exceptions import ExtractinatorError, URLNotAllowed
from .forge import SENSITIVE_HEADERS


class RequestLabError(ExtractinatorError):
    status_code = 422


class RequestLab:
    SAFE = {"GET", "HEAD", "OPTIONS"}
    WRITE = {"POST", "PUT", "PATCH", "DELETE"}

    def __init__(self, fetcher, allow_write: bool = False):
        self.fetcher = fetcher
        self.allow_write = allow_write

    def _headers(self, headers: dict[str, str] | None) -> dict[str, str]:
        cleaned = {}
        for key, value in (headers or {}).items():
            if key.lower() in SENSITIVE_HEADERS:
                raise RequestLabError(
                    f"Sensitive upstream header '{key}' is intentionally blocked. Extractinator does not act as an authentication bypass."
                )
            cleaned[key] = value
        return cleaned

    def send(
        self,
        *,
        method: str,
        url: str,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        body: str | None = None,
    ) -> dict[str, Any]:
        method = method.upper().strip()
        if method not in self.SAFE | self.WRITE:
            raise RequestLabError(f"Unsupported HTTP method: {method}")
        if method in self.WRITE and not self.allow_write:
            raise RequestLabError(
                "Write methods are disabled by default. Set EXTRACTINATOR_ALLOW_WRITE_METHODS=true for a deliberate local test."
            )

        self.fetcher.policy.validate(url)
        clean_headers = self._headers(headers)

        if method in {"GET", "HEAD"} and not body:
            from urllib.parse import urlencode
            full_url = url
            if params:
                joiner = "&" if "?" in full_url else "?"
                full_url = full_url + joiner + urlencode(params, doseq=True)
            result = self.fetcher.fetch(full_url)
            return {
                "status": result.status_code,
                "url": result.url,
                "content_type": result.content_type,
                "body": result.text[:1_000_000],
                "cached": result.from_cache,
            }

        session = requests.Session()
        session.cookies.clear()
        try:
            response = session.request(
                method,
                url,
                params=params or None,
                headers=clean_headers,
                data=body or None,
                timeout=self.fetcher.timeout,
                allow_redirects=False,
            )
        except requests.Timeout as exc:
            raise RequestLabError("Request timed out.") from exc
        except requests.RequestException as exc:
            raise RequestLabError(f"Request failed: {type(exc).__name__}") from exc

        return {
            "status": response.status_code,
            "url": response.url,
            "content_type": response.headers.get("Content-Type", ""),
            "body": response.text[:1_000_000],
            "headers": {k: v for k, v in response.headers.items() if k.lower() not in {"set-cookie"}},
        }
