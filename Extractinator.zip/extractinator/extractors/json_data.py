from __future__ import annotations

import json

from extractinator.core.exceptions import ExtractionError


def extract_json(text: str) -> tuple[str, dict, str]:
    try:
        payload = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ExtractionError(f"Response is not valid JSON: {exc.msg} (line {exc.lineno}).") from exc
    return "json", {"type": "json", "content": payload}, "json"


def extract_plain_text(text: str) -> tuple[str, dict, str]:
    return "text", {"type": "text", "content": {"text": text, "lines": text.count("\n") + 1}}, "plain_text"
