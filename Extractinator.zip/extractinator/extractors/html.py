from __future__ import annotations

from urllib.parse import urljoin

from bs4 import BeautifulSoup

LIMITS = {"links": 100, "images": 100, "tables": 20}
_SKIP_SCHEMES = ("javascript:", "data:", "#")


def _content_root(soup: BeautifulSoup):
    """A lone <article> or <main> is the page's content; otherwise use the whole document."""
    articles = soup.find_all("article")
    if len(articles) == 1:
        return articles[0]
    return soup.find("main") or soup


def extract_html(soup: BeautifulSoup, base_url: str) -> dict:
    root = _content_root(soup)

    headings = [
        text
        for tag in root.find_all(["h1", "h2", "h3"])
        if (text := tag.get_text(" ", strip=True))
    ]

    paragraphs = [
        text
        for tag in root.find_all("p")
        if (text := tag.get_text(" ", strip=True))
    ]

    links: list[dict] = []
    seen_links: set[tuple[str, str]] = set()
    for tag in root.find_all("a", href=True):
        href = tag["href"].strip()
        if not href or href.lower().startswith(_SKIP_SCHEMES):
            continue
        item = {"text": tag.get_text(" ", strip=True), "url": urljoin(base_url, href)}
        key = (item["url"], item["text"])
        if key not in seen_links:
            seen_links.add(key)
            links.append(item)

    images: list[dict] = []
    for tag in root.find_all("img"):
        src = (tag.get("src") or tag.get("data-src") or "").strip()
        if not src or src.lower().startswith("data:"):
            continue
        images.append({"alt": tag.get("alt", "").strip(), "url": urljoin(base_url, src)})

    tables = []
    for table in root.find_all("table"):
        rows = []
        for tr in table.find_all("tr"):
            cells = [cell.get_text(" ", strip=True) for cell in tr.find_all(["th", "td"])]
            if cells:
                rows.append(cells)
        if rows:
            tables.append(rows)

    return {
        "headings": headings,
        "paragraphs": paragraphs,
        "links": links[: LIMITS["links"]],
        "images": images[: LIMITS["images"]],
        "tables": tables[: LIMITS["tables"]],
        # Totals before truncation, so callers can tell when a list was cut short.
        "counts": {
            "headings": len(headings),
            "paragraphs": len(paragraphs),
            "links": len(links),
            "images": len(images),
            "tables": len(tables),
        },
    }
