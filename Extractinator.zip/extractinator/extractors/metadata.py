from __future__ import annotations

from urllib.parse import urljoin

from bs4 import BeautifulSoup


def _meta_index(soup: BeautifulSoup) -> dict[str, str]:
    """First non-empty content per meta key, matched case-insensitively on property/name/itemprop."""
    index: dict[str, str] = {}
    for tag in soup.find_all("meta"):
        key = (tag.get("property") or tag.get("name") or tag.get("itemprop") or "").strip().lower()
        content = (tag.get("content") or "").strip()
        if key and content:
            index.setdefault(key, content)
    return index


def _first(index: dict[str, str], *keys: str) -> str | None:
    for key in keys:
        if key in index:
            return index[key]
    return None


def extract_metadata(soup: BeautifulSoup, base_url: str | None = None) -> dict:
    index = _meta_index(soup)

    canonical_tag = soup.find("link", rel="canonical")
    canonical = canonical_tag.get("href") if canonical_tag else None
    if canonical and base_url:
        canonical = urljoin(base_url, canonical)

    images: list[str] = []
    for tag in soup.find_all("meta"):
        key = (tag.get("property") or tag.get("name") or "").strip().lower()
        if key in {"og:image", "twitter:image"} and (tag.get("content") or "").strip():
            value = tag["content"].strip()
            if value not in images:
                images.append(value)

    html_tag = soup.find("html")
    language = html_tag.get("lang", "").strip() if html_tag else ""

    return {
        "title": _first(index, "og:title", "twitter:title")
        or (soup.title.get_text(strip=True) if soup.title else None),
        "description": _first(index, "og:description", "description", "twitter:description"),
        "author": _first(index, "author", "article:author", "twitter:creator"),
        "published_at": _first(
            index, "article:published_time", "og:article:published_time",
            "datepublished", "date", "dc.date", "pubdate",
        ),
        "canonical": canonical,
        "site_name": _first(index, "og:site_name", "application-name"),
        "images": images,
        "og_type": _first(index, "og:type"),
        "language": language or None,
    }
