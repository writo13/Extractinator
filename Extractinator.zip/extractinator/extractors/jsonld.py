from __future__ import annotations

import json
from typing import Any

from bs4 import BeautifulSoup


KNOWN_TYPES = {
    "Article": "article",
    "NewsArticle": "article",
    "BlogPosting": "article",
    "TechArticle": "article",
    "ScholarlyArticle": "article",
    "Product": "product",
    "Book": "book",
    "JobPosting": "job",
    "Recipe": "recipe",
    "Event": "event",
    "Organization": "organization",
    "Person": "person",
    "Movie": "movie",
    "VideoObject": "video",
    "WebPage": "webpage",
}

# Higher wins when a page declares several entities (publishers put Organization/WebPage first).
PRIORITY = {
    "article": 90, "product": 90, "book": 90, "recipe": 90, "event": 90,
    "job": 90, "movie": 90, "video": 80,
    "person": 40, "organization": 30, "webpage": 20, "structured": 10,
}


def _as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def _type_name(raw: Any) -> str:
    """'https://schema.org/Article' -> 'Article'."""
    return str(raw).rsplit("/", 1)[-1].rsplit("#", 1)[-1]


def _flatten(payload: Any) -> list[Any]:
    items: list[Any] = []
    for entry in _as_list(payload):
        if isinstance(entry, dict) and "@graph" in entry:
            items.extend(_as_list(entry["@graph"]))
        else:
            items.append(entry)
    return items


def extract_jsonld(soup: BeautifulSoup) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []

    for script in soup.find_all("script", attrs={"type": "application/ld+json"}):
        raw = script.string or script.get_text()
        if not raw.strip():
            continue
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            continue

        for item in _flatten(payload):
            if not isinstance(item, dict):
                continue
            names = [_type_name(t) for t in _as_list(item.get("@type"))]
            normalized = next(
                (KNOWN_TYPES[n] for n in names if n in KNOWN_TYPES),
                "structured",
            )
            enriched = dict(item)
            enriched["_normalized_type"] = normalized
            records.append(enriched)

    return records


def best_jsonld_record(records: list[dict[str, Any]]) -> dict[str, Any] | None:
    if not records:
        return None
    return max(
        records,
        key=lambda r: (PRIORITY.get(r.get("_normalized_type", "structured"), 10), len(r)),
    )
