from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class SourceInfo(BaseModel):
    url: str
    requested_url: str | None = None
    retrieved_at: str
    method: str
    adapter: str | None = None
    content_type: str | None = None
    cached: bool = False


class ExtractionResponse(BaseModel):
    source: SourceInfo
    data: dict[str, Any]
    warnings: list[str] = Field(default_factory=list)


class ErrorResponse(BaseModel):
    error: str
    type: str
