from pathlib import Path

from extractinator.core.store import Store
from extractinator.forge import APIForge, build_upstream_url, slugify


class DummyPolicy:
    def validate(self, url, resolve=True):
        assert url.startswith("https://")


class DummyResult:
    def __init__(self, text="{}"):
        self.text = text
        self.content_type = "application/json"
        self.url = "https://example.com/data"
        self.status_code = 200
        self.from_cache = False


class DummyFetcher:
    policy = DummyPolicy()

    def fetch(self, url):
        return DummyResult()


def test_store_tokens_and_revocation(tmp_path):
    store = Store(str(tmp_path / "db.sqlite"))
    created = store.create_token("client", ["invoke"], None)
    assert created["token"].startswith("ext_live_")
    assert store.verify_token(created["token"], "invoke")
    assert not store.verify_token("wrong-token", "invoke")
    assert store.revoke_token(created["id"])
    assert not store.verify_token(created["token"], "invoke")


def test_forge_creates_public_get_and_exports(tmp_path):
    store = Store(str(tmp_path / "db.sqlite"))
    forge = APIForge(store, DummyFetcher())
    api = forge.create(
        name="Public Quotes",
        method="GET",
        upstream_url="https://example.com/data",
        description="demo",
    )
    assert api["slug"] == "public-quotes"
    assert build_upstream_url(api["upstream_url"], {"q": "hello world"}).endswith("?q=hello+world")
    assert "public-quotes" in forge.openapi()["paths"]
    assert forge.postman_collection()["item"]
