from __future__ import annotations

from typing import Any

from extractinator.adapters.base import Adapter
from extractinator.adapters.books_to_scrape import BooksToScrapeAdapter
from extractinator.core.config import Settings
from extractinator.core.exceptions import ExtractionError
from extractinator.core.fetcher import Fetcher
from extractinator.core.models import ExtractionResult, FetchResult
from extractinator.core.registry import AdapterRegistry
from extractinator.core.store import Store
from extractinator.extractors.generic import extract_generic
from extractinator.extractors.json_data import extract_json, extract_plain_text
from extractinator.forge import APIForge
from extractinator.request_lab import RequestLab

JSON_TYPES = {"application/json", "application/ld+json"}


class ExtractinatorService:
    def __init__(
        self,
        fetcher: Fetcher | None = None,
        *,
        settings: Settings | None = None,
        adapters: list[Adapter] | None = None,
    ):
        self.settings = settings or Settings.from_env()
        self.fetcher = fetcher or Fetcher.from_settings(self.settings)
        self.registry = AdapterRegistry(
            adapters if adapters is not None else [BooksToScrapeAdapter()]
        )
        self.store = Store(self.settings.db_path)
        self.forge = APIForge(self.store, self.fetcher)
        self.request_lab = RequestLab(
            self.fetcher,
            allow_write=self.settings.allow_write_methods,
        )

    def capabilities(self, url: str) -> dict:
        self.fetcher.policy.validate(url, resolve=False)
        adapter = self.registry.find(url)
        return {
            "url": url,
            "adapter": adapter.name if adapter else None,
            "generic_extractors": ["jsonld", "metadata", "generic_html"],
            "respects_robots": self.fetcher.respect_robots,
            "request_lab": {
                "enabled": True,
                "safe_methods": ["GET", "HEAD", "OPTIONS"],
                "write_methods_enabled": self.settings.allow_write_methods,
            },
            "api_generation": {
                "enabled": True,
                "generated_methods": ["GET", "HEAD"],
            },
        }

    def extract(self, url: str) -> ExtractionResult:
        fetched = self.fetcher.fetch(url)
        warnings: list[str] = []
        result: ExtractionResult | None = None

        adapter = self.registry.find(fetched.url)
        if adapter:
            try:
                result = adapter.extract(fetched)
            except ExtractionError as exc:
                warnings.append(
                    f"Adapter '{adapter.name}' could not parse this page ({exc}); "
                    "fell back to generic extraction."
                )

        if result is None:
            result = self._generic(fetched)
            warnings.extend(self._generic_warnings(result))

        if adapter and result.adapter is None and result.method != "generic_html":
            result.adapter = adapter.name

        result.warnings = warnings + result.warnings
        result.requested_url = fetched.requested_url
        result.content_type = fetched.content_type
        result.cached = fetched.from_cache
        return result

    @staticmethod
    def _generic(fetched: FetchResult) -> ExtractionResult:
        if fetched.content_type in JSON_TYPES:
            record_type, data, method = extract_json(fetched.text)
        elif fetched.content_type == "text/plain":
            record_type, data, method = extract_plain_text(fetched.text)
        else:
            record_type, data, method = extract_generic(fetched.text, fetched.url)
        return ExtractionResult(url=fetched.url, type=record_type, data=data, method=method)

    @staticmethod
    def _generic_warnings(result: ExtractionResult) -> list[str]:
        content = result.data.get("content")
        if result.method not in {"jsonld", "generic_html"} or not isinstance(content, dict):
            return []

        warnings = []
        counts = content.get("counts", {})
        for key in ("links", "images", "tables"):
            total = counts.get(key, 0)
            if total > len(content.get(key, [])):
                warnings.append(
                    f"Only the first {len(content[key])} of {total} {key} are included."
                )
        if result.method == "generic_html" and not content.get("paragraphs") and not content.get("headings"):
            warnings.append(
                "No readable text found. The page may be rendered by JavaScript, "
                "which Extractinator does not execute."
            )
        return warnings

    # ----------------------------------------------------------------- Request Lab
    def send_request(self, **kwargs: Any) -> dict[str, Any]:
        return self.request_lab.send(**kwargs)

    # --------------------------------------------------------------- API Forge
    def create_generated_api(self, **kwargs: Any) -> dict[str, Any]:
        return self.forge.create(**kwargs)

    def invoke_generated_api(self, slug: str, query: dict[str, Any]):
        api = self.store.get_api_by_slug(slug)
        if not api:
            from extractinator.core.exceptions import UpstreamError
            raise UpstreamError("Generated API not found", 404)
        return api, self.forge.invoke(api, query)
