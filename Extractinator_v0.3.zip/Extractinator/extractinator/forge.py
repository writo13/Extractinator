from __future__ import annotations

import re
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from .core.exceptions import ExtractionError, URLNotAllowed
from .core.store import Store

SAFE_METHODS = {"GET", "HEAD"}
SENSITIVE_HEADERS = {
    "authorization",
    "proxy-authorization",
    "cookie",
    "set-cookie",
    "x-api-key",
    "x-csrf-token",
}


def slugify(value: str) -> str:
    value = re.sub(r"[^a-zA-Z0-9]+", "-", value.strip().lower()).strip("-")
    return value[:60] or "generated-api"


def build_upstream_url(template: str, query: dict[str, Any]) -> str:
    parsed = urlsplit(template)
    existing = dict(parse_qsl(parsed.query, keep_blank_values=True))
    for key, value in query.items():
        if key.startswith("_"):
            continue
        existing[key] = str(value)
    return urlunsplit((parsed.scheme, parsed.netloc, parsed.path, urlencode(existing), parsed.fragment))


def sanitize_headers(headers: dict[str, str] | None) -> dict[str, str]:
    return {
        k: v
        for k, v in (headers or {}).items()
        if k.lower() not in SENSITIVE_HEADERS
    }


class APIForge:
    def __init__(self, store: Store, fetcher):
        self.store = store
        self.fetcher = fetcher

    def create(self, *, name: str, method: str, upstream_url: str, description: str = "") -> dict[str, Any]:
        method = method.upper().strip()
        if method not in SAFE_METHODS:
            raise ExtractionError("Generated APIs currently support GET and HEAD only; state-changing methods remain in Request Lab.")
        self.fetcher.policy.validate(upstream_url)
        slug = slugify(name)
        if self.store.get_api_by_slug(slug):
            slug = f"{slug}-{__import__('secrets').token_hex(3)}"
        return self.store.create_api(name, slug, method, upstream_url, description)

    def invoke(self, api: dict[str, Any], query: dict[str, Any]):
        url = build_upstream_url(api["upstream_url"], query)
        self.fetcher.policy.validate(url)
        return self.fetcher.fetch(url)

    def openapi(self) -> dict[str, Any]:
        paths: dict[str, Any] = {}
        for api in self.store.list_apis():
            if not api["enabled"]:
                continue
            path = f"/generated/{api['slug']}"
            paths[path] = {
                api["method"].lower(): {
                    "summary": api["name"],
                    "description": api["description"],
                    "operationId": f"generated_{api['slug'].replace('-', '_')}",
                    "parameters": [{
                        "name": "_note",
                        "in": "query",
                        "required": False,
                        "schema": {"type": "string"},
                        "description": "Ignored metadata parameter; other query parameters are forwarded to the public upstream URL.",
                    }],
                    "responses": {
                        "200": {"description": "Upstream public response"},
                        "401": {"description": "Missing or invalid Extractinator token"},
                    },
                    "security": [{"bearerAuth": []}],
                }
            }
        return {
            "openapi": "3.1.0",
            "info": {"title": "Extractinator Generated APIs", "version": "0.3.0"},
            "servers": [{"url": "http://127.0.0.1:8000"}],
            "components": {"securitySchemes": {"bearerAuth": {"type": "http", "scheme": "bearer"}}},
            "paths": paths,
        }

    def postman_collection(self) -> dict[str, Any]:
        items = []
        for api in self.store.list_apis():
            if not api["enabled"]:
                continue
            items.append({
                "name": api["name"],
                "request": {
                    "method": api["method"],
                    "header": [{"key": "Authorization", "value": "Bearer {{extractinator_token}}", "type": "text"}],
                    "url": {
                        "raw": f"http://127.0.0.1:8000/generated/{api['slug']}",
                        "protocol": "http",
                        "host": ["127", "0", "0", "1"],
                        "port": "8000",
                        "path": ["generated", api["slug"]],
                    },
                    "description": api["description"],
                },
            })
        return {
            "info": {
                "name": "Extractinator Generated APIs",
                "_postman_id": "extractinator-generated",
                "description": "Generated from public upstream endpoints by Extractinator.",
                "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json",
            },
            "variable": [{"key": "extractinator_token", "value": ""}],
            "item": items,
        }

    def postman_captures(self) -> dict[str, Any]:
        items = []
        for capture in self.store.list_captures(500):
            headers = [{"key": k, "value": v, "type": "text"} for k, v in capture.get("headers", {}).items()]
            request = {
                "method": capture["method"],
                "header": headers,
                "url": capture["url"],
            }
            if capture.get("body"):
                request["body"] = {"mode": "raw", "raw": capture["body"]}
            items.append({"name": f"Capture {capture['id']} · {capture['method']}", "request": request})
        return {
            "info": {
                "name": "Extractinator Captured Requests",
                "_postman_id": "extractinator-captures",
                "description": "Sanitized public request metadata captured by Extractinator.",
                "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json",
            },
            "item": items,
        }
