from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI, Header, Query, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from extractinator import __version__
from extractinator.core.exceptions import ExtractinatorError
from extractinator.discovery import discover_candidates
from extractinator.schemas.common import ErrorResponse, ExtractionResponse
from extractinator.service import ExtractinatorService


FRONTEND_DIR = Path(__file__).resolve().parent.parent / "frontend"
DASHBOARD_HEADERS = {
    "Content-Security-Policy": (
        "default-src 'self'; img-src 'self' data:; base-uri 'none'; "
        "form-action 'self'; frame-ancestors 'none'"
    ),
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
}

ERROR_RESPONSES = {
    400: {"model": ErrorResponse, "description": "URL rejected by the public-web policy"},
    401: {"model": ErrorResponse, "description": "Missing or invalid Extractinator token"},
    403: {"model": ErrorResponse, "description": "Blocked by robots.txt or access policy"},
    404: {"model": ErrorResponse, "description": "The requested resource does not exist"},
    413: {"model": ErrorResponse, "description": "Upstream response too large"},
    415: {"model": ErrorResponse, "description": "Unsupported upstream content type"},
    422: {"model": ErrorResponse, "description": "Invalid request or extraction failure"},
    502: {"model": ErrorResponse, "description": "Upstream fetch failed"},
    504: {"model": ErrorResponse, "description": "Upstream timed out"},
}


class ExtractRequest(BaseModel):
    url: str = Field(..., min_length=8, max_length=2048)


class RequestLabRequest(BaseModel):
    method: str = Field(default="GET", min_length=3, max_length=10)
    url: str = Field(..., min_length=8, max_length=2048)
    params: dict[str, Any] = Field(default_factory=dict)
    headers: dict[str, str] = Field(default_factory=dict)
    body: str | None = Field(default=None, max_length=1_000_000)


class GenerateAPIRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=80)
    upstream_url: str = Field(..., min_length=8, max_length=2048)
    method: str = Field(default="GET", min_length=3, max_length=10)
    description: str = Field(default="", max_length=500)


class TokenRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=80)
    expires_at: str | None = None
    scopes: list[str] = Field(default_factory=lambda: ["invoke"])


class CaptureRequest(BaseModel):
    method: str = Field(..., min_length=3, max_length=10)
    url: str = Field(..., min_length=8, max_length=2048)
    headers: dict[str, str] = Field(default_factory=dict)
    body: str | None = Field(default=None, max_length=100_000)


def _error_response(status_code: int, message: str, error_type: str) -> JSONResponse:
    return JSONResponse(status_code=status_code, content={"error": message, "type": error_type})


def _bearer_token(authorization: str | None) -> str | None:
    if not authorization:
        return None
    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer" or not token.strip():
        return None
    return token.strip()


def _admin_ok(request: Request, admin_key: str, supplied: str | None) -> bool:
    if admin_key:
        return bool(supplied) and supplied == admin_key
    client_host = request.client.host if request.client else ""
    return client_host in {"127.0.0.1", "::1", "localhost"}


def create_app(service: ExtractinatorService | None = None) -> FastAPI:
    service = service or ExtractinatorService()

    app = FastAPI(
        title="Extractinator",
        version=__version__,
        description=(
            "Public-web extraction and API-creation workbench. "
            "It can inspect public requests, generate token-protected wrappers for safe public GET endpoints, "
            "and export generated APIs to OpenAPI/Postman."
        ),
        docs_url="/docs",
        redoc_url="/redoc",
    )

    @app.exception_handler(ExtractinatorError)
    async def extractinator_error(request: Request, exc: ExtractinatorError):
        return _error_response(exc.status_code, str(exc), type(exc).__name__)

    @app.exception_handler(RequestValidationError)
    async def validation_error(request: Request, exc: RequestValidationError):
        first = exc.errors()[0] if exc.errors() else {}
        where = ".".join(str(part) for part in first.get("loc", ()) if part not in {"query", "body"})
        message = f"{where}: {first.get('msg', 'invalid request')}" if where else "invalid request"
        return _error_response(422, message, "ValidationError")

    @app.exception_handler(Exception)
    async def unexpected_error(request: Request, exc: Exception):
        return _error_response(500, "unexpected internal error", "InternalServerError")

    @app.middleware("http")
    async def dashboard_security_headers(request: Request, call_next):
        response = await call_next(request)
        if request.url.path == "/" or request.url.path.startswith("/assets/"):
            for name, value in DASHBOARD_HEADERS.items():
                response.headers.setdefault(name, value)
        return response

    app.mount("/assets", StaticFiles(directory=FRONTEND_DIR / "assets"), name="assets")

    @app.get("/", include_in_schema=False)
    @app.head("/", include_in_schema=False)
    def dashboard():
        return FileResponse(FRONTEND_DIR / "index.html")

    @app.get("/health")
    @app.head("/health", include_in_schema=False)
    def health():
        return {"status": "ok", "service": "extractinator", "version": __version__}

    @app.get("/adapters")
    def adapters():
        return {"adapters": service.registry.names()}

    @app.get("/capabilities", responses={400: ERROR_RESPONSES[400], 422: ERROR_RESPONSES[422]})
    def capabilities(url: str = Query(..., min_length=8, max_length=2048)):
        return service.capabilities(url)

    @app.get("/extract", response_model=ExtractionResponse, responses=ERROR_RESPONSES)
    def extract(url: str = Query(..., min_length=8, max_length=2048)):
        return service.extract(url).as_dict()

    @app.post("/extract", response_model=ExtractionResponse, responses=ERROR_RESPONSES)
    def extract_post(request: ExtractRequest):
        return service.extract(request.url).as_dict()

    # ------------------------------------------------------------ Request Lab
    @app.post("/lab/request", responses=ERROR_RESPONSES)
    def lab_request(payload: RequestLabRequest, request: Request, x_extractinator_admin_key: str | None = Header(default=None)):
        if not _admin_ok(request, service.settings.admin_key, x_extractinator_admin_key):
            return _error_response(401, "Admin access is required for Request Lab.", "Unauthorized")
        return service.send_request(**payload.model_dump())

    @app.get("/discover", responses=ERROR_RESPONSES)
    def discover(url: str = Query(..., min_length=8, max_length=2048)):
        fetched = service.fetcher.fetch(url)
        content_type = fetched.content_type or ""
        if "html" not in content_type and content_type != "" :
            return {"url": fetched.url, "candidates": [], "warning": "Discovery currently scans HTML pages only."}
        return {
            "url": fetched.url,
            "candidates": discover_candidates(fetched.text, fetched.url),
            "warning": "Candidates are heuristics from public page source; a candidate is not proof of a documented API or permission to bypass authentication."
        }

    # ----------------------------------------------------------- API capture
    @app.post("/capture", status_code=201)
    def capture(payload: CaptureRequest, request: Request, x_extractinator_admin_key: str | None = Header(default=None)):
        if not _admin_ok(request, service.settings.admin_key, x_extractinator_admin_key):
            return _error_response(401, "Admin access is required for capture management.", "Unauthorized")
        # Store only public request metadata sent by the local capture tool. The capture addon
        # strips credentials/cookies before sending it here.
        service.fetcher.policy.validate(payload.url, resolve=False)
        return service.store.add_capture(payload.method.upper(), payload.url, payload.headers, payload.body)

    @app.get("/captures")
    def captures(request: Request, limit: int = Query(100, ge=1, le=500), x_extractinator_admin_key: str | None = Header(default=None)):
        if not _admin_ok(request, service.settings.admin_key, x_extractinator_admin_key):
            return _error_response(401, "Admin access is required for capture management.", "Unauthorized")
        return {"captures": service.store.list_captures(limit)}

    @app.delete("/captures/{capture_id}")
    def delete_capture(capture_id: int, request: Request, x_extractinator_admin_key: str | None = Header(default=None)):
        if not _admin_ok(request, service.settings.admin_key, x_extractinator_admin_key):
            return _error_response(401, "Admin access is required for capture management.", "Unauthorized")
        if not service.store.delete_capture(capture_id):
            return _error_response(404, "capture not found", "NotFoundError")
        return {"status": "deleted", "id": capture_id}

    # -------------------------------------------------------------- API Forge
    @app.post("/forge/apis", responses=ERROR_RESPONSES)
    def generate_api(payload: GenerateAPIRequest, request: Request, x_extractinator_admin_key: str | None = Header(default=None)):
        if not _admin_ok(request, service.settings.admin_key, x_extractinator_admin_key):
            return _error_response(401, "Admin access is required to generate APIs.", "Unauthorized")
        return service.create_generated_api(**payload.model_dump())

    @app.get("/forge/apis")
    def generated_apis(request: Request, x_extractinator_admin_key: str | None = Header(default=None)):
        if not _admin_ok(request, service.settings.admin_key, x_extractinator_admin_key):
            return _error_response(401, "Admin access is required to manage generated APIs.", "Unauthorized")
        return {"apis": service.store.list_apis()}

    @app.delete("/forge/apis/{api_id}")
    def disable_generated_api(api_id: int, request: Request, x_extractinator_admin_key: str | None = Header(default=None)):
        if not _admin_ok(request, service.settings.admin_key, x_extractinator_admin_key):
            return _error_response(401, "Admin access is required to manage generated APIs.", "Unauthorized")
        if not service.store.disable_api(api_id):
            return _error_response(404, "generated API not found", "NotFoundError")
        return {"status": "disabled", "id": api_id}

    @app.get("/generated/{slug}", responses=ERROR_RESPONSES)
    @app.head("/generated/{slug}", include_in_schema=False, responses=ERROR_RESPONSES)
    def invoke_generated_api(
        slug: str,
        request: Request,
        authorization: str | None = Header(default=None),
    ):
        token = _bearer_token(authorization)
        if not token or not service.store.verify_token(token, "invoke"):
            return _error_response(401, "A valid Extractinator bearer token is required.", "Unauthorized")
        query = dict(request.query_params)
        api, fetched = service.invoke_generated_api(slug, query)
        media_type = fetched.content_type or "application/octet-stream"
        if media_type.startswith("application/json"):
            try:
                import json
                return JSONResponse(content=json.loads(fetched.text), headers={"X-Extractinator-Upstream": api["upstream_url"]})
            except Exception:
                pass
        return Response(content=fetched.text, media_type=media_type, headers={"X-Extractinator-Upstream": api["upstream_url"]})

    # --------------------------------------------------------------- Tokens
    @app.post("/tokens", status_code=201)
    def create_token(payload: TokenRequest, request: Request, x_extractinator_admin_key: str | None = Header(default=None)):
        if not _admin_ok(request, service.settings.admin_key, x_extractinator_admin_key):
            return _error_response(401, "Admin access is required to manage tokens.", "Unauthorized")
        return service.store.create_token(payload.name, payload.scopes, payload.expires_at)

    @app.get("/tokens")
    def list_tokens(request: Request, x_extractinator_admin_key: str | None = Header(default=None)):
        if not _admin_ok(request, service.settings.admin_key, x_extractinator_admin_key):
            return _error_response(401, "Admin access is required to manage tokens.", "Unauthorized")
        return {"tokens": service.store.list_tokens()}

    @app.delete("/tokens/{token_id}")
    def revoke_token(token_id: int, request: Request, x_extractinator_admin_key: str | None = Header(default=None)):
        if not _admin_ok(request, service.settings.admin_key, x_extractinator_admin_key):
            return _error_response(401, "Admin access is required to manage tokens.", "Unauthorized")
        if not service.store.revoke_token(token_id):
            return _error_response(404, "token not found", "NotFoundError")
        return {"status": "revoked", "id": token_id}

    # --------------------------------------------------------------- Exports
    @app.get("/exports/openapi.json")
    def export_openapi():
        return service.forge.openapi()

    @app.get("/exports/postman.json")
    def export_postman():
        return service.forge.postman_collection()

    @app.get("/exports/postman-captures.json")
    def export_postman_captures():
        return service.forge.postman_captures()

    return app
