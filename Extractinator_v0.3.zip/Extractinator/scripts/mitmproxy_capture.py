"""Optional mitmproxy addon for capturing your own browser's public requests.

Run locally with:
    mitmdump -s scripts/mitmproxy_capture.py

The addon intentionally strips cookies, Authorization, API keys and CSRF headers.
It forwards only request metadata to Extractinator at 127.0.0.1:8000/capture.
It is for inspecting public requests made by your own client; it is not an
authentication or access-control bypass tool.
"""

import os
from urllib.parse import urlsplit

import requests
from mitmproxy import http


TARGET = os.getenv("EXTRACTINATOR_CAPTURE_TARGET", "http://127.0.0.1:8000/capture")
BLOCKED_HEADERS = {
    "authorization",
    "proxy-authorization",
    "cookie",
    "set-cookie",
    "x-api-key",
    "x-csrf-token",
}


def request(flow: http.HTTPFlow):
    url = flow.request.pretty_url
    parsed = urlsplit(url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        return
    if parsed.hostname in {"localhost", "127.0.0.1", "::1"}:
        return

    headers = {
        key: value
        for key, value in flow.request.headers.items()
        if key.lower() not in BLOCKED_HEADERS
    }

    payload = {
        "method": flow.request.method,
        "url": url,
        "headers": headers,
        "body": None,
    }

    try:
        requests.post(TARGET, json=payload, timeout=1.5)
    except requests.RequestException:
        pass
