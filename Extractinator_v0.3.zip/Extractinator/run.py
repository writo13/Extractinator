import uvicorn

from extractinator.core.config import Settings


if __name__ == "__main__":
    settings = Settings.from_env()
    uvicorn.run("app:app", host=settings.host, port=settings.port, reload=False)
