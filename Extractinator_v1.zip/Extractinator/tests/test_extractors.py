from pathlib import Path

from bs4 import BeautifulSoup

from extractinator.extractors.generic import extract_generic
from extractinator.extractors.jsonld import extract_jsonld
from extractinator.extractors.metadata import extract_metadata

FIXTURES = Path(__file__).parent / "fixtures"


def test_jsonld_article_is_extracted():
    html = (FIXTURES / "generic_article.html").read_text(encoding="utf-8")
    soup = BeautifulSoup(html, "html.parser")
    records = extract_jsonld(soup)
    assert records
    assert records[0]["_normalized_type"] == "article"


def test_metadata():
    html = (FIXTURES / "generic_article.html").read_text(encoding="utf-8")
    soup = BeautifulSoup(html, "html.parser")
    metadata = extract_metadata(soup)
    assert metadata["title"] == "Example Article"
    assert metadata["author"] == "Jane Doe"


def test_generic_prefers_jsonld():
    html = (FIXTURES / "generic_article.html").read_text(encoding="utf-8")
    record_type, data, method = extract_generic(
        html,
        "https://example.com/article",
    )
    assert record_type == "article"
    assert method == "jsonld"
    assert data["structured_data"]["headline"] == "Example Article"
