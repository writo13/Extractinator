from pathlib import Path

from extractinator.adapters.books_to_scrape import BooksToScrapeAdapter
from extractinator.core.models import FetchResult

FIXTURES = Path(__file__).parent / "fixtures"


def test_books_listing_adapter():
    adapter = BooksToScrapeAdapter()
    html = (FIXTURES / "books_listing.html").read_text(encoding="utf-8")
    result = adapter.extract(
        FetchResult(
            url="https://books.toscrape.com/index.html",
            status_code=200,
            content_type="text/html",
            text=html,
        )
    )
    assert result.type == "book_collection"
    assert len(result.data["books"]) == 2
    assert result.data["books"][0]["id"] == 1000
    assert result.data["books"][0]["rating"] == 3


def test_books_detail_adapter():
    adapter = BooksToScrapeAdapter()
    html = (FIXTURES / "books_detail.html").read_text(encoding="utf-8")
    result = adapter.extract(
        FetchResult(
            url="https://books.toscrape.com/catalogue/book-one_1000/index.html",
            status_code=200,
            content_type="text/html",
            text=html,
        )
    )
    assert result.type == "book"
    assert result.data["id"] == 1000
    assert result.data["title"] == "Book One"
    assert result.data["stock_count"] == 22
    assert result.data["description"] == "A book description."
