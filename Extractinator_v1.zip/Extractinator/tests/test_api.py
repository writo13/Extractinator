from fastapi.testclient import TestClient

from extractinator.api import create_app
from extractinator.core.models import ExtractionResult


class FakeService:
    class Registry:
        def names(self):
            return ["books_to_scrape"]

        def find(self, url):
            return None

    registry = Registry()

    def capabilities(self, url):
        return {
            "url": url,
            "adapter": None,
            "generic_extractors": ["jsonld", "metadata", "generic_html"],
        }

    def extract(self, url):
        return ExtractionResult(
            url=url,
            type="webpage",
            data={"hello": "world"},
            method="generic_html",
        )


def test_dashboard():
    client = TestClient(create_app(FakeService()))
    response = client.get("/")
    assert response.status_code == 200
    assert "Extractinator" in response.text


def test_frontend_assets():
    client = TestClient(create_app(FakeService()))
    css = client.get("/assets/styles.css")
    js = client.get("/assets/app.js")
    assert css.status_code == 200
    assert ":root" in css.text
    assert js.status_code == 200
    assert "checkApi" in js.text


def test_health():
    client = TestClient(create_app(FakeService()))
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_adapters():
    client = TestClient(create_app(FakeService()))
    response = client.get("/adapters")
    assert response.status_code == 200
    assert response.json()["adapters"] == ["books_to_scrape"]


def test_capabilities():
    client = TestClient(create_app(FakeService()))
    response = client.get("/capabilities", params={"url": "https://example.com"})
    assert response.status_code == 200
    assert response.json()["generic_extractors"] == ["jsonld", "metadata", "generic_html"]


def test_extract():
    client = TestClient(create_app(FakeService()))
    response = client.get("/extract", params={"url": "https://example.com"})
    assert response.status_code == 200
    body = response.json()
    assert body["data"]["hello"] == "world"


def test_extract_post():
    client = TestClient(create_app(FakeService()))
    response = client.post("/extract", json={"url": "https://example.com"})
    assert response.status_code == 200
    assert response.json()["data"]["hello"] == "world"
