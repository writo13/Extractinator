from extractinator.core.fetcher import Fetcher
from extractinator.core.policy import URLPolicy
from extractinator.core.exceptions import URLNotAllowed


def test_policy_rejects_localhost():
    policy = URLPolicy()
    try:
        policy.validate("http://127.0.0.1:8000/")
    except URLNotAllowed:
        return
    raise AssertionError("localhost should be rejected")


def test_policy_rejects_non_http():
    policy = URLPolicy()
    try:
        policy.validate("ftp://example.com/file")
    except URLNotAllowed:
        return
    raise AssertionError("FTP should be rejected")


def test_fetcher_can_construct():
    fetcher = Fetcher(respect_robots=False, delay=0)
    assert fetcher.user_agent.startswith("Extractinator/")
