from extractinator.service import ExtractinatorService


def main():
    service = ExtractinatorService()
    url = input("Public URL to extract: ").strip()
    result = service.extract(url)
    print(result.as_dict())


if __name__ == "__main__":
    main()
