"""Small, read-only live smoke test.

Run manually from the project root after installing dependencies and with internet access:
    python scripts/live_smoke.py
"""

from extractinator.service import ExtractinatorService


URLS = [
    "https://books.toscrape.com/",
    "https://books.toscrape.com/catalogue/a-light-in-the-attic_1000/index.html",
]


if __name__ == "__main__":
    service = ExtractinatorService()
    for url in URLS:
        print(f"\n=== {url} ===")
        result = service.extract(url)
        print(result.as_dict())
