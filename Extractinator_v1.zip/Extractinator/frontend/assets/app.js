const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const urlInput = $('#url-input');
const extractBtn = $('#extract-btn');
const clearBtn = $('#clear-btn');
const validationMsg = $('#validation-msg');
const capabilityBox = $('#capability-box');
const statusPill = $('#api-status');
const errorBox = $('#error-box');
const emptyState = $('#empty-state');
const resultContent = $('#result-content');
const resultTitle = $('#result-title');
const resultMeta = $('#result-meta');
const overviewPanel = $('#tab-overview');
const dataPanel = $('#tab-data');
const jsonOutput = $('#json-output');
const copyBtn = $('#copy-btn');
const downloadBtn = $('#download-btn');
const recentList = $('#recent-list');

let lastResult = null;

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function isValidUrl(value) {
  try {
    const url = new URL(value);
    return ['http:', 'https:'].includes(url.protocol) && Boolean(url.hostname);
  } catch {
    return false;
  }
}

function setValidation(message = '', invalid = false) {
  validationMsg.textContent = message;
  validationMsg.classList.toggle('invalid', invalid);
}

function setLoading(loading) {
  extractBtn.disabled = loading;
  extractBtn.classList.toggle('loading', loading);
}

function showError(message) {
  errorBox.textContent = message;
  errorBox.classList.remove('hidden');
  emptyState.classList.add('hidden');
  resultContent.classList.add('hidden');
}

function clearError() {
  errorBox.classList.add('hidden');
  errorBox.textContent = '';
}

function formatValue(value) {
  if (value === null || value === undefined) return 'null';
  if (typeof value === 'string') return value;
  return JSON.stringify(value, null, 2);
}

function renderOverview(payload) {
  const source = payload.source || {};
  const data = payload.data || {};
  const keys = Object.keys(data);
  overviewPanel.innerHTML = `
    <div class="overview-grid">
      <div class="overview-card"><div class="overview-label">Type</div><div class="overview-value">${escapeHtml(data.type || 'webpage')}</div></div>
      <div class="overview-card"><div class="overview-label">Method</div><div class="overview-value">${escapeHtml(source.method || 'unknown')}</div></div>
      <div class="overview-card"><div class="overview-label">Adapter</div><div class="overview-value">${escapeHtml(source.adapter || 'generic')}</div></div>
      <div class="overview-card"><div class="overview-label">Fields</div><div class="overview-value">${keys.length}</div></div>
      <div class="overview-card" style="grid-column:1/-1"><div class="overview-label">Source URL</div><div class="overview-value">${escapeHtml(source.url || '')}</div></div>
      <div class="overview-card" style="grid-column:1/-1"><div class="overview-label">Retrieved</div><div class="overview-value">${escapeHtml(source.retrieved_at || '')}</div></div>
    </div>
    ${payload.warnings?.length ? `<div class="capability-box" style="margin-top:12px"><div class="overview-label">Warnings</div><div class="data-value">${escapeHtml(payload.warnings.join('\n'))}</div></div>` : ''}
  `;
}

function renderData(data) {
  const entries = Object.entries(data || {});
  if (!entries.length) {
    dataPanel.innerHTML = '<div class="capability-placeholder">No structured data returned.</div>';
    return;
  }

  dataPanel.innerHTML = `<div class="data-tree">${entries.map(([key, value]) => `
    <div class="data-item">
      <div class="data-key">${escapeHtml(key)}</div>
      <div class="data-value">${escapeHtml(formatValue(value))}</div>
    </div>
  `).join('')}</div>`;
}

function renderResult(payload) {
  lastResult = payload;
  clearError();
  emptyState.classList.add('hidden');
  resultContent.classList.remove('hidden');

  const source = payload.source || {};
  const type = payload.data?.type || 'webpage';
  resultTitle.textContent = type.replaceAll('_', ' ');
  resultMeta.innerHTML = `
    <div class="meta-chip"><strong>Type</strong> ${escapeHtml(type)}</div>
    <div class="meta-chip"><strong>Method</strong> ${escapeHtml(source.method || 'unknown')}</div>
    <div class="meta-chip"><strong>Adapter</strong> ${escapeHtml(source.adapter || 'generic')}</div>
    <div class="meta-chip"><strong>URL</strong> ${escapeHtml(source.url || '')}</div>
  `;

  renderOverview(payload);
  renderData(payload.data);
  jsonOutput.textContent = JSON.stringify(payload, null, 2);
  copyBtn.disabled = false;
  downloadBtn.disabled = false;
}

function renderCapability(payload) {
  const adapter = payload.adapter;
  const generic = (payload.generic_extractors || []).join(', ');
  capabilityBox.innerHTML = `
    <div class="capability-row">
      <div class="capability-main">
        <div class="capability-title">${adapter ? `Adapter: ${escapeHtml(adapter)}` : 'Generic extraction'}</div>
        <div class="capability-sub">${escapeHtml(payload.url || '')}</div>
      </div>
      <div class="badge">${adapter ? 'ADAPTER READY' : 'GENERIC READY'}</div>
    </div>
    <div class="capability-sub" style="margin-top:10px">Available generic extractors: ${escapeHtml(generic)}</div>
  `;
}

async function checkApi() {
  try {
    const response = await fetch('/health', { cache: 'no-store' });
    if (!response.ok) throw new Error('Health check failed');
    statusPill.classList.add('ok');
    statusPill.classList.remove('bad');
    statusPill.innerHTML = '<span class="status-dot"></span> API online';
  } catch {
    statusPill.classList.add('bad');
    statusPill.classList.remove('ok');
    statusPill.innerHTML = '<span class="status-dot"></span> API offline';
  }
}

async function checkCapabilities(url) {
  if (!isValidUrl(url)) {
    capabilityBox.innerHTML = '<div class="capability-placeholder">Enter a valid http(s) URL to inspect capabilities.</div>';
    return;
  }

  capabilityBox.innerHTML = '<div class="capability-placeholder">Checking extraction capabilities…</div>';

  try {
    const response = await fetch(`/capabilities?url=${encodeURIComponent(url)}`);
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.detail || payload.error || 'Could not inspect capabilities.');
    renderCapability(payload);
  } catch (error) {
    capabilityBox.innerHTML = `<div class="capability-placeholder">${escapeHtml(error.message)}</div>`;
  }
}

async function extract() {
  const url = urlInput.value.trim();

  if (!isValidUrl(url)) {
    setValidation('Please enter a valid public http(s) URL.', true);
    urlInput.focus();
    return;
  }

  setValidation('');
  clearError();
  setLoading(true);
  resultTitle.textContent = 'Extracting…';

  try {
    const response = await fetch(`/extract?url=${encodeURIComponent(url)}`);
    const payload = await response.json();

    if (!response.ok) {
      throw new Error(payload.error || payload.detail || 'Extraction failed.');
    }

    renderResult(payload);
    addRecent(url);
    renderRecent();
  } catch (error) {
    resultTitle.textContent = 'Extraction failed';
    showError(error.message);
  } finally {
    setLoading(false);
  }
}

function addRecent(url) {
  const current = JSON.parse(localStorage.getItem('extractinator_recent') || '[]');
  const next = [url, ...current.filter(item => item !== url)].slice(0, 6);
  localStorage.setItem('extractinator_recent', JSON.stringify(next));
}

function renderRecent() {
  const urls = JSON.parse(localStorage.getItem('extractinator_recent') || '[]');
  if (!urls.length) {
    recentList.innerHTML = '<div class="recent-empty">No extractions yet.</div>';
    return;
  }
  recentList.innerHTML = urls.map(url => `<button type="button" class="recent-item" data-url="${escapeHtml(url)}">${escapeHtml(url)}</button>`).join('');
  $$('.recent-item').forEach(button => {
    button.addEventListener('click', () => {
      urlInput.value = button.dataset.url;
      setValidation('');
      checkCapabilities(button.dataset.url);
    });
  });
}

function clearAll() {
  urlInput.value = '';
  setValidation('');
  clearError();
  capabilityBox.innerHTML = '<div class="capability-placeholder">Enter a URL and check capabilities before extracting.</div>';
  emptyState.classList.remove('hidden');
  resultContent.classList.add('hidden');
  resultTitle.textContent = 'Waiting for extraction';
  copyBtn.disabled = true;
  downloadBtn.disabled = true;
  lastResult = null;
  urlInput.focus();
}

urlInput.addEventListener('input', () => {
  const value = urlInput.value.trim();
  if (!value) {
    setValidation('');
    return;
  }
  if (!isValidUrl(value)) {
    setValidation('Waiting for a valid http(s) URL.', true);
    return;
  }
  setValidation('Valid URL. You can inspect capabilities or extract it.');
});

urlInput.addEventListener('blur', () => {
  const value = urlInput.value.trim();
  if (isValidUrl(value)) checkCapabilities(value);
});

extractBtn.addEventListener('click', extract);
clearBtn.addEventListener('click', clearAll);

$('.example-btn').closest && $$('.example-btn').forEach(button => {
  button.addEventListener('click', () => {
    urlInput.value = button.dataset.url;
    setValidation('Valid URL.');
    checkCapabilities(button.dataset.url);
  });
});

$$('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    $$('.tab').forEach(item => item.classList.remove('active'));
    $$('.tab-panel').forEach(item => item.classList.remove('active'));
    tab.classList.add('active');
    $(`#tab-${tab.dataset.tab}`).classList.add('active');
  });
});

copyBtn.addEventListener('click', async () => {
  if (!lastResult) return;
  await navigator.clipboard.writeText(JSON.stringify(lastResult, null, 2));
  copyBtn.textContent = 'Copied';
  setTimeout(() => { copyBtn.textContent = 'Copy JSON'; }, 1200);
});

downloadBtn.addEventListener('click', () => {
  if (!lastResult) return;
  const blob = new Blob([JSON.stringify(lastResult, null, 2)], { type: 'application/json' });
  const href = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = href;
  link.download = `extractinator-${Date.now()}.json`;
  link.click();
  URL.revokeObjectURL(href);
});

checkApi();
renderRecent();
