from __future__ import annotations

from extractinator.adapters.books_to_scrape import BooksToScrapeAdapter
from extractinator.core.fetcher import Fetcher
from extractinator.core.models import ExtractionResult
from extractinator.core.registry import AdapterRegistry
from extractinator.extractors.generic import extract_generic


class ExtractinatorService:
    def __init__(self, fetcher: Fetcher | None = None):
        self.fetcher = fetcher or Fetcher()
        self.registry = AdapterRegistry(
            [BooksToScrapeAdapter()]
        )

    def capabilities(self, url: str) -> dict:
        adapter = self.registry.find(url)
        return {
            "url": url,
            "adapter": adapter.name if adapter else None,
            "generic_extractors": [
                "jsonld",
                "metadata",
                "generic_html",
            ],
        }

    def extract(self, url: str) -> ExtractionResult:
        result = self.fetcher.fetch(url)
        adapter = self.registry.find(result.url)

        if adapter:
            return adapter.extract(result)

        record_type, data, method = extract_generic(
            result.text,
            result.url,
        )

        return ExtractionResult(
            url=result.url,
            type=record_type,
            data=data,
            method=method,
        )
