from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class SourceInfo(BaseModel):
    url: str
    retrieved_at: str
    method: str
    adapter: str | None = None


class ExtractionResponse(BaseModel):
    source: SourceInfo
    data: dict[str, Any]
    warnings: list[str] = Field(default_factory=list)
