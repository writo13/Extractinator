from __future__ import annotations

import threading
import time
from collections import defaultdict
from urllib.parse import urljoin, urlparse
from urllib.robotparser import RobotFileParser

import requests

from .exceptions import FetchError, ResponseTooLarge, RobotsDisallowed, UnsupportedContentType
from .models import FetchResult
from .policy import URLPolicy


class Fetcher:
    """Polite HTTP fetcher for publicly accessible web pages."""

    RETRYABLE = {429, 500, 502, 503, 504}
    DEFAULT_CONTENT_TYPES = {
        "text/html",
        "application/xhtml+xml",
        "application/json",
        "application/ld+json",
        "text/plain",
    }

    def __init__(
        self,
        *,
        user_agent: str = "Extractinator/0.1 (+https://example.invalid/extractinator)",
        delay: float = 0.5,
        retries: int = 3,
        backoff: float = 1.0,
        timeout: float = 15.0,
        max_bytes: int = 5_000_000,
        respect_robots: bool = True,
        session: requests.Session | None = None,
        policy: URLPolicy | None = None,
    ):
        self.user_agent = user_agent
        self.delay = max(0.0, delay)
        self.retries = max(0, retries)
        self.backoff = max(0.0, backoff)
        self.timeout = timeout
        self.max_bytes = max_bytes
        self.respect_robots = respect_robots
        self.session = session or requests.Session()
        self.session.headers.update(
            {
                "User-Agent": self.user_agent,
                "Accept": "text/html,application/xhtml+xml,application/json,application/ld+json;q=0.9,*/*;q=0.1",
            }
        )
        self.policy = policy or URLPolicy()
        self._cache: dict[str, tuple[float, FetchResult]] = {}
        self.cache_ttl = 3600.0
        self._robots: dict[str, RobotFileParser] = {}
        self._last_by_host: dict[str, float] = defaultdict(float)
        self._lock = threading.Lock()

    def _throttle(self, host: str) -> None:
        with self._lock:
            now = time.monotonic()
            elapsed = now - self._last_by_host[host]
            wait = self.delay - elapsed
            if wait > 0:
                time.sleep(wait)
            self._last_by_host[host] = time.monotonic()

    def _robots_for(self, url: str) -> RobotFileParser:
        parsed = urlparse(url)
        origin = f"{parsed.scheme}://{parsed.netloc}"
        if origin in self._robots:
            return self._robots[origin]

        robots_url = urljoin(f"{origin}/", "robots.txt")
        self._throttle(parsed.hostname or origin)

        parser = RobotFileParser()
        try:
            response = self.session.get(robots_url, timeout=self.timeout, allow_redirects=False)
        except requests.RequestException:
            parser.parse([])
        else:
            if response.status_code == 200:
                parser.parse(response.text.splitlines())
            else:
                parser.parse([])
        self._robots[origin] = parser
        return parser

    def _check_robots(self, url: str) -> None:
        if not self.respect_robots:
            return
        parser = self._robots_for(url)
        if not parser.can_fetch(self.user_agent, url):
            raise RobotsDisallowed(url)

    def _cached(self, url: str) -> FetchResult | None:
        item = self._cache.get(url)
        if not item:
            return None
        timestamp, result = item
        if time.monotonic() - timestamp <= self.cache_ttl:
            return result
        del self._cache[url]
        return None

    def _read_limited(self, response: requests.Response) -> bytes:
        data = bytearray()
        for chunk in response.iter_content(chunk_size=64 * 1024):
            if not chunk:
                continue
            data.extend(chunk)
            if len(data) > self.max_bytes:
                raise ResponseTooLarge(
                    f"Response exceeded {self.max_bytes} bytes."
                )
        return bytes(data)

    def fetch(self, url: str) -> FetchResult:
        self.policy.validate(url)
        self._check_robots(url)

        cached = self._cached(url)
        if cached:
            return cached

        current_url = url
        original_url = url
        last_error: Exception | None = None
        redirect_count = 0
        max_redirects = 5

        for attempt in range(self.retries + 1):
            self.policy.validate(current_url)
            self._check_robots(current_url)
            host = urlparse(current_url).hostname or ""
            self._throttle(host)

            try:
                response = self.session.get(
                    current_url,
                    timeout=self.timeout,
                    allow_redirects=False,
                    stream=True,
                )
            except requests.RequestException as exc:
                last_error = FetchError(f"Network error: {exc}")
            else:
                if 300 <= response.status_code < 400:
                    location = response.headers.get("Location")
                    if not location:
                        raise FetchError("Redirect response did not include Location.")
                    redirect_count += 1
                    if redirect_count > max_redirects:
                        raise FetchError("Maximum redirect count exceeded.")
                    next_url = urljoin(current_url, location)
                    if next_url == current_url:
                        raise FetchError("Redirect loop detected.")
                    current_url = next_url
                    continue

                if response.status_code == 200:
                    content_type = response.headers.get("Content-Type", "").split(";", 1)[0].strip().lower()
                    if content_type and content_type not in self.DEFAULT_CONTENT_TYPES:
                        raise UnsupportedContentType(content_type)
                    raw = self._read_limited(response)
                    response.encoding = response.encoding or "utf-8"
                    text = raw.decode(response.encoding, errors="replace")
                    result = FetchResult(
                        url=current_url,
                        status_code=200,
                        content_type=content_type or "text/html",
                        text=text,
                        encoding=response.encoding,
                        redirected_from=original_url if current_url != original_url else None,
                    )
                    self._cache[url] = (time.monotonic(), result)
                    return result

                if response.status_code == 404:
                    raise FetchError(f"404 Not Found: {current_url}")

                if response.status_code not in self.RETRYABLE:
                    raise FetchError(
                        f"HTTP {response.status_code} from {current_url}"
                    )

                last_error = FetchError(
                    f"Temporary HTTP {response.status_code} from {current_url}"
                )
                retry_after = response.headers.get("Retry-After", "")
                if retry_after.isdigit():
                    time.sleep(min(int(retry_after), 30))

            if attempt < self.retries:
                time.sleep(self.backoff * (2 ** attempt))

        raise last_error or FetchError("Fetch failed.")
