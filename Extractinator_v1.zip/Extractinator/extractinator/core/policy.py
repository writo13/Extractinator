from __future__ import annotations

import ipaddress
import socket
from urllib.parse import urlparse

from .exceptions import URLNotAllowed


class URLPolicy:
    """Conservative public-web URL policy used by the fetcher."""

    def __init__(self, allow_ports: set[int] | None = None):
        self.allow_ports = allow_ports or {80, 443}

    def validate(self, url: str) -> None:
        parsed = urlparse(url)

        if parsed.scheme not in {"http", "https"}:
            raise URLNotAllowed("Only HTTP and HTTPS URLs are allowed.")

        if not parsed.hostname:
            raise URLNotAllowed("URL must contain a hostname.")

        if parsed.username or parsed.password:
            raise URLNotAllowed("URLs containing user credentials are not allowed.")

        if parsed.port and parsed.port not in self.allow_ports:
            raise URLNotAllowed("Only standard HTTP/HTTPS ports are allowed.")

        host = parsed.hostname

        try:
            address = ipaddress.ip_address(host)
            self._validate_ip(address)
            return
        except ValueError:
            pass

        try:
            infos = socket.getaddrinfo(host, parsed.port or (443 if parsed.scheme == "https" else 80))
        except socket.gaierror as exc:
            raise URLNotAllowed(f"Unable to resolve hostname: {host}") from exc

        for info in infos:
            address = ipaddress.ip_address(info[4][0])
            self._validate_ip(address)

    @staticmethod
    def _validate_ip(address: ipaddress._BaseAddress) -> None:
        if (
            address.is_private
            or address.is_loopback
            or address.is_link_local
            or address.is_reserved
            or address.is_multicast
            or address.is_unspecified
        ):
            raise URLNotAllowed(
                f"Local or non-public network address is not allowed: {address}"
            )
