class ExtractinatorError(Exception):
    """Base exception for Extractinator."""


class FetchError(ExtractinatorError):
    """Upstream fetching failed."""


class RobotsDisallowed(FetchError):
    """The requested URL is disallowed by robots.txt."""


class URLNotAllowed(FetchError):
    """The URL is outside the public-web policy."""


class ResponseTooLarge(FetchError):
    """The upstream response exceeded the configured size limit."""


class UnsupportedContentType(FetchError):
    """The response content type is not supported."""


class ExtractionError(ExtractinatorError):
    """A page could not be extracted."""
