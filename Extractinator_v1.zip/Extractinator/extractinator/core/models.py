from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


@dataclass
class FetchResult:
    url: str
    status_code: int
    content_type: str
    text: str
    encoding: str | None = None
    redirected_from: str | None = None


@dataclass
class ExtractionResult:
    url: str
    type: str
    data: dict[str, Any]
    method: str
    adapter: str | None = None
    warnings: list[str] = field(default_factory=list)
    retrieved_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def as_dict(self) -> dict[str, Any]:
        return {
            "source": {
                "url": self.url,
                "retrieved_at": self.retrieved_at,
                "method": self.method,
                "adapter": self.adapter,
            },
            "data": self.data,
            "warnings": self.warnings,
        }
