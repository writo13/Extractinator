from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from extractinator.core.exceptions import ExtractinatorError, RobotsDisallowed, URLNotAllowed
from extractinator.schemas.common import ExtractionResponse
from extractinator.service import ExtractinatorService


FRONTEND_DIR = Path(__file__).resolve().parent.parent / "frontend"


class ExtractRequest(BaseModel):
    url: str = Field(..., min_length=8, max_length=2048)


def _error_response(status_code: int, exc: Exception):
    return JSONResponse(
        status_code=status_code,
        content={
            "error": str(exc),
            "type": type(exc).__name__,
        },
    )


def create_app(service: ExtractinatorService | None = None) -> FastAPI:
    service = service or ExtractinatorService()

    app = FastAPI(
        title="Extractinator",
        version="0.1.0",
        description=(
            "A public-web extraction API using site adapters and generic structured-data extraction."
        ),
        docs_url="/docs",
        redoc_url="/redoc",
    )

    app.mount("/assets", StaticFiles(directory=FRONTEND_DIR / "assets"), name="assets")

    @app.get("/", include_in_schema=False)
    def dashboard():
        return FileResponse(FRONTEND_DIR / "index.html")

    @app.get("/health")
    def health():
        return {
            "status": "ok",
            "service": "extractinator",
            "version": "0.1.0",
        }

    @app.get("/adapters")
    def adapters():
        return {
            "adapters": service.registry.names(),
        }

    @app.get("/capabilities")
    def capabilities(url: str = Query(..., min_length=8, max_length=2048)):
        try:
            return service.capabilities(url)
        except URLNotAllowed as exc:
            raise HTTPException(
                status_code=400,
                detail=str(exc),
            ) from exc

    @app.get("/extract", response_model=ExtractionResponse)
    def extract(url: str = Query(..., min_length=8, max_length=2048)):
        try:
            result = service.extract(url)
            return result.as_dict()
        except URLNotAllowed as exc:
            return _error_response(400, exc)
        except RobotsDisallowed as exc:
            return _error_response(403, exc)
        except ExtractinatorError as exc:
            return _error_response(502, exc)
        except Exception:
            return JSONResponse(
                status_code=500,
                content={
                    "error": "unexpected internal error",
                    "type": "InternalServerError",
                },
            )

    @app.post("/extract", response_model=ExtractionResponse)
    def extract_post(request: ExtractRequest):
        try:
            result = service.extract(request.url)
            return result.as_dict()
        except URLNotAllowed as exc:
            return _error_response(400, exc)
        except RobotsDisallowed as exc:
            return _error_response(403, exc)
        except ExtractinatorError as exc:
            return _error_response(502, exc)
        except Exception:
            return JSONResponse(
                status_code=500,
                content={
                    "error": "unexpected internal error",
                    "type": "InternalServerError",
                },
            )

    return app
