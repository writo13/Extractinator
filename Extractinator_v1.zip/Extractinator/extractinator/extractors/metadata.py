from __future__ import annotations

from bs4 import BeautifulSoup


def extract_metadata(soup: BeautifulSoup) -> dict[str, str | None | list[str]]:
    def meta(name: str | None = None, prop: str | None = None) -> str | None:
        if name:
            tag = soup.find("meta", attrs={"name": name})
        else:
            tag = soup.find("meta", attrs={"property": prop})
        return tag.get("content", "").strip() if tag else None

    canonical_tag = soup.find("link", rel="canonical")

    images: list[str] = []
    for tag in soup.find_all("meta", attrs={"property": "og:image"}):
        if tag.get("content"):
            images.append(tag["content"].strip())

    return {
        "title": meta(prop="og:title") or (soup.title.get_text(strip=True) if soup.title else None),
        "description": meta(prop="og:description") or meta(name="description"),
        "author": meta(name="author") or meta(prop="article:author"),
        "published_at": meta(prop="article:published_time") or meta(name="date"),
        "canonical": canonical_tag.get("href") if canonical_tag else None,
        "site_name": meta(prop="og:site_name"),
        "images": images,
        "og_type": meta(prop="og:type"),
    }
