from __future__ import annotations

from bs4 import BeautifulSoup

from .html import extract_html
from .jsonld import best_jsonld_record, extract_jsonld
from .metadata import extract_metadata


def _clean_jsonld(record: dict) -> dict:
    return {k: v for k, v in record.items() if k != "_normalized_type"}


def infer_type(metadata: dict, html: dict, jsonld: dict | None) -> str:
    if jsonld:
        return jsonld.get("_normalized_type", "structured")

    og_type = metadata.get("og_type")
    if og_type == "article":
        return "article"

    if html.get("headings") and metadata.get("author"):
        return "article"

    return "webpage"


def extract_generic(html_text: str, url: str) -> tuple[str, dict, str]:
    soup = BeautifulSoup(html_text, "html.parser")
    jsonld_records = extract_jsonld(soup)
    jsonld = best_jsonld_record(jsonld_records)
    metadata = extract_metadata(soup)
    html = extract_html(soup, url)

    record_type = infer_type(metadata, html, jsonld)

    data = {
        "type": record_type,
        "metadata": metadata,
        "content": html,
    }

    if jsonld:
        data["structured_data"] = _clean_jsonld(jsonld)

    return record_type, data, "jsonld" if jsonld else "generic_html"
