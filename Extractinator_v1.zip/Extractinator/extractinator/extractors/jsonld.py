from __future__ import annotations

import json
from typing import Any

from bs4 import BeautifulSoup


KNOWN_TYPES = {
    "Article": "article",
    "NewsArticle": "article",
    "BlogPosting": "article",
    "Product": "product",
    "Book": "book",
    "JobPosting": "job",
    "Recipe": "recipe",
    "Event": "event",
    "Organization": "organization",
    "Person": "person",
    "Movie": "movie",
    "WebPage": "webpage",
}


def _as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def extract_jsonld(soup: BeautifulSoup) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []

    for script in soup.find_all("script", attrs={"type": "application/ld+json"}):
        raw = script.string or script.get_text()
        if not raw.strip():
            continue
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            continue

        candidates = []
        if isinstance(payload, dict) and "@graph" in payload:
            candidates.extend(_as_list(payload["@graph"]))
        else:
            candidates.extend(_as_list(payload))

        for item in candidates:
            if not isinstance(item, dict):
                continue
            raw_type = item.get("@type")
            types = raw_type if isinstance(raw_type, list) else [raw_type]
            normalized = next(
                (KNOWN_TYPES[t] for t in types if t in KNOWN_TYPES),
                "structured",
            )
            enriched = dict(item)
            enriched["_normalized_type"] = normalized
            records.append(enriched)

    return records


def best_jsonld_record(records: list[dict[str, Any]]) -> dict[str, Any] | None:
    if not records:
        return None
    preferred = [r for r in records if r.get("_normalized_type") != "structured"]
    return (preferred or records)[0]
