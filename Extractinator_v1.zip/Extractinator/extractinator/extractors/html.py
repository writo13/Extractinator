from __future__ import annotations

from urllib.parse import urljoin

from bs4 import BeautifulSoup


def extract_html(soup: BeautifulSoup, base_url: str) -> dict:
    article = soup.find("article")
    root = article or soup

    headings = [
        tag.get_text(" ", strip=True)
        for tag in root.find_all(["h1", "h2", "h3"])
        if tag.get_text(" ", strip=True)
    ]

    paragraphs = [
        tag.get_text(" ", strip=True)
        for tag in root.find_all("p")
        if tag.get_text(" ", strip=True)
    ]

    links = []
    for tag in root.find_all("a", href=True):
        text = tag.get_text(" ", strip=True)
        links.append(
            {
                "text": text,
                "url": urljoin(base_url, tag["href"]),
            }
        )

    images = []
    for tag in root.find_all("img", src=True):
        images.append(
            {
                "alt": tag.get("alt", "").strip(),
                "url": urljoin(base_url, tag["src"]),
            }
        )

    tables = []
    for table in root.find_all("table"):
        rows = []
        for tr in table.find_all("tr"):
            cells = [
                cell.get_text(" ", strip=True)
                for cell in tr.find_all(["th", "td"])
            ]
            if cells:
                rows.append(cells)
        if rows:
            tables.append(rows)

    return {
        "headings": headings,
        "paragraphs": paragraphs,
        "links": links[:100],
        "images": images[:100],
        "tables": tables[:20],
    }
