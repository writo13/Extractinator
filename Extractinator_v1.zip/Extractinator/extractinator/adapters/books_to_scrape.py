from __future__ import annotations

import re
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup

from extractinator.adapters.base import Adapter
from extractinator.core.exceptions import ExtractionError
from extractinator.core.models import ExtractionResult, FetchResult

RATINGS = {"One": 1, "Two": 2, "Three": 3, "Four": 4, "Five": 5}
KEY_RE = re.compile(r"^(?P<slug>[a-z0-9-]+)_(?P<id>\d+)$")


class BooksToScrapeAdapter(Adapter):
    name = "books_to_scrape"
    host = "books.toscrape.com"

    def can_handle(self, url: str) -> bool:
        return urlparse(url).hostname == self.host

    @staticmethod
    def _price(text: str) -> float | None:
        match = re.search(r"\d+(?:\.\d+)?", text or "")
        return float(match.group()) if match else None

    @staticmethod
    def _rating(tag) -> int | None:
        if not tag:
            return None
        for cls in tag.get("class", []):
            if cls in RATINGS:
                return RATINGS[cls]
        return None

    @staticmethod
    def _book_id_from_url(url: str) -> int | None:
        parts = [part for part in urlparse(url).path.split("/") if part]
        if len(parts) < 3:
            return None
        key = parts[-2]
        match = KEY_RE.match(key)
        return int(match.group("id")) if match else None

    def _parse_listing(self, soup: BeautifulSoup, result: FetchResult) -> dict:
        books = []
        for pod in soup.select("article.product_pod"):
            link = pod.select_one("h3 a")
            price = pod.select_one("p.price_color")
            availability = pod.select_one("p.availability")
            image = pod.select_one("img")
            if not link or not price:
                raise ExtractionError("Book listing markup is missing required fields.")

            item_url = urljoin(result.url, link.get("href", ""))
            books.append(
                {
                    "id": self._book_id_from_url(item_url),
                    "title": link.get("title") or link.get_text(" ", strip=True),
                    "url": item_url,
                    "price": self._price(price.get_text(" ", strip=True)),
                    "currency": "GBP" if "£" in price.get_text() else None,
                    "rating": self._rating(pod.select_one("p.star-rating")),
                    "in_stock": bool(
                        availability
                        and "in stock" in availability.get_text(" ", strip=True).lower()
                    ),
                    "image": urljoin(result.url, image["src"]) if image and image.get("src") else None,
                }
            )

        if not books:
            return {"type": "book_collection", "books": []}

        count_text = soup.select_one("form.form-horizontal strong")
        total_results = int(count_text.get_text(strip=True)) if count_text and count_text.get_text(strip=True).isdigit() else len(books)

        pager = soup.select_one("ul.pager li.current")
        current_page = None
        total_pages = None
        if pager:
            match = re.search(r"Page\s+(\d+)\s+of\s+(\d+)", pager.get_text(" ", strip=True))
            if match:
                current_page = int(match.group(1))
                total_pages = int(match.group(2))

        return {
            "type": "book_collection",
            "books": books,
            "pagination": {
                "page": current_page,
                "total_pages": total_pages,
                "total_results": total_results,
            },
        }

    def _parse_detail(self, soup: BeautifulSoup, result: FetchResult) -> dict:
        main = soup.select_one("div.product_main")
        title = main.select_one("h1") if main else None
        price = main.select_one("p.price_color") if main else None
        if not main or not title or not price:
            raise ExtractionError("Book detail markup is missing required fields.")

        table = {}
        for row in soup.select("table.table-striped tr"):
            th = row.find("th")
            td = row.find("td")
            if th and td:
                table[th.get_text(strip=True)] = td.get_text(" ", strip=True)

        crumbs = soup.select("ul.breadcrumb li")
        category = crumbs[2].get_text(strip=True) if len(crumbs) >= 4 else None
        description = None
        description_header = soup.select_one("#product_description")
        if description_header:
            paragraph = description_header.find_next_sibling("p")
            if paragraph:
                description = paragraph.get_text(" ", strip=True)

        availability = main.select_one("p.availability")
        stock_text = availability.get_text(" ", strip=True) if availability else ""
        count = re.search(r"(\d+)\s+available", stock_text)
        image = soup.select_one("#product_gallery img")

        return {
            "type": "book",
            "id": self._book_id_from_url(result.url),
            "key": [p for p in urlparse(result.url).path.split("/") if p][-2] if len([p for p in urlparse(result.url).path.split("/") if p]) >= 2 else None,
            "title": title.get_text(" ", strip=True),
            "url": result.url,
            "price": self._price(price.get_text(" ", strip=True)),
            "currency": "GBP" if "£" in price.get_text() else None,
            "rating": self._rating(main.select_one("p.star-rating")),
            "in_stock": "in stock" in stock_text.lower(),
            "image": urljoin(result.url, image["src"]) if image and image.get("src") else None,
            "upc": table.get("UPC"),
            "product_type": table.get("Product Type"),
            "category": category,
            "description": description,
            "price_excl_tax": self._price(table.get("Price (excl. tax)", "")),
            "price_incl_tax": self._price(table.get("Price (incl. tax)", "")),
            "tax": self._price(table.get("Tax", "")),
            "stock_count": int(count.group(1)) if count else None,
            "num_reviews": int(table["Number of reviews"]) if table.get("Number of reviews", "").isdigit() else None,
        }

    def extract(self, result: FetchResult) -> ExtractionResult:
        soup = BeautifulSoup(result.text, "html.parser")
        if soup.select_one("div.product_main"):
            data = self._parse_detail(soup, result)
            return ExtractionResult(
                url=result.url,
                type="book",
                data=data,
                method="site_adapter",
                adapter=self.name,
            )

        data = self._parse_listing(soup, result)
        return ExtractionResult(
            url=result.url,
            type="book_collection",
            data=data,
            method="site_adapter",
            adapter=self.name,
        )
