from extractinator.service import ExtractinatorService


if __name__ == "__main__":
    service = ExtractinatorService()
    print(service.capabilities("https://books.toscrape.com/"))
