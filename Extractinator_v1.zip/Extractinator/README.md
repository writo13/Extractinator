# Extractinator

**Extractinator** is a self-contained public-web extraction platform that turns a publicly accessible webpage into structured JSON through a REST API and a browser dashboard.

It is intentionally designed as a **layered extraction system** rather than a single universal scraper:

```text
Public URL
   ↓
URL policy + robots.txt
   ↓
Fetcher (throttle + cache + retries + limits)
   ↓
Site adapter? ── yes ──→ adapter extraction
   │
   no
   ↓
JSON-LD → metadata → semantic HTML
   ↓
Normalized JSON + provenance
   ↓
FastAPI + web dashboard
```

The first site-specific adapter is for `books.toscrape.com`, a public scraping-practice sandbox.

## What is included

### Backend

- FastAPI REST API
- GET and POST extraction endpoints
- `/health` health check
- `/adapters` installed-adapter discovery
- `/capabilities` extraction-method discovery
- Swagger UI at `/docs`
- ReDoc at `/redoc`
- Public HTTP/HTTPS URL validation
- Private/local-network blocking to reduce SSRF risk
- Redirect validation
- `robots.txt` handling by default
- Per-host request throttling
- In-memory cache with TTL
- Retry and exponential backoff for temporary errors
- Response-size limits
- Content-type filtering
- Site-adapter architecture
- Generic JSON-LD, metadata, and semantic HTML extraction

### Frontend

The included dashboard is served directly by FastAPI, so there is no separate Node.js build step.

Features:

- URL input
- One-click extraction
- Capability detection
- Books.toscrape quick examples
- API health indicator
- Extraction method/adapter badges
- Overview, normalized data, and raw JSON tabs
- Copy JSON
- Download JSON
- Local recent-URL history
- Links to Swagger and ReDoc
- Responsive layout

## Project structure

```text
Extractinator/
├── app.py
├── run.py
├── start.bat
├── test.bat
├── requirements.txt
├── README.md
├── .gitignore
│
├── frontend/
│   ├── index.html
│   └── assets/
│       ├── styles.css
│       └── app.js
│
├── extractinator/
│   ├── core/
│   │   ├── exceptions.py
│   │   ├── fetcher.py
│   │   ├── models.py
│   │   ├── policy.py
│   │   └── registry.py
│   ├── extractors/
│   │   ├── generic.py
│   │   ├── html.py
│   │   ├── jsonld.py
│   │   └── metadata.py
│   ├── adapters/
│   │   ├── base.py
│   │   └── books_to_scrape.py
│   ├── schemas/
│   │   └── common.py
│   ├── api.py
│   └── service.py
│
├── tests/
│   ├── fixtures/
│   ├── test_api.py
│   ├── test_books_adapter.py
│   ├── test_extractors.py
│   └── test_fetcher.py
│
├── scripts/
│   ├── demo.py
│   └── live_smoke.py
│
└── legacy/
    └── original Books.toscrape implementation and tests
```

## Windows setup

Open the **outer `Extractinator` folder** in VS Code.

### Option A — easiest

Double-click:

```text
start.bat
```

It will create the virtual environment if necessary, install dependencies, and start the API.

### Option B — terminal

Use VS Code's Command Prompt terminal:

```cmd
python -m venv .venv
.venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m uvicorn app:app --reload
```

Then open:

```text
http://127.0.0.1:8000/
```

The dashboard and API are hosted by the same process.

## Test the project

Run:

```cmd
python -m pytest -q
```

or double-click:

```text
test.bat
```

The normal test suite is offline and deterministic.

Live tests are intentionally separate because they depend on external network availability and the current state of the target website:

```cmd
python scripts\live_smoke.py
```

A live test should be considered a manual smoke check, not proof that every website remains compatible forever.

## API

### Health

```http
GET /health
```

### Installed adapters

```http
GET /adapters
```

### Capabilities

```http
GET /capabilities?url=https://books.toscrape.com/
```

### Extract with GET

```http
GET /extract?url=https://books.toscrape.com/
```

### Extract with POST

```http
POST /extract
Content-Type: application/json

{
  "url": "https://books.toscrape.com/"
}
```

### Interactive documentation

```text
http://127.0.0.1:8000/docs
http://127.0.0.1:8000/redoc
```

## Example result

A successful extraction returns a structure like:

```json
{
  "source": {
    "url": "https://example.com/article",
    "retrieved_at": "2026-10-01T18:30:00+00:00",
    "method": "jsonld",
    "adapter": null
  },
  "data": {
    "type": "article",
    "metadata": {
      "title": "Example Article"
    },
    "content": {
      "headings": [],
      "paragraphs": [],
      "links": [],
      "images": [],
      "tables": []
    },
    "structured_data": {}
  },
  "warnings": []
}
```

## Extraction strategy

Extractinator chooses the most specific available strategy:

1. **Site adapter** — exact parsing for a known website.
2. **JSON-LD** — structured data embedded in the page.
3. **Metadata** — OpenGraph, description, author, canonical URL, etc.
4. **Semantic HTML** — headings, paragraphs, links, images, and tables.

This is why Extractinator can handle both known sites and unfamiliar pages without pretending that all websites share the same markup.

## Adding another site adapter

Create a class implementing the `Adapter` interface in `extractinator/adapters/`.

Conceptually:

```python
class MyAdapter(Adapter):
    name = "my_site"

    def can_handle(self, url: str) -> bool:
        return urlparse(url).hostname == "example.com"

    def extract(self, result: FetchResult) -> ExtractionResult:
        ...
```

Register it in `ExtractinatorService`.

The rest of the fetching, robots, throttling, caching, and API infrastructure stays the same.

## Public-web safety boundaries

Extractinator is designed for publicly accessible resources only. It does not log in, collect private data, bypass authentication, bypass CAPTCHA or access controls, or deliberately evade anti-bot mechanisms.

The fetch policy also rejects URLs resolving to private, loopback, link-local, reserved, multicast, or unspecified network addresses and re-validates redirects.

These controls reduce risk but do not make arbitrary web collection automatically permissible. Users still need to consider applicable law, site terms, and operational policies.

## Known limitations

- HTML layouts change, so site adapters can break.
- Generic extraction is inherently less precise than a site-specific adapter.
- JSON-LD quality varies by site.
- JavaScript-only pages may require browser rendering, which is not enabled in this release.
- Cache state is in memory and disappears when the process stops.
- The service currently extracts one requested page at a time rather than operating as a distributed crawler.
- DNS-based URL policy is a defense-in-depth measure, not a complete production egress gateway.

## Long-term integration

For a site owner-controlled integration, an official documented and versioned API or data feed is the durable solution. Extractinator isolates scraping behind adapters so consumers can change the upstream source without rewriting the application-facing API.

## Current milestone

**Extractinator v0.1** is the complete first foundation:

- backend
- frontend dashboard
- adapter architecture
- generic extraction
- API documentation
- safety policy
- automated tests
- offline fixtures

Future extensions can add browser rendering, more normalized schemas, more adapters, persistent storage, observability, and a separate crawl scheduler.
