@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo Creating virtual environment...
    python -m venv .venv
    if errorlevel 1 exit /b 1
)

call ".venv\Scripts\activate.bat"
python -m pip install -r requirements.txt
if errorlevel 1 exit /b 1

echo.
echo Starting Extractinator...
echo Open http://127.0.0.1:8000/
echo API docs: http://127.0.0.1:8000/docs
echo.
python -m uvicorn app:app --host 127.0.0.1 --port 8000
