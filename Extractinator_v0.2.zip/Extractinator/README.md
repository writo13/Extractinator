# Extractinator

Turns a publicly accessible web page into structured JSON, through a REST API and a browser dashboard served by the same process (no Node.js, no build step).

It is a **layered** extractor, not a universal scraper: it uses the most specific strategy available for each page.

```text
Public URL
   ↓
URL policy      scheme · port · credentials · private/reserved IPs · DNS
   ↓
robots.txt      RFC 9309: wildcards, Crawl-delay, fails closed
   ↓
Fetcher         per-host throttle · LRU cache · retries · size limit · charset detection
   ↓
Site adapter? ── yes ──→ adapter extraction (falls back to generic if the page doesn't match)
   │ no
   ↓
JSON / plain text → returned as is
HTML → JSON-LD → metadata → semantic HTML
   ↓
Normalized JSON + provenance + warnings
```

The first site adapter is for `books.toscrape.com`, a public scraping sandbox.

## Quick start

**Windows:** double-click `start.bat` (creates `.venv`, installs dependencies, starts the server), then open <http://127.0.0.1:8000/>.

**macOS / Linux:**

```bash
python3 -m venv .venv && source .venv/bin/activate
python -m pip install -r requirements.txt
python run.py
```

Swagger UI is at `/docs` and ReDoc at `/redoc`.

## Configuration

Environment variables, all optional:

| Variable | Default | Meaning |
|---|---|---|
| `EXTRACTINATOR_USER_AGENT` | `Extractinator/<version>` | Sent on every request and used to match `robots.txt` groups. **Add a contact**, e.g. `MyBot/1.0 (+mailto:you@example.com)`, so site owners can reach you. |
| `EXTRACTINATOR_DELAY` | `0.5` | Minimum seconds between requests to one host (raised to the site's `Crawl-delay`, capped at 10 s). |
| `EXTRACTINATOR_RETRIES` | `3` | Retries for network errors and HTTP 429/5xx. |
| `EXTRACTINATOR_BACKOFF` | `1.0` | Base for exponential backoff (1 s, 2 s, 4 s …). |
| `EXTRACTINATOR_TIMEOUT` | `15` | Seconds per request. |
| `EXTRACTINATOR_MAX_BYTES` | `5000000` | Largest response accepted (checked after decompression). |
| `EXTRACTINATOR_CACHE_TTL` | `3600` | Seconds a fetched page stays cached. |
| `EXTRACTINATOR_CACHE_MAX_ENTRIES` | `64` | Cache size (least recently used is evicted). |
| `EXTRACTINATOR_HOST` / `_PORT` | `127.0.0.1` / `8000` | Used by `run.py` and `start.bat`. |

```cmd
set EXTRACTINATOR_DELAY=1
start.bat
```

PowerShell: `$env:EXTRACTINATOR_DELAY = "1"`. An invalid value stops startup with a clear message.

`robots.txt` handling cannot be switched off through the environment, by design.

> **The API has no authentication or rate limiting.** Anyone who can reach it can make your machine fetch public URLs. Keep it on `127.0.0.1`, or put it behind something that adds auth, before changing `EXTRACTINATOR_HOST`.

## API

| Endpoint | Purpose |
|---|---|
| `GET /health` | Status and version |
| `GET /adapters` | Installed site adapters |
| `GET /capabilities?url=…` | Which strategy would handle this URL (validates the URL, makes no network request) |
| `GET /extract?url=…` | Extract a page |
| `POST /extract` | Same, with body `{"url": "https://…"}` |

### Errors

Every error has the same body, `{"error": "...", "type": "..."}`.

| Status | Meaning |
|---|---|
| 400 | URL rejected by the public-web policy (bad scheme, credentials, non-standard port, private/local address, unresolvable host) |
| 403 | Blocked by `robots.txt`, or `robots.txt` could not be retrieved (5xx or network error) |
| 404 | The page returned 404 or 410 |
| 413 | Response larger than `EXTRACTINATOR_MAX_BYTES` |
| 415 | Content type is not HTML, JSON or plain text |
| 422 | Invalid request, or the content could not be parsed (e.g. malformed JSON) |
| 502 | Upstream failed after retries, or any other upstream error status |
| 504 | Upstream timed out |
| 500 | Unexpected internal error (details stay in the server log) |

### Example result

```json
{
  "source": {
    "url": "https://example.com/article",
    "requested_url": "https://example.com/article",
    "retrieved_at": "2026-10-02T09:30:00+00:00",
    "method": "jsonld",
    "adapter": null,
    "content_type": "text/html",
    "cached": false
  },
  "data": {
    "type": "article",
    "metadata": { "title": "Example Article", "language": "en" },
    "content": {
      "headings": [], "paragraphs": [], "links": [], "images": [], "tables": [],
      "counts": { "headings": 0, "paragraphs": 0, "links": 0, "images": 0, "tables": 0 }
    },
    "structured_data": {}
  },
  "warnings": []
}
```

`source.url` is the final URL after redirects, `requested_url` is what you asked for. `content.counts` holds the totals before the 100-link / 100-image / 20-table caps; a warning says when a list was cut.

## Extraction strategy

1. **Site adapter**: exact parsing for a known site. If the page no longer matches the adapter's expectations, extraction falls back to generic and adds a warning instead of failing.
2. **JSON** (`application/json`) and **plain text**: returned as is.
3. **JSON-LD**: when a page declares several entities, the most specific one wins (Product/Article/Recipe… beat Organization/WebPage).
4. **Metadata**: OpenGraph, Twitter cards, `description`, author, canonical URL, language.
5. **Semantic HTML**: headings, paragraphs, links, images, tables, taken from a lone `<article>`, else `<main>`, else the whole page.

Pages that are rendered by JavaScript yield little text; the result then carries a warning saying so.

## Adding a site adapter

```python
class MyAdapter(Adapter):
    name = "my_site"

    def can_handle(self, url: str) -> bool:
        return urlparse(url).hostname == "example.com"

    def extract(self, result: FetchResult) -> ExtractionResult:
        ...  # raise ExtractionError if the markup is not what you expect
```

Register it in `ExtractinatorService` (or pass `adapters=[...]`). Fetching, robots, throttling, caching, the API and the dashboard all work unchanged.

## Public-web safety

Extractinator reads publicly accessible pages only. It does not log in, solve CAPTCHAs, or evade anti-bot measures.

- Only `http`/`https` on ports 80/443, no credentials in URLs.
- Hostnames and every redirect hop must resolve to public addresses only (loopback, private, link-local, CGNAT, reserved, multicast, and IPv4 addresses hidden inside IPv6 are refused).
- `robots.txt` is obeyed, including `*` and `$` patterns and `Crawl-delay`. If it cannot be retrieved because of a server error, fetching is refused.
- Requests are throttled per host, retried with backoff, size-limited and carry no cookies.
- The dashboard escapes everything it renders and ships a strict Content-Security-Policy.

These controls reduce risk; they do not make every collection lawful. You are still responsible for the site's terms and the law that applies to you.

## Tests

```cmd
test.bat                 (or: python -m pip install -r requirements-dev.txt && python -m pytest -q)
```

About 160 offline tests, about two seconds. The fetcher tests run against a real HTTP server on `127.0.0.1` rather than mocks, so redirects, gzip, timeouts, streaming limits and robots behaviour go through the real `requests` stack.

`python scripts/live_smoke.py` checks the real sites and exits non-zero on failure. It needs internet access and is not part of the pytest run. `python scripts/demo.py <url>` prints one extraction.

## Known limitations

- **DNS rebinding.** The URL policy resolves a hostname and `requests` resolves it again when connecting, so a hostile DNS server could answer differently the second time. Closing this needs connections pinned to the validated IP, or an egress proxy; the policy alone is defence in depth.
- No authentication, rate limiting or persistence (cache and robots rules live in memory of one process).
- No JavaScript rendering, and one page per request (no crawling).
- Generic extraction is heuristic. Site adapters break when the site changes layout; the live smoke test is there to notice.
- For a site you control, an official versioned API or data feed is the durable solution; adapters keep scraping isolated so consumers can switch later.

## Project layout

```text
Extractinator/
├── app.py · run.py · start.bat · test.bat
├── requirements.txt · requirements-dev.txt · pytest.ini
├── frontend/            dashboard (index.html, assets/app.js, assets/styles.css)
├── extractinator/
│   ├── api.py           FastAPI app, error mapping, security headers
│   ├── service.py       adapter → fallback → generic orchestration
│   ├── core/            config · policy · fetcher · encoding · exceptions · models · registry
│   ├── extractors/      jsonld · metadata · html · json_data · generic
│   ├── adapters/        base · books_to_scrape
│   └── schemas/         response models
├── tests/               offline suite + fixtures
├── scripts/             demo.py · live_smoke.py
└── legacy/              original Books.toscrape client (kept for reference; `python -m pytest legacy`)
```

See `CHANGELOG.md` for what changed in 0.2.0.
