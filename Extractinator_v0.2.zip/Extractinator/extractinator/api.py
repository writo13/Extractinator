from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, Query, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from extractinator import __version__
from extractinator.core.exceptions import ExtractinatorError
from extractinator.schemas.common import ErrorResponse, ExtractionResponse
from extractinator.service import ExtractinatorService


FRONTEND_DIR = Path(__file__).resolve().parent.parent / "frontend"

# The dashboard renders text scraped from arbitrary sites. It escapes everything, and this
# policy is the second line of defence. It is applied to the dashboard only, because the
# Swagger/ReDoc pages need inline scripts and a CDN.
DASHBOARD_HEADERS = {
    "Content-Security-Policy": (
        "default-src 'self'; img-src 'self' data:; base-uri 'none'; "
        "form-action 'self'; frame-ancestors 'none'"
    ),
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
}

ERROR_RESPONSES = {
    400: {"model": ErrorResponse, "description": "URL rejected by the public-web policy"},
    403: {"model": ErrorResponse, "description": "Blocked by robots.txt"},
    404: {"model": ErrorResponse, "description": "The upstream page does not exist"},
    413: {"model": ErrorResponse, "description": "Upstream response too large"},
    415: {"model": ErrorResponse, "description": "Unsupported upstream content type"},
    422: {"model": ErrorResponse, "description": "Invalid request, or the page could not be parsed"},
    502: {"model": ErrorResponse, "description": "Upstream fetch failed"},
    504: {"model": ErrorResponse, "description": "Upstream timed out"},
}


class ExtractRequest(BaseModel):
    url: str = Field(..., min_length=8, max_length=2048)


def _error_response(status_code: int, message: str, error_type: str) -> JSONResponse:
    return JSONResponse(
        status_code=status_code,
        content={"error": message, "type": error_type},
    )


def create_app(service: ExtractinatorService | None = None) -> FastAPI:
    service = service or ExtractinatorService()

    app = FastAPI(
        title="Extractinator",
        version=__version__,
        description=(
            "A public-web extraction API using site adapters and generic structured-data extraction."
        ),
        docs_url="/docs",
        redoc_url="/redoc",
    )

    @app.exception_handler(ExtractinatorError)
    async def extractinator_error(request: Request, exc: ExtractinatorError):
        return _error_response(exc.status_code, str(exc), type(exc).__name__)

    @app.exception_handler(RequestValidationError)
    async def validation_error(request: Request, exc: RequestValidationError):
        first = exc.errors()[0] if exc.errors() else {}
        where = ".".join(str(part) for part in first.get("loc", ()) if part not in {"query", "body"})
        message = f"{where}: {first.get('msg', 'invalid request')}" if where else "invalid request"
        return _error_response(422, message, "ValidationError")

    @app.exception_handler(Exception)
    async def unexpected_error(request: Request, exc: Exception):
        # Starlette re-raises after this handler runs, so the traceback is still logged by the server.
        return _error_response(500, "unexpected internal error", "InternalServerError")

    @app.middleware("http")
    async def dashboard_security_headers(request: Request, call_next):
        response = await call_next(request)
        if request.url.path == "/" or request.url.path.startswith("/assets/"):
            for name, value in DASHBOARD_HEADERS.items():
                response.headers.setdefault(name, value)
        return response

    app.mount("/assets", StaticFiles(directory=FRONTEND_DIR / "assets"), name="assets")

    @app.get("/", include_in_schema=False)
    @app.head("/", include_in_schema=False)
    def dashboard():
        return FileResponse(FRONTEND_DIR / "index.html")

    @app.get("/health")
    @app.head("/health", include_in_schema=False)
    def health():
        return {
            "status": "ok",
            "service": "extractinator",
            "version": __version__,
        }

    @app.get("/adapters")
    def adapters():
        return {
            "adapters": service.registry.names(),
        }

    @app.get("/capabilities", responses={400: ERROR_RESPONSES[400], 422: ERROR_RESPONSES[422]})
    def capabilities(url: str = Query(..., min_length=8, max_length=2048)):
        return service.capabilities(url)

    @app.get("/extract", response_model=ExtractionResponse, responses=ERROR_RESPONSES)
    def extract(url: str = Query(..., min_length=8, max_length=2048)):
        return service.extract(url).as_dict()

    @app.post("/extract", response_model=ExtractionResponse, responses=ERROR_RESPONSES)
    def extract_post(request: ExtractRequest):
        return service.extract(request.url).as_dict()

    return app
