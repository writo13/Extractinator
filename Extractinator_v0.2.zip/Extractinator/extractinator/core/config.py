from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Mapping

from extractinator import __version__

PREFIX = "EXTRACTINATOR_"


@dataclass(frozen=True)
class Settings:
    """Runtime settings. Override any of them with EXTRACTINATOR_* environment variables.

    robots.txt handling is deliberately not configurable from the environment.
    """

    user_agent: str = f"Extractinator/{__version__}"
    delay: float = 0.5  # minimum seconds between requests to one host
    retries: int = 3
    backoff: float = 1.0
    timeout: float = 15.0
    max_bytes: int = 5_000_000
    cache_ttl: float = 3600.0
    cache_max_entries: int = 64
    host: str = "127.0.0.1"
    port: int = 8000

    @classmethod
    def from_env(cls, env: Mapping[str, str] | None = None) -> "Settings":
        env = os.environ if env is None else env
        defaults = cls()
        values: dict[str, object] = {}
        for name in cls.__dataclass_fields__:
            raw = env.get(PREFIX + name.upper())
            if raw is None or raw.strip() == "":
                continue
            kind = type(getattr(defaults, name))
            try:
                values[name] = raw.strip() if kind is str else kind(raw)
            except ValueError as exc:
                raise ValueError(
                    f"{PREFIX}{name.upper()} must be a valid {kind.__name__}, got {raw!r}"
                ) from exc
        return cls(**values)  # type: ignore[arg-type]
